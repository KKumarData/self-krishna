aws ecr get-login-password --region eu-central-1 | docker login --username AWS --password-stdin 984636045500.dkr.ecr.eu-central-1.amazonaws.com
docker build -t hema-cdp-prod-spark-eks-repository .
docker tag hema-cdp-prod-spark-eks-repository:latest 984636045500.dkr.ecr.eu-central-1.amazonaws.com/hema-cdp-prod-spark-eks-repository:latest
docker push 984636045500.dkr.ecr.eu-central-1.amazonaws.com/hema-cdp-prod-spark-eks-repository:latest