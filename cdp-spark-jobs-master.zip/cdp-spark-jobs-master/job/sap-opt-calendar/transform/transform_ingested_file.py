from utils.modules import logger
from pyspark.sql.functions import lit, col, substring, lpad, to_date, to_timestamp, date_format

logger = logger()

def transform_sap_opt_calendar(**kwargs):

    logger.info("Invoked transform_sap_opt_calendar def")

    df = kwargs.get("df")
    ingestion_date = kwargs.get("exc_period")
    
    df = (
        df.withColumnRenamed('_c0', 'vendor_number')
        .withColumnRenamed('_c1', 'location_id')
        .withColumnRenamed('_c2', 'headgroup')
        .withColumnRenamed('_c3', 'opt_cycle')
        .withColumnRenamed('_c4', 'ordering_date')
        .withColumnRenamed('_c5', 'ordering_time')
        .withColumnRenamed('_c6', 'production_date')
        .withColumnRenamed('_c7', 'production_time')
        .withColumnRenamed('_c8', 'delivery_date')
        .withColumnRenamed('_c9', 'delivery_time')
        .withColumnRenamed('_c10', 'batch_run_number')
        .withColumn('etl_date', to_date(lit(ingestion_date), 'yyyy-MM-dd'))
        .withColumn("location_id", lpad(substring('location_id', 2, 5), 5, '0'))
        .withColumn('ordering_date', to_date(col('ordering_date'), 'yyyyMMdd'))
        .withColumn('ordering_time', date_format(to_timestamp(col('ordering_time'), 'HHmmss'), 'HH:mm:ss'))
        .withColumn('production_date', to_date(col('production_date'), 'yyyyMMdd'))
        .withColumn('production_time', date_format(to_timestamp(col('production_time'), 'HHmmss'), 'HH:mm:ss'))
        .withColumn('delivery_date', to_date(col('delivery_date'), 'yyyyMMdd'))
        .withColumn('delivery_time', date_format(to_timestamp(col('delivery_time'), 'HHmmss'), 'HH:mm:ss'))
    )

    return df