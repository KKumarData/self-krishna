import os
import logging 
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType 
from utils.modules import logger
from functools import reduce

# Instanciate Logger
logger = logger()

def TCurrencyExchange(**kwargs):

    logger.info('Invoked TCurrencyExchange def')

    dfCurrExch = kwargs.get("df")
    columns = "rate_type;zfcurr;ztcurr;exchange_rate;zukurs;zffact;ztfact".split(";")

    oldColumns=dfCurrExch.schema.names
    dfCurrExch = reduce(lambda dfCurrExch, idx: dfCurrExch.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfCurrExch)

    dfCurrExch = dfCurrExch.withColumn("exchange_rate",expr("concat(substring(exchange_rate,1,4),'-', substring(exchange_rate,5,2),'-', '0' ,substring(exchange_rate,7,2))").cast("date")) \
                           .withColumn("load_time",current_timestamp()) \
                           .withColumn("ingestion_date",current_date()) \
                           .withColumn("year", year(current_date())) \
                           .withColumn("month", month(current_date())) \
                           .withColumn("day", dayofmonth(current_date())) \


    logger.info('End of TCurrencyExchange def')

    return dfCurrExch