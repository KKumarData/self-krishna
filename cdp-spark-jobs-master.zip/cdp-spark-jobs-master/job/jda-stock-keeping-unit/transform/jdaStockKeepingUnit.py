import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import * 
from pyspark.sql.types import *
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name

logger = logger()

def TjdaStockKeepingUnit(**kwargs):

  logger.info("Invoked TjdaSkuReplenishmentSettings def")

  dfjdaStockKeepingUnit = kwargs.get("df")

  #Lowering the columns from caps:
  lower_coloumn_names = [c.lower() for c in dfjdaStockKeepingUnit.columns]
  dfjdaStockKeepingUnit = dfjdaStockKeepingUnit.toDF(*lower_coloumn_names)
  
  #Renaimg of the columns from caps:
  columns = "item|loc|ohpost_date|sku_replishment_type|replenmethod|assortment_location|product_start_date|product_end_date|sku_plan_status|sku_status|dfuview_sw|sku_sw|contract_start_date|contract_end_date|contract_id|contract_total_quantity|contract_remainder_quantity|avg_lead_time|lead_time_sd|hema_replenishment_type".split("|")
  oldColumns = dfjdaStockKeepingUnit.schema.names
  dfjdaStockKeepingUnit = reduce(lambda dfjdaStockKeepingUnit, idx: dfjdaStockKeepingUnit.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfjdaStockKeepingUnit)
   
  #Adding new column names:
  dfjdaStockKeepingUnit = dfjdaStockKeepingUnit.withColumn("ingestion_file", input_file_name())\
                                               .withColumn("etl_date", current_date())
  #Casting datatypes of column:
  dfjdaStockKeepingUnit = dfjdaStockKeepingUnit.withColumn("loc",format_string("%05d", col("loc").cast("int")))\
                                                               .withColumn("item",col("item").cast("int"))

  #Final Select:
  dfjdaStockKeepingUnit = dfjdaStockKeepingUnit.select("item","loc","ohpost_date","sku_replishment_type","replenmethod","assortment_location",
                          "product_start_date","product_end_date","sku_plan_status","sku_status","contract_start_date","contract_end_date",
                          "contract_id","contract_total_quantity","contract_remainder_quantity","dfuview_sw","sku_sw","avg_lead_time",
                          "lead_time_sd","hema_replenishment_type","etl_date","ingestion_file")

  logger.info("End of TjdaSkuReplenishmentSettings def")
    
  return dfjdaStockKeepingUnit

