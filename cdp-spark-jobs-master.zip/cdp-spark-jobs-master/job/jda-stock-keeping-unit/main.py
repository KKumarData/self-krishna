import os
import sys
import ast
import sys
import inspect

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

from threading import Thread
from utils.modules import logger
from utils.writeS3 import WriteS3
from utils.extractS3 import ReadS3
from multiprocessing.pool import ThreadPool
from utils.sparkSession import SparkSessionFunc
from botocore.exceptions import ClientError
from transform.jdaStockKeepingUnit import TjdaStockKeepingUnit

logger = logger()

logger.info("Init of Main ")

def main(**kwargs):

    env = kwargs.get("env")
    app_name = kwargs.get("app_name")
    raw_bucket = kwargs.get("raw_path")
    curated_bucket = kwargs.get("curated_path")
    period = kwargs.get("execution_period")
    file_format = kwargs.get("file_format")
    job_mode = kwargs.get("job_mode")

    # Create Spark Session
    logger.info("Create Spark Session")

    ss = SparkSessionFunc(app_name=app_name, env=env)

    logger.info("Load newly ingested data from S3")

    df = ReadS3(
        ss=ss,
        env=env,
        s3_bucket=raw_bucket + "/ingestion_date=%s/" % (period),
        file_format=file_format,
        load_type=job_mode,
        period=period,
        header=True,
        sep='|',
        compressed=True
    )


    logger.info("End load process from S3")

    # Set Transformation Process
    logger.info("Start Transformation process")

    dfStockKeepingUnit = TjdaStockKeepingUnit(df=df)

    logger.info("End newly ingested transformation process")

    logger.info("Start  write process")

    WriteS3(
            df=dfStockKeepingUnit,
            bucket=curated_bucket,
            env=env,
            job_mode=job_mode,
            ss=ss,
            flag_partition=False
    )
    
    logger.info("End write process")


if __name__ == "__main__":
    env = sys.argv[1]
    app_name = sys.argv[2]
    raw_path = sys.argv[3]
    curated_path = sys.argv[4]
    execution_period = sys.argv[5]
    file_format = sys.argv[6]
    job_mode = sys.argv[7]
   

    if "delta" not in job_mode:
        for period in ast.literal_eval(execution_period):
            try:
                main(
                    env=env,
                    app_name=app_name,
                    raw_path=raw_path,
                    curated_path=curated_path,
                    execution_period=period,
                    file_format=file_format,
                    job_mode=job_mode
                )
            except:
                pass
    else:
        main(
            env=env,
            app_name=app_name,
            raw_path=raw_path,
            curated_path=curated_path,
            execution_period=execution_period,
            file_format=file_format,
            job_mode=job_mode
        )
