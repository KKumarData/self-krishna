import os
import logging
import sys
from pyspark.sql.functions import *
from utils.modules import logger

# Instanciate Logger
logger = logger()


def TsfsOrdersStoreAvailability(**kwargs):

    logger.info("Invoked TsfsOrdersStoreAvailability def")

    df = kwargs.get("df")
    
    df = df.withColumnRenamed("orderId","order_id") \
            .withColumnRenamed("storeId","store_id") \
            .withColumn("load_time", current_timestamp()) \
            .withColumn("ingestion_date", current_date()) \
            .withColumn("year", year(current_timestamp())) \
            .withColumn("month", month(current_timestamp())) \
            .withColumn("day", dayofmonth(current_timestamp()))


    logger.info("End of TsfsOrdersStoreAvailability def")

    return df
