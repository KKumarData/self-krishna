DO
$do$
declare var_job_name varchar = 			'sap-sales-manual-corrections';
var_landing_path varchar = 				's3://hema-cdp-prod-landing/sap-sales-manual-corrections/'; 
var_raw_path varchar = 					's3://hema-cdp-prod-raw/sap-sales-manual-corrections/';
var_curated_path varchar = 				's3://hema-cdp-prod-curated/sap-sales-manual-corrections/';
var_file_format varchar = 				'csv';
var_dcl_channel varchar = 				'sap-sales-manualcorrections'; 
var_flag_enable boolean = 				'1';
var_job_mode varchar = 					'delta'; 
var_job_env varchar = 					'cloud';
var_partition_columns varchar = 		$$"['year', 'month', 'day']"$$; 
var_start_date varchar = 				'2021-01-01T06:00:00';
var_execution_date_formatted varchar = 	'%Y-%m-%dT%H%M'; 
var_delta_period varchar = 				$$['2021-01-01T06:00:00']$$;
var_job_location varchar =  			'/home/hadoop/main.py'; 
var_redshift_tables varchar = 			$$['sap_sales_manual_corrections']$$; 
var_redshift_views varchar = 			$$['sap_sales_manual_corrections_mv']$$; 
var_job_type varchar = 					'pyspark';
var_row_tag varchar =					'';
var_rowkey varchar =					$$['calendar_day', 'local_currency', 'store_id', 'category_id', 'sales_organisation', 'distribution_channel_id']$$;
BEGIN
   IF EXISTS (SELECT 1 FROM data_pipeline.job where job_name = var_job_name) 
   THEN
      UPDATE data_pipeline.job 
     	SET landing_path = var_landing_path,
     		raw_path = var_raw_path,
     		curated_path = var_curated_path,
     		file_format = var_file_format,
     		dcl_channel = var_dcl_channel,
     		flag_enable = var_flag_enable,
     		job_mode = var_job_mode,
     		job_env = var_job_env,
     		partition_columns = var_partition_columns,
     		start_date = var_start_date,
     		execution_date_formatted = var_execution_date_formatted,
     		delta_period = var_delta_period,
     		job_location = var_job_location,
     		redshift_tables = var_redshift_tables,
     		redshift_views = var_redshift_views,
     		job_type = var_job_type,
			row_tag = var_row_tag,
			rowkey = var_rowkey
		WHERE job_name = var_job_name
     	;
   ELSE
     insert into data_pipeline.job (job_name, landing_path, raw_path, curated_path, file_format, dcl_channel, flag_enable, job_mode, job_env, partition_columns, start_date, 
     								execution_date_formatted, job_location, delta_period, redshift_tables, redshift_views, job_type, row_tag, rowkey)
     select var_job_name, var_landing_path, var_raw_path, var_curated_path, var_file_format, var_dcl_channel, var_flag_enable, var_job_mode, var_job_env, var_partition_columns,
     		var_start_date, var_execution_date_formatted, var_delta_period, var_job_location, var_redshift_tables, var_redshift_views, var_job_type, var_row_tag, var_rowkey
    ;
   END IF;
END
$do$