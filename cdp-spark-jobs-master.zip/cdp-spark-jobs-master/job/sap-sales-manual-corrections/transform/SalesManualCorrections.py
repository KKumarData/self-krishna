
import os
import logging 
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType 
from utils.modules import logger
from functools import reduce

# Instanciate Logger
logger = logger()

def TSalesManualCorrections(**kwargs):

    logger.info('Invoked TSalesManualCorrections def')

    dfManuCorrections = kwargs.get("df")
    columns = "calendar_day;calendar_week;fiscal_per;fiscal_varient;fiscal_year;fiscal_per3;week_day1;local_currency;store;category;he_fiswk;he_fiswk2;postal_code;division;sales_org;distribution_channel;version;vtype;rt_revreas;curr_type;heromzvpl".split(";")

    oldColumns=dfManuCorrections.schema.names
    dfManuCorrections = reduce(lambda dfManuCorrections, idx: dfManuCorrections.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfManuCorrections)
    
    dfManuCorrections = dfManuCorrections.withColumn("calendar_day", expr("concat(substring(calendar_day,1,4),'-', substring(calendar_day,5,2),'-', '0' ,substring(calendar_day,7,2))").cast("date")) \
                           .withColumnRenamed("fiscal_per","fiscal_period") \
                           .withColumnRenamed("store","store_id") \
                           .withColumnRenamed("category","category_id") \
                           .withColumnRenamed("division","world_id") \
                           .withColumnRenamed("sales_org","sales_organisation") \
                           .withColumnRenamed("distribution_channel","distribution_channel_id") \
                           .withColumnRenamed("vtype","value_type") \
                           .withColumnRenamed("curr_type","currency_type") \
                           .withColumnRenamed("heromzvpl","manual_correction_amount") \
                           .withColumn("manual_correction_amount", expr("case when right(manual_correction_amount,1) = '-' then -1 * cast(replace(manual_correction_amount, '-', '') as double) else manual_correction_amount end")) \
                           .withColumn("manual_correction_amount", col("manual_correction_amount").cast("double")) \
                           .withColumn("load_time",current_timestamp()) \
                           .withColumn("ingestion_date",current_date()) \
                           .withColumn("year", year("calendar_day")) \
                           .withColumn("month", month("calendar_day")) \
                           .withColumn("day", dayofmonth("calendar_day")) \
                           

        
    logger.info('End of TSalesManualCorrections def')

    return dfManuCorrections
