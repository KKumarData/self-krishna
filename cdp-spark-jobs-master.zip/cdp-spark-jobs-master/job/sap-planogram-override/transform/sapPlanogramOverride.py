import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TplanogramOverride(**kwargs):

    logger.info("Invoked TplanogramOverride def")

    dsapPlanogram = kwargs.get("df")

    columns = "product_id;presentation_assortment;startdate;store_type;enddate;pog_shelfmax;hart_selfmax_override;pog_presqty_perc;hart_presqty_perc_override;hart_presqty_qty_override;hart_min_leading;hart_max_leading;hart_salesperiod_leading;dummy_column".split(";")
    
    oldColumns = dsapPlanogram.schema.names
    dsapPlanogram = reduce(lambda dsapPlanogram, idx: dsapPlanogram.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dsapPlanogram)
    
    dsapPlanogram = dsapPlanogram.withColumn("filename_reverse", input_file_name())
    dsapPlanogram =  dsapPlanogram.withColumn("fileday",reverse(split(reverse(dsapPlanogram.filename_reverse), '/')[1]))
    dsapPlanogram =  dsapPlanogram.withColumn("filemonth",reverse(split(reverse(dsapPlanogram.filename_reverse), '/')[2]))
    dsapPlanogram =  dsapPlanogram.withColumn("fileyear",reverse(split(reverse(dsapPlanogram.filename_reverse), '/')[3]))
    dsapPlanogram = dsapPlanogram.withColumn('ingestion_date', concat(col('fileyear'),lit('-'), col('filemonth'),lit('-'), col('fileday')).cast("date"))
    dsapPlanogram = (
        dsapPlanogram.withColumn("product_id",col("product_id").cast("bigint"))
        .withColumn(
                            "startdate",
                            expr(
                                "concat(substring(startdate,1,4),'-', substring(startdate,5,2),'-',substring(startdate,7,2))").cast("date")
                                )
         .withColumn(
                            "enddate",
                            expr(
                                "concat(substring(enddate,1,4),'-', substring(enddate,5,2),'-',substring(enddate,7,2))").cast("date")
                                )
        .withColumn("pog_shelfmax",col("pog_shelfmax").cast("int"))
        .withColumn("hart_selfmax_override",col("hart_selfmax_override").cast("int"))
        .withColumn("pog_presqty_perc",col("pog_presqty_perc").cast('decimal(17,3)'))
        .withColumn("hart_presqty_perc_override",col("hart_presqty_perc_override").cast('decimal(17,3)'))
        .withColumn("hart_presqty_qty_override",col("hart_presqty_qty_override").cast('decimal(17,3)'))
        .withColumn("load_time", current_timestamp())
        .withColumn("year", year("ingestion_date"))
        .withColumn("month", month("ingestion_date"))
        .withColumn("day", dayofmonth("ingestion_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse","fileday","filemonth","fileyear")
        .select("product_id","presentation_assortment","startdate","store_type","enddate","pog_shelfmax","hart_selfmax_override","pog_presqty_perc","hart_presqty_perc_override","hart_presqty_qty_override","hart_min_leading","hart_max_leading","hart_salesperiod_leading","dummy_column","load_time","ingestion_date","ingestion_file","year","month","day")
    
        )

    dsapPlanogram.show(20,False)

    logger.info("End of sap planogram override def")
    
    return dsapPlanogram
