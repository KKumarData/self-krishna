import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def Tstorelfl(**kwargs):

    logger.info("Invoked Tstorelfl def")

    dlflStore = kwargs.get("df")

    columns = "fiscal_year;fiscal_varnt;store_id;lfl;dummy_column".split(";")
    
    oldColumns = dlflStore.schema.names
    dlflStore = reduce(lambda dlflStore, idx: dlflStore.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dlflStore)
    
    dlflStore = (
        dlflStore.withColumn("fiscal_year",col("fiscal_year").cast("int"))
        .withColumn("store_id",col("store_id").cast("int"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("year", year("ingestion_date"))
        .withColumn("month", month("ingestion_date"))
        .withColumn("day", dayofmonth("ingestion_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("dummy_column")
        )

    dlflStore = dlflStore.dropDuplicates(['store_id','fiscal_year'])
    
    logger.info("End of sap store lfl def")
    
    return dlflStore
