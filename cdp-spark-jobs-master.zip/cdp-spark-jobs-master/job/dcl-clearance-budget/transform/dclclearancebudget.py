import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def Tclearancetarget(**kwargs):

    logger.info("Invoked Tclearancetarget def")

    dfclearancetarget = kwargs.get("df")

    columns = "Plant;Clearance_planversie;Clearance_target;LOC_CURRENCY;Custom_1;Custom_2".split(";")
    
    oldColumns = dfclearancetarget.schema.names
    dfclearancetarget = reduce(lambda dfclearancetarget, idx: dfclearancetarget.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfclearancetarget)
    
    dfclearancetarget = dfclearancetarget.withColumn("filename_reverse", input_file_name())

    dfclearancetarget = (dfclearancetarget.withColumn("fileday",reverse(split(reverse(dfclearancetarget.filename_reverse), '/')[1]))
                                .withColumn("filemonth",reverse(split(reverse(dfclearancetarget.filename_reverse), '/')[2]))
                                .withColumn("fileyear",reverse(split(reverse(dfclearancetarget.filename_reverse), '/')[3]))
                                .withColumn('creation_date', concat(col('fileyear'),lit('-'), col('filemonth'),lit('-'), col('fileday')).cast("date")))

    dfclearancetarget = (
        dfclearancetarget.withColumn("Plant", col("Plant").cast("int"))
        .withColumnRenamed("Plant","Store_Id")
        .withColumnRenamed("Clearance_planversie","Clearance_Plan_Version")
        .withColumnRenamed("LOC_CURRENCY","Local_Currency")
        .withColumn("Clearance_target", col("Clearance_target").cast("int"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date",col("creation_date")) \
        .withColumn("year", year("creation_date")) \
        .withColumn("month", month("creation_date")) \
        .withColumn("day", dayofmonth("creation_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse"))

    wdw = Window.partitionBy('Store_Id','Clearance_Plan_Version').orderBy(desc('ingestion_date'))
    dfclearancetarget = dfclearancetarget.withColumn('Rank',rank().over(wdw))
    dfclearancetarget = dfclearancetarget.filter(dfclearancetarget.Rank == 1).drop(dfclearancetarget.Rank)
    #dfclearancetarget = dfclearancetarget.dropDuplicates(['flr_dbkey','str_number','flr_livedate','flrfix_dbkey','flrfix_partid','flrfix_type','flrfix_name','flrfix_x','flrfix_y','flrfix_z'])

    dfclearancetarget = dfclearancetarget.select("Store_Id","Clearance_Plan_Version","Clearance_target","Local_Currency","Custom_1","Custom_2","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info("End of clearancetarget")
    
    return dfclearancetarget
