
from utils.modules import logger
from pyspark.sql.window import Window
from datetime import datetime, timedelta
from pyspark.sql.functions import col, coalesce, to_date, count, when, lit, first, row_number

logger = logger()

def transform_loy_member_wk(**kwargs):

	logger.info("Invoked transform_calendar_wk def")

	fisc_cal = kwargs.get("fisc_cal")
	test_users = kwargs.get("intersolve_test_users")
	loy_cards = kwargs.get("loyalty_cards")
	prof_address = kwargs.get("customer_address")
	loy_card_wk = kwargs.get("loyalty_cards_week")
	fisc_cal_wk = kwargs.get("fisc_cal_wk")
	etl_date_str = kwargs.get("ingestion_date")
	etl_date = datetime.strptime(etl_date_str, '%Y/%m/%d').date()

	loy_cards_win_spec = Window.partitionBy("hema_customer_id", "card_id").orderBy(col("load_time").desc())
	loy_cards = (
					loy_cards
					.withColumn("row_num", row_number().over(loy_cards_win_spec))
					.where(col('row_num')==1)

				)

	loy_calday = fisc_cal.alias('fisc_cal').where(col('fisc_cal.calday') == (etl_date - timedelta(days=1-7*0))).select('fisc_cal.calday', 'fisc_cal.calweek')

	loy_calday_calweeks = [row.calweek for row in loy_calday.collect()]
	intersolve_excluded_test_user_ids = [row.UserID for row in test_users.collect()]

	if not('etl_date' in loy_card_wk.columns):
		loy_card_wk = loy_card_wk.withColumn('etl_date', lit('').cast('date'))

	cards_curr_week = (
		loy_cards
		.where(
			(
				(col('card_id').like('606436172%'))
				|(col('card_id').like('606436171%'))
			)
			&(col('status').isin(['Normal', 'Blocked', 'Pending']))
			&(
				(~col('hema_customer_id').isin(intersolve_excluded_test_user_ids))
				|(col('hema_customer_id').isNull())
			)
		)
		.groupBy('card_id', 'hema_customer_id', 'status')
		.agg(first('card_id'), first('hema_customer_id'), first('status'))
		.drop('first(card_id)', 'first(hema_customer_id)', 'first(status)')
	)

	cust_country_temp = (
		prof_address
		.where(
			(col('country_code')!=',,')
			&(col('country_code')!='')
			&(col('country_code').isNotNull())
			&((~col('hema_customer_id').isin(intersolve_excluded_test_user_ids)) | (col('hema_customer_id').isNull()))
		)
		.groupBy('hema_customer_id', 'country_code')
		.agg(count('country_code'))
		.withColumnRenamed('count(country_code)', 'country_code_count')
	)

	cust_country_temp2 = (
		cust_country_temp
		.groupBy('hema_customer_id')
		.max('country_code_count')
		.withColumnRenamed('max(country_code_count)', 'max_country_code_count')
	)

	cust_country = (
		cust_country_temp
		.join(
			cust_country_temp2,
			(cust_country_temp.hema_customer_id==cust_country_temp2.hema_customer_id)
			&(cust_country_temp.country_code_count==cust_country_temp2.max_country_code_count)
			,'inner'
		)
		.select(cust_country_temp.hema_customer_id, cust_country_temp.country_code)
	)

	loy_card_wk  = loy_card_wk.where((~col('calweek').isin(loy_calday_calweeks)))

	loy_card_wk_temp = (
		loy_card_wk.alias('l')
		.join(fisc_cal_wk.alias('cal_wk'), col('l.calweek')==col('cal_wk.calweek_previous'), 'inner')
		.join(loy_calday.alias('pl'), col('pl.calweek')==col('cal_wk.calweek'), 'inner')
		.join(cards_curr_week.alias('ilc'), col('l.card_id')==col('ilc.card_id'), 'full')
		.join(cust_country.alias('a'), col('l.hema_id')==col('a.hema_customer_id'), 'left')
		.crossJoin(loy_calday.alias('p'))
		.select(
			coalesce(col('ilc.hema_customer_id'), col('l.hema_id')).alias('hema_id')
			,coalesce(col('ilc.card_id'), col('l.card_id')).alias('card_id')
			,col('p.calweek').cast('int').alias('calweek')
			,coalesce(col('a.country_code'), lit('NL')).alias('country')
			,when(col('ilc.card_id').like('606436171%'), lit('Plastic')).otherwise(lit('Digital')).alias('type_card')
			,when(col('l.card_id').isNull(), lit(1)).otherwise(lit(0)).alias('new_card_ind')
			,when(
				(col('ilc.status')=='Normal') 
				& (col('ilc.hema_customer_id').isNotNull()
				)
				,lit(1)
			).otherwise(lit(0)).alias('card_registration_ind')
			,when(
				(col('ilc.status')=='Pending') 
				| (
					(col('ilc.status')=='Normal') 
					& (col('ilc.hema_customer_id').isNull())
				)
				,lit(1)
			).otherwise(lit(0)).alias('card_activated_ind')
			,when(
				(col('ilc.status')=='Blocked')
				&(col('ilc.card_id').isNull())
				,lit(1)
			).otherwise(lit(0)).alias('card_deactivation_ind')
		)
	).withColumn('etl_date', to_date(lit(etl_date_str), 'yyyy/MM/dd'))

	loy_card_wk_temp = loy_card_wk_temp.drop_duplicates()
	loy_card_wk = loy_card_wk.unionByName(loy_card_wk_temp)

	return loy_card_wk