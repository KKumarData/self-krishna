import os
import sys
import ast
import sys
import boto3
import shutil
import inspect
from os import path
from pathlib import Path

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

from threading import Thread
from utils.modules import logger
from utils.writeS3 import WriteS3
from utils.extractS3 import ReadS3
from multiprocessing.pool import ThreadPool
from utils.sparkSession import SparkSessionFunc
from transform.transform import transform_loy_member_wk

logger = logger()

logger.info("Init of Main ")

def main(**kwargs):
	env = kwargs.get("env")
	app_name = kwargs.get("app_name")
	fisc_cal_path = kwargs.get("fisc_cal")
	test_users_path = kwargs.get("test_users")
	loy_cards_path = kwargs.get("loy_cards")
	prof_address_path = kwargs.get("prof_address")
	loy_cards_week_path = kwargs.get("loy_card_wk")
	fisc_cal_wk_path = kwargs.get("fisc_cal_wk")
	etl_date = kwargs.get("etl_date")

	logger.info("Create Spark Session")

	ss = SparkSessionFunc(app_name=app_name, env=env)

	# from utils.writeS3_delta import WriteDelta

	if env == 'local':
		loy_cards_path = currentdir+'/'+loy_cards_path+'-temp'

	logger.info(f"Load Fiscal Calendar from S3 {fisc_cal_path}")

	fisc_cal_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=fisc_cal_path,
		file_format='delta'
	)

	logger.info("End load process Fiscal Calendar from S3")

	logger.info(f"Load Loyalty Cards Week from S3 {loy_cards_week_path}")

	loy_cards_week_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=loy_cards_week_path,
		file_format='parquet'
	)

	logger.info("End load process Loyalty Cards Week from S3")

	logger.info(f"Load Intersolve Excluded Test Users from S3 {test_users_path}")

	test_users_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=test_users_path,
		file_format='csv',
		header=True,
		sep='|'
	)

	logger.info("End load process Intersolve Excluded Test Users from S3")

	logger.info(f"Load Loyalty Cards from S3 {loy_cards_path}")

	loy_cards_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=loy_cards_path,
		file_format='delta'
	)

	logger.info("End load process Loyalty Cards from S3")

	logger.info(f"Load SFCC Customer Address from S3 {prof_address_path}")

	prof_address_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=prof_address_path,
		file_format='delta'
	)

	logger.info("End load process SFCC Customer Address from S3")

	logger.info(f"Load Fiscal Calendar Week from S3 {fisc_cal_wk_path}")

	fisc_cal_wk_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=fisc_cal_wk_path,
		file_format='delta'
	)

	logger.info("End load process Fiscal Calendar Week from S3")

	logger.info("Start loyalty-member-week transformation process")

	loyalty_cards_week_df = transform_loy_member_wk(
		fisc_cal=fisc_cal_df,
		intersolve_test_users=test_users_df,
		loyalty_cards=loy_cards_df,
		customer_address=prof_address_df,
		fisc_cal_wk=fisc_cal_wk_df,
		loyalty_cards_week=loy_cards_week_df,
		ingestion_date=etl_date
		)

	logger.info("End loyalty-member-week transformation process")

	logger.info("Start Calendar Week DF write process")
	# loyalty_member_week_df.show()
	WriteS3(
		ss=ss,
		bucket=loy_cards_week_path+'-temp',
		df=loyalty_cards_week_df,
		flag_partition=False,
		job_mode="full"
	)

	logger.info("End Calendar Week DF write write process")


if __name__ == "__main__":
	main(
		env=sys.argv[1],
		app_name=sys.argv[2],
		fisc_cal=sys.argv[3],
		test_users=sys.argv[4],
		etl_date=sys.argv[5],
		loy_cards=sys.argv[6],
		prof_address=sys.argv[7],
		loy_card_wk=sys.argv[8],
		fisc_cal_wk=sys.argv[9]
	)
