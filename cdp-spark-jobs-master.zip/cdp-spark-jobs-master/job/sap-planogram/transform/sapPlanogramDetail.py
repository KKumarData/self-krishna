import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, logger, camelToUnderscores

# Instanciate Logger
logger = logger()


def TsapPlanogramDetail(**kwargs):

    logger.info("Invoked TsapPlanogramDetail def")

    df = kwargs.get("df")
    dfDetail = flatten_df(df)
    dfDetail = flatten_df(dfDetail)

    dfDetail = dfDetail.withColumn("details", explode("E1BPE1MALG")).drop("E1BPE1MALG")
    dfDetail = flatten_df(dfDetail)
    dfDetail = flatten_df(dfDetail)

    dfDetail = (
        dfDetail.withColumnRenamed("details_FUNCTION", "function")
        .withColumnRenamed("details_MATERIAL", "product_id")
        .withColumnRenamed("details_UNIT", "unit_of_measure")
        .withColumnRenamed("details_UNIT_ISO", "uom_iso")
        .withColumnRenamed("details_LAYOUT_MOD","presentation_assortment")
        .withColumnRenamed("details_SORT_SEQ", "sort_sequence")
        .withColumnRenamed("details_FACING", "facing")
        .withColumnRenamed("details_SHELF_BOARD_NUMBER", "shelf_number")
        .withColumnRenamed("details_FRONT", "shelf_front")
        .withColumnRenamed("details_SHELF_QUANTITY_MAX", "shelfmax")
        .withColumnRenamed("details_SHELF_QUANTITY_OPT", "shelfmax_opt")
        .withColumnRenamed("details_PRES_QNT", "presqty")
        .withColumnRenamed("details_LAYMOD_VER", "layout_module_version")
        .withColumnRenamed("details_ZZAANT_ETIKETTEN", "nr_of_shelf_labels")
        .withColumnRenamed("details_ZZPOSITIE", "shelf_position")
        .withColumnRenamed("details_ZZSUBPOSITIE", "shelf_subposition")
        .withColumnRenamed("details_ZZSEGMENT", "shelf_segmentnr")
        .withColumnRenamed("details_ZZDBKEY", "jda_keynr")
        .withColumnRenamed("EDI_DC40_CREDAT", "creation_date")
        .withColumnRenamed("EDI_DC40_CRETIM", "creation_time")
    )


    dfDetail = (dfDetail.select("function","product_id","unit_of_measure",\
                    "uom_iso","presentation_assortment","sort_sequence",\
                        "facing","shelf_number","shelf_front",\
                            "shelfmax","shelfmax_opt","presqty","layout_module_version",\
                                "nr_of_shelf_labels","shelf_position","shelf_subposition",\
                                    "shelf_segmentnr","jda_keynr","creation_date","creation_time")
                                    )


    dfDetail = (
        dfDetail.withColumn("product_id",col("product_id").cast("bigint"))
        .withColumn("facing", col("facing").cast('decimal(18,3)'))
        .withColumn("shelf_number", col("shelf_number").cast('decimal(18,3)'))
        .withColumn("shelf_front", col("shelf_front").cast('decimal(18,3)'))
        .withColumn("shelfmax", col("shelfmax").cast('decimal(18,3)'))
        .withColumn("shelfmax_opt", col("shelfmax_opt").cast('decimal(18,3)'))
        .withColumn("presqty", col("presqty").cast('decimal(18,3)'))
        .withColumn("layout_module_version", col("layout_module_version").cast('decimal(18,3)'))
        .withColumn("nr_of_shelf_labels",col("nr_of_shelf_labels").cast("int"))
        .withColumn("shelf_position",col("shelf_position").cast("int"))
        .withColumn("shelf_subposition",col("shelf_subposition").cast("int"))
        .withColumn(
                            "creation_date",
                            expr(
                                "concat(substring(creation_date,1,4),'-', substring(creation_date,5,2),'-',substring(creation_date,7,2))").cast("date")
                                )
        .withColumn("creation_time",col("creation_time").cast("bigint"))
        .withColumn("year", year("creation_date"))
        .withColumn("month", month("creation_date"))
        .withColumn("day", dayofmonth("creation_date"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .select("function","product_id","unit_of_measure","uom_iso","presentation_assortment","sort_sequence","facing","shelf_number","shelf_front","shelfmax","shelfmax_opt","presqty","layout_module_version","nr_of_shelf_labels","shelf_position","shelf_subposition","shelf_segmentnr","jda_keynr","creation_date","creation_time","load_time","ingestion_date","ingestion_file","year","month","day")
    )

    dfDetail = dfDetail.dropDuplicates(['product_id','presentation_assortment','layout_module_version','creation_date'])

    logger.info("End of TsapPlanogramDetail def")

    return dfDetail