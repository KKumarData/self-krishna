import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, camelToUnderscores, logger

# Instanciate logger
logger = logger()


def TsapPlanogramHeader(**kwargs):

    logger.info("Invoked TsapPlanogramHeader def")

    df = kwargs.get("df")
    dfHeader = flatten_df(df)
    dfHeader = flatten_df(dfHeader)

    dfHeader = (dfHeader.select("EDI_DC40_CREDAT","EDI_DC40_CRETIM","E1BPE1TWMLT_LANGU_ISO",\
                    "E1BPE1TWMLT_NAMEOFSTATE","E1BPE1WLMV_FUNCTION","E1BPE1WLMV_LAYOUT_MOD",\
                        "E1BPE1WLMV_LAYMOD_VER","E1BPE1WLMV_LMOD_STAT","E1BPE1WLMV_LM_DATE_FR",\
                            "E1BPE1WLMV_LM_DATE_TO"))
    

    dfHeader = (
        dfHeader.withColumnRenamed("E1BPE1WLMV_FUNCTION", "function")
        .withColumnRenamed("E1BPE1TWMLT_LANGU_ISO", "Language_code")
        .withColumnRenamed("E1BPE1TWMLT_NAMEOFSTATE", "Name_of_layout_module")
        .withColumnRenamed("E1BPE1WLMV_LAYOUT_MOD", "presentation_assortment")
        .withColumnRenamed("E1BPE1WLMV_LAYMOD_VER","layout_module_version")
        .withColumnRenamed("E1BPE1WLMV_LMOD_STAT", "layout_module_state")
        .withColumnRenamed("E1BPE1WLMV_LM_DATE_FR", "layout_module_startdate")
        .withColumnRenamed("E1BPE1WLMV_LM_DATE_TO", "layout_module_enddate")
        .withColumnRenamed("EDI_DC40_CREDAT", "creation_date")
        .withColumnRenamed("EDI_DC40_CRETIM", "creation_time")
    )

    dfHeader = (
        dfHeader.withColumn("layout_module_version",col("layout_module_version").cast('decimal(18,3)'))
        .withColumn("layout_module_state",col("layout_module_state").cast('decimal(18,3)'))
        .withColumn(
                            "layout_module_startdate",
                            expr(
                                "concat(substring(layout_module_startdate,1,4),'-', substring(layout_module_startdate,5,2),'-',substring(layout_module_startdate,7,2))").cast("date")
                                )
        .withColumn(
                            "layout_module_enddate",
                            expr(
                                "concat(substring(layout_module_enddate,1,4),'-', substring(layout_module_enddate,5,2),'-',substring(layout_module_enddate,7,2))").cast("date")
                                )
        .withColumn(
                            "creation_date",
                            expr(
                                "concat(substring(creation_date,1,4),'-', substring(creation_date,5,2),'-',substring(creation_date,7,2))").cast("date")
                                )
        .withColumn("creation_time",col("creation_time").cast("bigint"))
        .withColumn("year", year("creation_date"))
        .withColumn("month", month("creation_date"))
        .withColumn("day", dayofmonth("creation_date"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .select("function","Language_code","Name_of_layout_module","presentation_assortment","layout_module_version","layout_module_state","layout_module_startdate","layout_module_enddate","creation_date","creation_time","load_time","ingestion_date","ingestion_file","year","month","day")
    )

    dfHeader = dfHeader.dropDuplicates(['language_code','presentation_assortment','layout_module_version','creation_date'])

    logger.info("End of TsapPlanogramHeader def")

    return dfHeader