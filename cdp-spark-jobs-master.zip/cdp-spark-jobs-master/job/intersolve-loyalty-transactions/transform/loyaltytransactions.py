import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name

# Instanciate Logger
logger = logger()

def TLoyaltyTransactions(**kwargs):

    logger.info('Invoked TLoyaltyTransactions def')

    dfLoyTrxs = kwargs.get("df")

    columns = "record_number;card_id;hema_customer_id;transaction_date_time;client_ref;loyalty_transaction_hostref;loyalty_value;loyalty_value_unit;loyalty_transaction_type;pos_id;retailer_id;retailer_name;scheme_id;scheme_name;merchandise;employee_id;custom_1;custom_2;custom_3;custom_4;custom_5".split(";")
    oldColumns=dfLoyTrxs.schema.names
    dfLoyTrxs = reduce(lambda dfLoyTrxs, idx: dfLoyTrxs.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfLoyTrxs)
    
    dfLoyTrxs = dfLoyTrxs.withColumn("filename_reverse", input_file_name())
    dfLoyTrxs = dfLoyTrxs.withColumn("filename_reverse", reverse(split(reverse(dfLoyTrxs.filename_reverse), '/')[0]))
    
    dfLoyTrxs = dfLoyTrxs.withColumn("transaction_date_time",col("transaction_date_time").cast("timestamp")) \
                           .withColumn("hema_customer_id",expr("concat('{',hema_customer_id,'}')")) \
                           .withColumn("loyalty_transaction_hostref",col("loyalty_transaction_hostref").cast("int")) \
                           .withColumn("loyalty_value",col("loyalty_value").cast("int")) \
                           .withColumn("pos_id",col("pos_id").cast("bigint")) \
                           .withColumn("retailer_id",col("retailer_id").cast("bigint")) \
                           .withColumn("scheme_id",col("scheme_id").cast("int")) \
                           .withColumn("employee_id",col("employee_id").cast("int")) \
                           .withColumn("column_date", substring('filename_reverse',12,8)) \
                           .withColumnRenamed("column_date", "file_date") \
                           .withColumn("load_time",current_timestamp()) \
                           .withColumnRenamed("filename_reverse","ingestion_file") \
                           .withColumn("file_date",date_format(to_date(col("file_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date")) \
                           .withColumnRenamed("file_date","ingestion_date") \
                           .withColumn("year", year("ingestion_date")) \
                           .withColumn("month", month("ingestion_date")) \
                           .withColumn("day", dayofmonth("ingestion_date"))

    wdw = Window.partitionBy('card_id','transaction_date_time','loyalty_transaction_hostref').orderBy(desc('ingestion_date'))
    dfLoyTrxs = dfLoyTrxs.withColumn('Rank',rank().over(wdw))
    dfLoyTrxs = dfLoyTrxs.filter(dfLoyTrxs.Rank == 1).drop(dfLoyTrxs.Rank)
    dfLoyTrxs = dfLoyTrxs.dropDuplicates(['record_number','card_id','hema_customer_id','transaction_date_time','client_ref','loyalty_transaction_hostref','loyalty_value','loyalty_value_unit','loyalty_transaction_type','pos_id','retailer_id','retailer_name','scheme_id','scheme_name','merchandise','employee_id','custom_1','custom_2','custom_3','custom_4','custom_5'])

    dfLoyTrxs = dfLoyTrxs.select("record_number","card_id","hema_customer_id","transaction_date_time","client_ref","loyalty_transaction_hostref","loyalty_value","loyalty_value_unit","loyalty_transaction_type","pos_id","retailer_id","retailer_name","scheme_id","scheme_name","merchandise","employee_id","custom_1","custom_2","custom_3","custom_4","custom_5","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info('End of TLoyaltyTransactions def')

    return dfLoyTrxs
