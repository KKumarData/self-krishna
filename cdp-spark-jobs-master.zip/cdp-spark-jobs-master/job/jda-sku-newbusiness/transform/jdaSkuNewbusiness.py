import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TjdaSkuNewBusiness(**kwargs):

    logger.info("Invoked TjdaLocations def")

    dfjdasku = kwargs.get("df")

    columns = "item;loc;ohpost;replentype;replenmethod;u_inasso;u_range_start;u_range_end;u_plan_status;u_status;u_dfuview_sw;u_sku_sw;u_contract_eff;u_contract_disc;u_contract_id;u_contract_total;u_contract_remain;u_avgleadtime;u_leadtimesd;u_rptype_hema".split(";")
    oldColumns = dfjdasku.schema.names
    dfjdasku = reduce(lambda dfjdasku, idx: dfjdasku.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfjdasku)

    dfjdasku = dfjdasku.withColumn("filename_reverse", input_file_name())
    dfjdasku = dfjdasku.withColumn("filename_reverse", reverse(split(reverse(dfjdasku.filename_reverse), '/')[0]))

    dfjdasku = (
        dfjdasku.withColumn("creation_date", reverse(split(reverse(dfjdasku.filename_reverse), '_')[0]))
        .withColumn(
                            "creation_date",
                            expr(
                                "concat(substring(creation_date,1,4),'-', substring(creation_date,5,2),'-',substring(creation_date,7,2))").cast("date")
                                )                
        .withColumn("item", col("item").cast("bigint"))
        .withColumn("loc", col("loc").cast("bigint"))
        .withColumn("ohpost", col("ohpost").cast("date"))
        .withColumn("u_range_start", col("u_range_start").cast("date"))
        .withColumn("u_range_end", col("u_range_end").cast("date"))               
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("year", year("creation_date"))
        .withColumn("month", month("creation_date"))
        .withColumn("day", dayofmonth("creation_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse"))

    logger.info("End of jda locations def")
    
    return dfjdasku
