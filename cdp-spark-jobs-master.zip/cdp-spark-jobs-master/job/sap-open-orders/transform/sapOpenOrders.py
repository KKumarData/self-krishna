import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType,StringType,BooleanType,DateType
from utils.modules import logger
from functools import reduce
from datetime import datetime
from utils.sparkSession import SparkSessionFunc

# Instanciate Logger
logger = logger()


def TdfSapOpenOrders(**kwargs):

    logger.info("Invoked TdfSapOpenOrders def")
    
    dfSapOpenOrders = kwargs.get("df")
    period = kwargs.get("period")
    spark = kwargs.get("ss")
    
    columns = "type|order_id|order_type|date_orderline_created|source_plant|source_st_loc|source_type|destination_plant|destination_st_loc|destination_type|line_item_number|account_assignment|del_indicator|item|tracking_nr|ship_date|arrival_date|return|quantity|open_quantity|unit_of_measure|source_status|destination_status|allocation_status|producing_dc".split("|")
    
    oldColumns=dfSapOpenOrders.schema.names
    dfSapOpenOrders = reduce(lambda dfSapOpenOrders, idx: dfSapOpenOrders.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfSapOpenOrders)
    
    #Getting the file path:
    dfSapOpenOrders = dfSapOpenOrders.withColumn("input_file_name", input_file_name())

    #Casting Columns:
    dfSapOpenOrders = dfSapOpenOrders.withColumn("date_orderline_created", date_format(to_date(col("date_orderline_created"),"dd-MM-yyyy"),"yyyy-MM-dd").cast("date"))\
                                     .withColumn("ship_date", date_format(to_date(col("ship_date"),"dd-MM-yyyy"),"yyyy-MM-dd").cast("date"))\
                                     .withColumn("arrival_date", date_format(to_date(col("arrival_date"),"dd-MM-yyyy"),"yyyy-MM-dd").cast("date"))\
                                     .withColumn("quantity", col("quantity").cast("decimal(25,3)"))\
                                     .withColumn("open_quantity", col("open_quantity").cast("decimal(25,3)"))\
                                     .withColumn("return", when(col("return").isNull(), False).otherwise(True).cast("boolean"))

    #year,Month,Date Creation:
    dfSapOpenOrders = (dfSapOpenOrders.withColumn("period", date_format(to_date(lit(period),"yyyy/MM/dd"),"yyyy-MM-dd").cast('date'))
                                     .withColumnRenamed("period","ingestion_date")
                                     .withColumn("load_time", current_timestamp()))
    #Removing duplicates:
    dfSapOpenOrders = dfSapOpenOrders.dropDuplicates()
    #Final Select:
    dfSapOpenOrders = dfSapOpenOrders.select("type","order_id","order_type","date_orderline_created","source_plant","source_st_loc","source_type",
    "destination_plant","destination_st_loc","destination_type","line_item_number","account_assignment","del_indicator","item","tracking_nr","ship_date","arrival_date",
    "return","quantity","open_quantity","unit_of_measure","source_status","destination_status","allocation_status","producing_dc",
    "ingestion_date","load_time","input_file_name")

    logger.info("End of TdfSapOpenOrders def")
    
    return dfSapOpenOrders