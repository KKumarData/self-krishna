import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import * 
from pyspark.sql.types import *
from utils.modules import flatten_df, logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate the Log
logger = logger()


def TbazaarVoice(**kwargs):

    logger.info("Invoked TbazaarVoice def")

    dfbazaarVoice = kwargs.get("df")

    #Getting the Filename
    dfbazaarVoice = dfbazaarVoice.withColumn("ingestion_file", input_file_name())

    #Extracting from 1st array ratings:
    dfbazaarVoice=dfbazaarVoice.withColumn("ratings_",explode("ratings")).drop("ratings")
    #Converting ratings_ from struct:
    dfbazaarVoice = dfbazaarVoice.select("ratings_.*", "*").drop("ratings_")
    #Extracting only date:
    dfbazaarVoice = dfbazaarVoice.withColumn("filename", reverse(split(reverse(dfbazaarVoice.ingestion_file), '/')[0]))\
                                 .withColumn("creation_date", substring('filename',25,8))\
                                 .withColumn("creation_date",
                                  expr("concat(substring(creation_date,1,4),'-', substring(creation_date,5,2),'-',substring(creation_date,7,2))")
                                 .cast("date"))
    #Dropping unwanted columns:
    dfbazaarVoice = dfbazaarVoice.drop("filename")
    #Creation of new columns:
    dfbazaarVoice = dfbazaarVoice.withColumn("load_time", current_timestamp())\
                                 .withColumn("ingestion_date", current_date())\
                                 .withColumn("year", year("creation_date"))\
                                 .withColumn("month", month("creation_date"))\
                                 .withColumn("day", dayofmonth("creation_date"))
    #Renaming of Columns and casting:
    dfbazaarVoice = dfbazaarVoice.withColumnRenamed("productId","product_id")\
                                 .withColumnRenamed("baseProductId","base_product_id")\
                                 .withColumn("product_id", col("product_id").cast("bigint"))\
                                 .withColumn("amount", col("amount").cast("double"))
    #Final Select: 
    dfbazaarVoice = dfbazaarVoice.select("locale","average","amount","product_id","base_product_id",
                                        "ingestion_date","load_time","year","month","day","ingestion_file")
                                        
    logger.info("End of store stock def")
    
    return dfbazaarVoice
