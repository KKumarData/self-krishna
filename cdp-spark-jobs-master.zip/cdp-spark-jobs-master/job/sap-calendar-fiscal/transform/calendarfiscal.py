
from functools import reduce
from datetime import datetime
from utils.modules import logger
from pyspark.sql.window import Window
from pyspark.sql.functions import date_format, to_date, col, current_timestamp, current_date, year, month, dayofmonth, udf, dense_rank

logger = logger()


def TCalenFisc(**kwargs):

    logger.info('Invoked TCalenFisc def')

    df = kwargs.get("df")
    columns = "calday;calmonth;calmonth2;calquart1;calquarter;calweek;calyear;fiscper;fiscper3;fiscvarnt;fiscyear;weekday1;he_fiswk;he_fiswk2;halfyear1".split(";")

    oldColumns=df.schema.names
    df = reduce(lambda dfCalFis, idx: dfCalFis.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), df)
    
    windowSpec = Window.orderBy('calweek', year('calday'))

    df = (
                df
                .withColumn("calday",date_format(to_date(col("calday"), "dd-MM-yyyy"), "yyyy-MM-dd").cast("date")) 
                .withColumn("load_time",current_timestamp()) 
                .withColumn("ingestion_date",current_date()) 
                .withColumn("year", year(current_date())) 
                .withColumn("month", month(current_date())) 
                .withColumn("day", dayofmonth(current_date()))
                .withColumn("continuous_week_nr", dense_rank().over(windowSpec)) 
                )
    logger.info('End of TCalenFisc def')   

    return df
