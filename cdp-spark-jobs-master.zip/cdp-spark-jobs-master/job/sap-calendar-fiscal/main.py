import os
import sys
import inspect
from datetime import datetime
import ast
import sys

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir)

from threading import Thread
from utils.modules import logger
from utils.extractS3 import ReadS3
from multiprocessing.pool import ThreadPool
from transform.calendarfiscal import TCalenFisc
from utils.sparkSession import SparkSessionFunc

# Instanciate the Log
logger = logger()

# Start App
logger.info('Init of Main ')

def main (**kwargs):

    env = kwargs.get("env")
    app_name = kwargs.get("app_name")
    raw_bucket = kwargs.get("raw_path")
    curated_bucket = kwargs.get("curated_path")
    period = kwargs.get("execution_period")
    file_format = kwargs.get("file_format")
    job_mode = kwargs.get("job_mode")
    primary_key = kwargs.get("pk")

    # Create Spark Session
    logger.info('Create Spark Session')
    
    ss = SparkSessionFunc(app_name=app_name, env=env)

    from utils.writeS3_delta import WriteDelta

    # Load data from S3
    logger.info('Load data from S3')

    
    df = ReadS3(ss=ss, 
                env=env, 
                s3_bucket= raw_bucket + period,
                file_format= file_format, 
                load_type = job_mode,
                sep=";",
                period=period,
                header=True)
                   
    logger.info('End load process from S3')

    #Set Transformation Process using ThreadPool

    logger.info('Start Transformation process')
   
    pool = ThreadPool(processes=50)

    q1 = pool.apply_async(TCalenFisc, kwds={"df": df})
    dfFiscCal = q1.get()
    
    logger.info('Start Transformation process')
    
    t1 = Thread(
        target=WriteDelta,
        kwargs={
            "df": dfFiscCal,
            "bucket": curated_bucket,
            "ss": ss,
            "pk_column" : primary_key,
        },
    )

    t1.start()
    t1.join()
            
    logger.info('End Write process')


if __name__ == "__main__":

    env = sys.argv[1]
    app_name = sys.argv[2]
    raw_path = sys.argv[3]
    curated_path = sys.argv[4]
    execution_period = sys.argv[5]
    file_format = sys.argv[6]
    job_mode = sys.argv[7]
    pk = sys.argv[8]
    

    if 'delta' not in job_mode:
        for period in ast.literal_eval(execution_period):
            try:
                main(env=env, 
                app_name=app_name, 
                raw_path=raw_path, 
                curated_path=curated_path, 
                execution_period=period,
                file_format=file_format,
                job_mode=job_mode,
                pk=pk)
            except:
                pass
    else:
        main(env=env, 
                app_name=app_name, 
                raw_path=raw_path, 
                curated_path=curated_path, 
                execution_period=execution_period,
                file_format=file_format,
                job_mode=job_mode,
                pk=pk
                )