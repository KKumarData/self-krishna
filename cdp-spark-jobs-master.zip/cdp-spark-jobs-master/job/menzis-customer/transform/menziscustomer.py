import os
import logging 
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
import hashlib
from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql.functions import input_file_name

logger = logger()

def TMenzisCustomer(**kwargs):

    logger.info('Invoked TMenzisCustomer def')

    dfMenzCust = kwargs.get("df")

    columns = "insured_personnr;appointment_nr;appointment_name;age_of_birth;age;gender;voorletters;prefix;achternaam;startdate;enddate;policy_number;straatnaam;huis_nr;huis_nr_toevoeging;postal_code;city;basic_insurance;additional_insurance;dental_insurance;phone_number;e_mailadres;countrycode;customer_duration_label;type".split(";")
    oldColumns=dfMenzCust.schema.names
    dfMenzCust = reduce(lambda dfMenzCust, idx: dfMenzCust.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfMenzCust)
    
    dfMenzCust = dfMenzCust.withColumn("filename_reverse", input_file_name())
    dfMenzCust = dfMenzCust.withColumn("filename_reverse", reverse(split(reverse(dfMenzCust.filename_reverse), '/')[0]))

    salt = "@)@!-@)#!"
    
    dfMenzCust = dfMenzCust.withColumn('initials',sha2(concat_ws(salt, trim(dfMenzCust.voorletters)), 256),) \
                           .withColumn('surname',sha2(concat_ws(salt, trim(dfMenzCust.achternaam)), 256),) \
                           .withColumn('street',sha2(concat_ws(salt, trim(dfMenzCust.straatnaam)), 256),) \
                           .withColumn('house_number',sha2(concat_ws(salt, trim(dfMenzCust.huis_nr)), 256),) \
                           .withColumn("email_address", when(dfMenzCust.e_mailadres == "" ,"")
                                                       .when(dfMenzCust.e_mailadres.isNull() ,"" )
                                                       .otherwise(sha2(concat_ws(salt, trim(dfMenzCust.e_mailadres)), 256),)) \
                           .withColumn('house_nr_annex',sha2(concat_ws(salt, trim(dfMenzCust.huis_nr_toevoeging)), 256),) \
                           .withColumn("column_date", substring('filename_reverse',11,8)) \
                           .withColumnRenamed("column_date", "file_date") \
                           .withColumn(
                            "file_date",
                            expr(
                                "concat(substring(file_date,1,4),'-', substring(file_date,5,2),'-',substring(file_date,7,2))").cast("date")
                                ) \
                           .withColumn("load_time",current_timestamp()) \
                           .withColumnRenamed("file_date","ingestion_date") \
                           .withColumn("year", year("ingestion_date")) \
                           .withColumn("month", month("ingestion_date")) \
                           .withColumn("day", dayofmonth("ingestion_date")) \
                           .withColumnRenamed("filename_reverse","ingestion_file")
    dfMenzCust = dfMenzCust.select("insured_personnr","appointment_nr","appointment_name","age_of_birth","age","gender","initials","prefix","surname","startdate","enddate","policy_number","street","house_number","house_nr_annex","postal_code","city","basic_insurance","additional_insurance","dental_insurance","phone_number","email_address","countrycode","customer_duration_label","type","load_time","ingestion_date","ingestion_file","year","month","day")                  
    logger.info('End of TMenzisCustomer def')

    return dfMenzCust
