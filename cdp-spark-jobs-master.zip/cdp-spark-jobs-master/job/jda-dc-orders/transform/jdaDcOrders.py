import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TjdaDcOrders(**kwargs):

    logger.info("Invoked TjdaDcOrders def")

    dfjdaDcOrders = kwargs.get("df")

    #Renaimg of the default columnname:
    columns = "dummy_col_jdaDcOrders".split(";")
    oldColumns=dfjdaDcOrders.schema.names
    dfjdaDcOrders = reduce(lambda dfjdaDcOrders, idx: dfjdaDcOrders.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfjdaDcOrders)
    
    #Adding header dataframe:
    df_header = dfjdaDcOrders.limit(1).collect()
    df_header_row =  df_header[0][0]
    #Creation of columns:
    generation_date = df_header_row[2:10]
    generation_time = df_header_row[10:16]

    #Adding filename:
    dfjdaDcOrders = dfjdaDcOrders.withColumn("ingestion_file", input_file_name())
    #Creation of columns in detail:
    dfjdaDcOrders = dfjdaDcOrders.withColumn('rec_id', substring('dummy_col_jdaDcOrders',0,2))
    #Deletion of Header and trailor:
    dfjdaDcOrders = dfjdaDcOrders.filter(~dfjdaDcOrders.rec_id.isin(["00","02"]))

    #Creation of others columns in detail:
    dfjdaDcOrders = dfjdaDcOrders.withColumn('order_date', substring('dummy_col_jdaDcOrders',3,8))\
                                 .withColumn('dc_number', substring('dummy_col_jdaDcOrders',11,4))\
                                 .withColumn('article_number', substring('dummy_col_jdaDcOrders',15,18).cast("int"))\
                                 .withColumn('order_quantity', substring('dummy_col_jdaDcOrders',33,13))\
                                 .withColumn('delivery_date', substring('dummy_col_jdaDcOrders',46,8))\
                                 .withColumn('supplier_locs', substring('dummy_col_jdaDcOrders',54,10))\
                                 .withColumn('reference_number', substring('dummy_col_jdaDcOrders',64,10))\
                                 .withColumn("generation_date", lit(generation_date))\
                                 .withColumn("generation_time", lit(generation_time))                    
    #Dropping duplicate columns:                                        
    dfjdaDcOrders = dfjdaDcOrders.drop("dummy_col_jdaDcOrders")
    #Datatype Conversion:
    dfjdaDcOrders = dfjdaDcOrders.withColumn("order_date", date_format(to_date(col("order_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))\
                                 .withColumn("delivery_date", date_format(to_date(col("delivery_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))\
                                 .withColumn("generation_date", date_format(to_date(col("generation_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))\
                                 .withColumn("etl_date", date_format(to_date(col("generation_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))\
                                 .withColumn('order_quantity', regexp_replace(dfjdaDcOrders.order_quantity,'0','').cast("int"))
    #Datatype Conversion:
    dfjdaDcOrders = dfjdaDcOrders.withColumn("year", year(dfjdaDcOrders.etl_date))\
                                 .withColumn("month", month(dfjdaDcOrders.etl_date))\
                                 .withColumn("day",dayofmonth(dfjdaDcOrders.etl_date))
    #Final Select:
    dfjdaDcOrders = dfjdaDcOrders.select("rec_id","order_date","dc_number","article_number","order_quantity","delivery_date",
                                         "supplier_locs","reference_number","generation_date","generation_time",
                                         "etl_date","ingestion_file","year","month","day")
    logger.info("End of jda Inter dc orders def")
    return dfjdaDcOrders