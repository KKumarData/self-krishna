import os
import logging 
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType 
from utils.modules import logger

# Instanciate Logger
logger = logger()

def TSalesBudWeekly(**kwargs):

    logger.info('Invoked TSalesBudWeekly def')

    dfBudgetWeekly = kwargs.get("df")
    
    dfBudgetWeekly = dfBudgetWeekly.withColumnRenamed("CALMONTH","cal_month") \
                           .withColumnRenamed("CALMONTH2","cal_month2") \
                           .withColumnRenamed("CALWEEK","calendar_week") \
                           .withColumnRenamed("SALES_UNIT","sales_unit") \
                           .withColumnRenamed("BASE_UOM","quantity_unit") \
                           .withColumnRenamed("LOC_CURRCY","local_currency") \
                           .withColumnRenamed("DOC_CURRCY","document_currency") \
                           .withColumnRenamed("HERHFG","headgroup") \
                           .withColumnRenamed("PLANT","store") \
                           .withColumnRenamed("HERSSUPL","supplier") \
                           .withColumnRenamed("RT_ASORT","assortment") \
                           .withColumnRenamed("RT_ASSGRAD","assortmentgrade_store") \
                           .withColumnRenamed("COMP_CODE","company_code") \
                           .withColumnRenamed("SALESORG","sales_organization") \
                           .withColumnRenamed("DISTR_CHAN","distribution_chain") \
                           .withColumnRenamed("VTYPE","valuetype") \
                           .withColumnRenamed("HERACTIND","promo_indicator") \
                           .withColumnRenamed("MOVE_PLANT","moving_store") \
                           .withColumnRenamed("HELPPL","pull_stream") \
                           .withColumnRenamed("ZCURTYPE","currency_type") \
                           .withColumnRenamed("CPBAINSASU","sales_pieces") \
                           .withColumnRenamed("CPBAINSABU","sales_sku") \
                           .withColumnRenamed("RTBAINSAST","gross_sales") \
                           .withColumnRenamed("RTBAINSASV","net_sales") \
                           .withColumnRenamed("CPBAINSAPV","costprice_sales") \
                           .withColumnRenamed("HERFICT","theoretical_gross_sales") \
                           .withColumnRenamed("RTPRINSAST","theoretical_promo_sales") \
                           .withColumnRenamed("CPBAINSANI","sales_items") \
                           .withColumnRenamed("HERPVWINK","store_markdown") \
                           .withColumnRenamed("HERPVACT","promo_markdown") \
                           .withColumnRenamed("CPRETORDNI","returned_items") \
                           .withColumnRenamed("CPRETORDBU","returned_sku") \
                           .withColumnRenamed("CPRETORDPV","costprice_returns") \
                           .withColumnRenamed("CPRETORDSU","returned_salesunits") \
                           .withColumnRenamed("RTRETORDST","returns_gross_sales") \
                           .withColumnRenamed("RTRETORDSV","returns_net_sales") \
                           .withColumnRenamed("CPSAEXCUSU","deliverysales_salesunits") \
                           .withColumnRenamed("CPSAEXCUBU","deliverysales_sku") \
                           .withColumnRenamed("RTSAEXCUST","deliverysales_gross") \
                           .withColumnRenamed("RTSAEXCUSV","deliverysales_net") \
                           .withColumnRenamed("CPSAEXCUPV","costprice_deliverysales") \
                           .withColumnRenamed("HERDVERG","service_fee") \
                           .withColumnRenamed("HERGRMARG","gross_margin_calc") \
                           .withColumnRenamed("HERRABAT","rabat") \
                           .withColumnRenamed("CPSAEXCUNI","sales_abs_position_numbers") \
                           .withColumnRenamed("NETVAL_INV","net_value") \
                           .withColumnRenamed("GROSS_VAL","gross_value") \
                           .withColumnRenamed("HERDPVPVP","def_markdown_pos_salesprice") \
                           .withColumnRenamed("HERUGVKP0","outbound_salesprice") \
                           .withColumnRenamed("HERSTTST","stock_orig_price") \
                           .withColumnRenamed("HERAGVKP0","inbound_salesprice") \
                           .withColumnRenamed("HERDPVMVP","def_markdown_neg_salesprice") \
                           .withColumnRenamed("HERCAINH","inbound_costprice_dc") \
                           .withColumnRenamed("HERCAVKP","inbound_salesprice_ex_dc") \
                           .withColumnRenamed("HERCAVKP0","inbound_salesprice_DC") \
                           .withColumnRenamed("HERNCBUD","netcalculation") \
                           .withColumnRenamed("HERDUGWVI","DC_outbound_store_salesprice") \
                           .withColumnRenamed("HERDAGWVI","DC_inbound_storereturn_salesprice") \
                           .withColumnRenamed("HERWAGDVI","Store_inbound_DC_salesprice") \
                           .withColumnRenamed("HERBUDACT","promo_sales") \
                           .withColumnRenamed("HEROSBUD","turnover_rate") \
                           .withColumnRenamed("HERVRDCOR","stock_corrections_nrs") \
                           .withColumnRenamed("INVOICES","tickets") \
                           .withColumnRenamed("HERBUDWSH","webshop_sales") \
                           .withColumnRenamed("HERDVPCT","loss_percentage") \
                           .withColumnRenamed("HERMSFB","msf_budget") \
                           .withColumnRenamed("HERCLMD","clearance_markdown") \
                           .withColumnRenamed("HERCLMDAB","clearance_markdown_ab") \
                           .withColumnRenamed("HERBUOCC","click_collect_sales") \
                           .withColumnRenamed("HERBUOHD","homedelivery_sales") \
                           .withColumnRenamed("HERBUOST","store_sales") \
                           .withColumn("load_time",current_timestamp()) \
                           .withColumn("ingestion_date",current_date()) \
                           .withColumn("year", year(current_date())) \
                           .withColumn("month", month(current_date())) \
                           .withColumn("day", dayofmonth(current_date())) \
                           

        
    logger.info('End of TSalesBudWeekly def')

    return dfBudgetWeekly