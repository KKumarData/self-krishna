from utils.modules import logger
from datetime import timedelta, datetime
from pyspark.sql.functions import col, first, to_date, lit
from pyspark.sql.types import StructType, StructField, IntegerType, StringType

logger = logger()

def t_loyalty_dashboard(**kwargs):
    loy_mem_wk_df = kwargs.get("loy_mem_wk_df")
    fisc_cal_df  = kwargs.get("fisc_cal_df")
    etl_date_str = kwargs.get("etl_date")
    etl_date = datetime.strptime(etl_date_str, '%Y/%m/%d').date()
    spark = kwargs.get("ss")

    logger.info("Setting up empty loyalty dashboard dataframe")
    columns = ['etl_date', 'year', 'month', 'day', 'calweek','total_plastic_cards_over_time', 'new_plastic_cards_per_period']
    loy_dashboard_struct_cols = list()
    loy_dashboard_struct_cols.append(StructField('etl_date', StringType(), True))
    for column in columns[1:]:
        loy_dashboard_struct_cols.append(StructField(column, IntegerType(), False))
    loyalty_dashboard_schema  = StructType(loy_dashboard_struct_cols)

    logger.info("Calculating current calweek")
    loy_cal = fisc_cal_df.alias('fisc_cal').where(col('fisc_cal.calday') == (etl_date - timedelta(days=1))).select('fisc_cal.calday', 'fisc_cal.calweek')
    calweek = loy_cal.select('calweek').collect()[0].calweek

    logger.info("Calculating metrics")
    total_plastic_cards = loy_mem_wk_df.where(col('plastic_card_ind')==1).groupBy('hema_id').agg(first('hema_id')).count()

    new_plastic_cards_for_period = (
        loy_mem_wk_df
        .where(
            (col('calweek')==calweek) 
            & (col('plastic_card_ind')==1)
            &(col('new_member_ind')==1)
        )
        .groupBy('hema_id')
        .agg(first('hema_id'))
        .count()

    )

    logger.info("Assigning values to empty loyalty dashboard dataframe")
    loyalty_dashboard_df = (
        spark.createDataFrame(
            [
                (
                etl_date_str,
                etl_date.year, 
                etl_date.month, 
                etl_date.day, 
                int(calweek), 
                total_plastic_cards, 
                new_plastic_cards_for_period
                )
            ], 
            loyalty_dashboard_schema)
        )


    loyalty_dashboard_df = loyalty_dashboard_df.withColumn('etl_date', to_date(lit(etl_date_str), 'yyyy/MM/dd'))
    return loyalty_dashboard_df, calweek

