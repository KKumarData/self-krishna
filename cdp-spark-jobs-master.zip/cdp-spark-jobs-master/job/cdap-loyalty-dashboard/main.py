import os
import sys
import sys
import inspect


currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

from utils.modules import logger
from utils.extractS3 import ReadS3
from pyspark.sql.functions import col
from utils.sparkSession import SparkSessionFunc
from transform.transform import t_loyalty_dashboard

logger = logger()

logger.info("Init of Main ")

def main(**kwargs):
	env = kwargs.get("env")
	app_name = kwargs.get("app_name")
	loyalty_dashboard_path = kwargs.get("loyalty_dashboard_path")
	loyalty_members_week_path = kwargs.get("loyalty_members_week_path")
	fisc_cal_path = kwargs.get("fisc_cal_path")
	etl_date = kwargs.get("etl_date")

	logger.info("Create Spark Session")

	ss = SparkSessionFunc(app_name=app_name, env=env)

	from delta.tables import DeltaTable

	if env == 'local':
		loyalty_dashboard_path = currentdir+'/'+loyalty_dashboard_path

	logger.info("Loading loyalty dashboard Delta Table")
	if DeltaTable.isDeltaTable(ss, loyalty_dashboard_path):
		loyalty_dashboard_dt = DeltaTable.forPath(loyalty_dashboard_path)
		logger.info("Delta table exists")
	else:
		logger.info("Delta table does not exist")
		loyalty_dashboard_dt = None
	logger.info("Loading loyalty dashboard Delta Table - DONE")

	logger.info("Loading CDAP loyalty members week Dataframe")
	loyalty_mem_wk_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=loyalty_members_week_path,
		file_format='parquet'
	)
	logger.info("Loading CDAP loyalty members week Dataframe - DONE")

	logger.info("Loading HEMA fiscal calendar Dataframe")
	fisc_cal_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=fisc_cal_path,
		file_format='delta'
	)
	logger.info("Loading HEMA fiscal calendar Dataframe - DONE")


	logger.info("Start loyalty-dashboard transformation process")

	loyalty_dashboard_df, calweek = t_loyalty_dashboard(
		fisc_cal_df=fisc_cal_df,
		loy_mem_wk_df=loyalty_mem_wk_df,
		etl_date=etl_date,
		ss=ss
		)
	logger.info("End loyalty-dashboard transformation process")

	logger.info("Start loyalty-dashboard write process")
	if not(loyalty_dashboard_dt is None):
		logger.info(f"Deleting data from delta table for calweek {calweek}")
		loyalty_dashboard_dt.delete(col('calweek')==calweek)

		logger.info("Performing upsert operation")
		loyalty_dashboard_dt.alias('dt').merge(
			source=loyalty_dashboard_df.alias('df'),
			condition='dt.calweek = df.calweek'
		).whenNotMatchedInsertAll().execute()

		logger.info("Starting Symlink Manifest Re-Generation " + loyalty_dashboard_path) 
		loyalty_dashboard_dt.generate("symlink_format_manifest")
	else:
		logger.info("Saving to S3 via dataframe, not upsert")

		loyalty_dashboard_df.show(truncate=False)

		loyalty_dashboard_df.write.format("delta").partitionBy('calweek').option(
                    "mergeSchema", "true"
                ).save(loyalty_dashboard_path)

		logger.info("End write process to S3 " + loyalty_dashboard_path)

		# Read Path with Delta Objects
		logger.info("Read Path with Delta Objects " + loyalty_dashboard_path)

		loyalty_dashboard_dt = DeltaTable.forPath(ss, loyalty_dashboard_path)

		# Starting Symlink Manifest Generation
		logger.info("Starting Symlink Manifest Generation " + loyalty_dashboard_path) 

		loyalty_dashboard_dt.generate("symlink_format_manifest")

		# End Symlink Manifest Generation
		logger.info("End Symlink Manifest Generation " + loyalty_dashboard_path)

	logger.info("End loyalty-dashboard write process")


if __name__ == "__main__":
	main(
		env=sys.argv[1],
		app_name=sys.argv[2],
		loyalty_dashboard_path=sys.argv[3],
		loyalty_members_week_path=sys.argv[4],
		etl_date=sys.argv[5],
		fisc_cal_path=sys.argv[6]
	)
