import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import *
from utils.modules import flatten_df, logger

# Instanciate Logger
logger = logger()


def TsapB2bCustomer(**kwargs):

    logger.info("Invoked Products def")

    dfsapB2bCustomer = kwargs.get("df")
    #Getting the file path:
    dfsapB2bCustomer = dfsapB2bCustomer.withColumn("input_file_name", input_file_name())
    #Removing the struct IDOC:
    dfsapB2bCustomer = dfsapB2bCustomer.select("IDOC.*", "*").drop("IDOC")
    #Removing the struct E1KNA1M:
    dfsapB2bCustomer = dfsapB2bCustomer.select("E1KNA1M.*","*").drop("E1KNA1M")
    #Removing the struct E1KNA1M:
    dfsapB2bCustomer = dfsapB2bCustomer.select("EDI_DC40.*","*").drop("EDI_DC40")
    #Assiging columns to a list:
    list_columns=dfsapB2bCustomer.columns
  
    #For handling dynamic schema of XML File:  
    if "BEGRU" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("BEGRU","authorization_group")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("authorization_group",lit(""))
    if "MSGFN" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("MSGFN","msg_function")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("msg_function",lit(""))
    if "KUNNR" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("KUNNR","customer_id")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("customer_id",lit(""))
    if "BBBNR" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("BBBNR","location_part1")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("location_part1",lit(""))
    if "BBSNR" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("BBSNR","location_part2")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("location_part2",lit(""))
    if "BUBKZ" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("BUBKZ","check_digit")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("check_digit",lit(""))
    if "KTOKD" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("KTOKD","account_group")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("account_group",lit(""))
    if "LAND1" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("LAND1","country")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("country",lit(""))
    if "NAME1" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("NAME1","name")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("name",lit(""))
    if "ORT01" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("ORT01","city")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("city",lit(""))
    if "PSTLZ" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("PSTLZ","zipcode")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("zipcode",lit(""))
    if "SORTL" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("SORTL","sort_field")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("sort_field",lit(""))
    if "SPRAS" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("SPRAS","language_key")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("language_key",lit(""))
    if "STRAS" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("STRAS","house_no_street")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("house_no_street",lit(""))
    if "STRAS" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("STRAS","house_no_street")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("house_no_street",lit(""))
    if "LZONE" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("LZONE","land_zone")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("land_zone",lit(""))
    if "WERKS" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("WERKS","old_store_id")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("old_store_id",lit(""))
    if "NAME4" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("NAME4","store_id")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("store_id",lit(""))
    if "KDGRP" in list_columns:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("KDGRP","customer_group")
    else:
        dfsapB2bCustomer = dfsapB2bCustomer.withColumn("customer_group",lit(""))

    #Renaming the column:
    dfsapB2bCustomer = dfsapB2bCustomer.withColumnRenamed("CREDAT","edi_c40_creation_date")\
                                       .withColumnRenamed("CRETIM","edi_c40_creation_time")\
                                       .withColumnRenamed("SERIAL","edi_c40_serial")\
                                       .withColumn("ingestion_frequency",lit(""))
    #Adding year,month,date:
    dfsapB2bCustomer = dfsapB2bCustomer.withColumn("year", substring("edi_c40_creation_date",0,4).cast("int"))\
                                       .withColumn("month", substring("edi_c40_creation_date",5,2).cast("int"))\
                                       .withColumn("day",substring("edi_c40_creation_date",7,2).cast("int"))\
                                       .withColumn("load_time", current_timestamp())\
                                       .withColumn("ingestion_date", current_date())
    #Converting Datatype:
    dfsapB2bCustomer = dfsapB2bCustomer.withColumn("edi_c40_creation_date",col("edi_c40_creation_date").cast("int"))\
                                       .withColumn("edi_c40_creation_time",col("edi_c40_creation_time").cast("int"))\
                                       .withColumn("edi_c40_serial",col("edi_c40_serial").cast("bigint"))
    #Converting Datatype:
    dfsapB2bCustomer = dfsapB2bCustomer.withColumn("load_time",col("load_time").cast(StringType()))\
                                       .withColumn("ingestion_date", col("ingestion_date").cast(StringType()))
    #Derived Columns:
    dfsapB2bCustomer = dfsapB2bCustomer.withColumn("gln",concat("location_part1","location_part2","check_digit").cast("bigint"))\
                                       .withColumn("store_id_derived", when(col("country")=='MX',col("customer_id").cast("int").cast(StringType()))
                                       .otherwise(col("store_id")))

    #Final Select:
    dfsapB2bCustomer = dfsapB2bCustomer.select("msg_function","customer_id","customer_group","location_part1","location_part2","gln",
                                               "check_digit","account_group","name","city","zipcode","sort_field","language_key","house_no_street",
                                               "country","land_zone","store_id_derived","input_file_name","load_time","ingestion_frequency",
                                               "ingestion_date","old_store_id","authorization_group","edi_c40_creation_date",
                                               "edi_c40_creation_time","edi_c40_serial","year","month","day")

    logger.info("End of TsapProductMaster def")
    return dfsapB2bCustomer
