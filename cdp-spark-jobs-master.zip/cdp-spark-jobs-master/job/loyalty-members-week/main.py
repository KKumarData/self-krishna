import os
import sys
import ast
import sys
import boto3
import shutil
import inspect
from os import path
from pathlib import Path

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

from threading import Thread
from utils.modules import logger
from utils.writeS3 import WriteS3
from utils.extractS3 import ReadS3
from multiprocessing.pool import ThreadPool
from utils.sparkSession import SparkSessionFunc
from transform.transform import transform_loy_member_wk

logger = logger()

logger.info("Init of Main ")

def main(**kwargs):
	env = kwargs.get("env")
	app_name = kwargs.get("app_name")
	fisc_cal_path = kwargs.get("fisc_cal")
	loy_trx_path = kwargs.get("loy_trx")
	test_users_path = kwargs.get("test_users")
	loy_cards_path = kwargs.get("loy_cards")
	prof_optin_path = kwargs.get("prof_optin")
	prof_address_path = kwargs.get("prof_address")
	prof_user_path = kwargs.get("prof_user")
	loy_mem_wk_path = kwargs.get("loy_mem_wk")
	fisc_cal_wk_path = kwargs.get("fisc_cal_wk")
	etl_date = kwargs.get("etl_date")

	logger.info("Create Spark Session")

	ss = SparkSessionFunc(app_name=app_name, env=env)

	# from utils.writeS3_delta import WriteDelta

	if env == 'local':
		loy_mem_wk_path = currentdir+'/'+loy_mem_wk_path+'-temp'

	logger.info(f"Load Fiscal Calendar from S3 {fisc_cal_path}")

	fisc_cal_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=fisc_cal_path,
		file_format='delta'
	)

	logger.info("End load process Fiscal Calendar from S3")

	logger.info(f"Load Loyalty Transactions from S3 {loy_trx_path}")

	loy_trx_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=loy_trx_path,
		file_format='delta'
	)

	logger.info("End load process Loyalty Transactions from S3")

	logger.info(f"Load Intersolve Excluded Test Users from S3 {test_users_path}")

	test_users_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=test_users_path,
		file_format='csv',
		header=True,
		sep='|'
	)

	logger.info("End load process Intersolve Excluded Test Users from S3")

	logger.info(f"Load Loyalty Cards from S3 {loy_cards_path}")

	loy_cards_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=loy_cards_path,
		file_format='delta'
	)

	logger.info("End load process Loyalty Cards from S3")

	logger.info(f"Load Selligence Optin from S3 {prof_optin_path}")

	prof_optin_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=prof_optin_path,
		file_format='delta'
	)

	logger.info("End load process Selligence Optin from S3")

	logger.info(f"Load SFCC Customer Address from S3 {prof_address_path}")

	prof_address_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=prof_address_path,
		file_format='delta'
	)

	logger.info("End load process SFCC Customer Address from S3")

	logger.info(f"Load SFCC Customer from S3 {prof_user_path}")

	prof_user_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=prof_user_path,
		file_format='delta'
	)

	logger.info("End load process SFCC Custome from S3")
	
	logger.info(f"Load Loyalty Member Week from S3 {loy_mem_wk_path}")

	loy_mem_wk_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=loy_mem_wk_path,
		file_format='parquet'
	)

	logger.info("End load process Loyalty Member Week from S3")

	logger.info(f"Load Fiscal Calendar Week from S3 {fisc_cal_wk_path}")

	fisc_cal_wk_df = ReadS3(
		ss=ss,
		env=env,
		s3_bucket=fisc_cal_wk_path,
		file_format='delta'
	)

	logger.info("End load process Fiscal Calendar Week from S3")

	logger.info("Start loyalty-member-week transformation process")

	loyalty_member_week_df = transform_loy_member_wk(
		fisc_cal=fisc_cal_df,
		loyalty_transactions=loy_trx_df,
		intersolve_test_users=test_users_df,
		loyalty_cards=loy_cards_df,
		profile_optin=prof_optin_df,
		customer_address=prof_address_df,
		customer_profile=prof_user_df,
		loyalty_member_week=loy_mem_wk_df,
		fisc_cal_wk=fisc_cal_wk_df,
		ingestion_date=etl_date
		)

	logger.info("End loyalty-member-week transformation process")

	logger.info("Start loyalty-member-week DF write process")
	WriteS3(
		ss=ss,
		bucket=loy_mem_wk_path+'-temp',
		df=loyalty_member_week_df,
		flag_partition=False,
		job_mode="full"
	)
	# loyalty_member_week_df.show()

	logger.info("End loyalty-member-week DF write write process")


if __name__ == "__main__":
	main(
		env=sys.argv[1],
		app_name=sys.argv[2],
		fisc_cal=sys.argv[3],
		loy_trx=sys.argv[4],
		etl_date=sys.argv[5],
		test_users=sys.argv[6],
		loy_cards=sys.argv[7],
		prof_optin=sys.argv[8],
		prof_address=sys.argv[9],
		prof_user=sys.argv[10],
		loy_mem_wk=sys.argv[11],
		fisc_cal_wk=sys.argv[12],
	)
