
from utils.modules import logger
from pyspark.sql.window import Window
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from pyspark.sql.functions import col, coalesce, to_date, count, substring, when, lit, row_number, regexp_replace

logger = logger()

def transform_loy_member_wk(**kwargs):

	logger.info("Invoked transform_calendar_wk def")

	fisc_cal = kwargs.get("fisc_cal")
	loy_trx = kwargs.get("loyalty_transactions")
	test_users = kwargs.get("intersolve_test_users")
	loy_cards = kwargs.get("loyalty_cards")
	prof_optin = kwargs.get("profile_optin")
	prof_address = kwargs.get("customer_address")
	prof_user = kwargs.get("customer_profile")
	loy_mem_wk = kwargs.get("loyalty_member_week")
	fisc_cal_wk = kwargs.get("fisc_cal_wk")
	etl_date_str = kwargs.get("ingestion_date")
	etl_date = datetime.strptime(etl_date_str, '%Y/%m/%d').date()


	loy_cards_win_spec = Window.partitionBy("hema_customer_id", "card_id").orderBy(col("load_time").desc())
	loy_cards = (
					loy_cards
					.withColumn("row_num", row_number().over(loy_cards_win_spec))
					.where(col('row_num')==1)

				)
		

	loy_calday = fisc_cal.alias('fisc_cal').where(col('fisc_cal.calday') == (etl_date - timedelta(days=1))).select('fisc_cal.calday', 'fisc_cal.calweek')

	loy_calday_calweeks = [int(row.calweek) for row in loy_calday.collect()]
	intersolve_excluded_test_user_ids = [row.UserID for row in test_users.collect()]

	if not('etl_date' in loy_mem_wk.columns):
		loy_mem_wk = loy_mem_wk.withColumn('etl_date', lit('').cast('date'))

	cust_curr_wk = (
		prof_user
		.where((col('optin_loyalty')=='True') & (~col('hema_customer_id').isin(intersolve_excluded_test_user_ids)))
		.select(col('hema_customer_id').alias('hema_id'), col('verzekerde_nr').alias('insurance_ind'))
	)

	loy_buy_trx_last_yr = (
		loy_trx
		.where(
				(to_date('transaction_date_time').between(etl_date-relativedelta(months=12), etl_date))
				& (col('scheme_id')==1)
			)
		.groupBy('hema_customer_id')
		.agg(count('hema_customer_id').alias('hema_customer_id_count'))
		.where(col('hema_customer_id_count')>1)
		.drop('hema_customer_id_count')
	)

	loy_buy_trx_last_wk = (
		loy_trx.
		where(
			(col('scheme_id') == 1)
			& (to_date('transaction_date_time') >= '2019-01-01')
		)
		.join(fisc_cal.alias('fisc_cal'), to_date('transaction_date_time')==col('fisc_cal.calday'), 'inner')
		.join(loy_calday.alias('loy_cal'), col('fisc_cal.calweek')==col('loy_cal.calweek'), 'inner')
		.groupBy('hema_customer_id')
		.agg(count('hema_customer_id').alias('hema_customer_id_count'))
		.where(col('hema_customer_id_count')>1)
		.drop('hema_customer_id_count')
	)

	bonus_pts_reg = (
		loy_trx
		.where(
			(to_date('transaction_date_time') >= '2019-01-01')
			&(col('loyalty_transaction_type')=='Issue')
			&((col('client_ref')=='LoyaltyRegistration') | (substring('client_ref', 1, 4).between('B000', 'B100')) | (substring('client_ref', 1, 3)=='CSP'))
		)
		.join(fisc_cal.alias('fisc_cal'), to_date('transaction_date_time')==col('fisc_cal.calday'), 'inner')
		.join(loy_calday.alias('loy_cal'), col('fisc_cal.calweek')==col('loy_cal.calweek'), 'inner')
		.groupBy('hema_customer_id')
		.sum('loyalty_value')
		.withColumnRenamed('sum(loyalty_value)', 'loyalty_value')
	)

	all_cust_cards = (
		loy_cards
		.where(
			(col('status')=='Normal')
			&(col('hema_customer_id').isNotNull())
		)
		.withColumn('plastic_card_ind', when(col('card_id').like('606436171%'), lit(1)).otherwise(lit(0)))
		.withColumn('digital_card_ind', when(col('card_id').like('606436172%'), lit(1)).otherwise(lit(0)))
		.groupBy('hema_customer_id')
		.max('plastic_card_ind', 'digital_card_ind')
		.select('hema_customer_id', col('max(digital_card_ind)').alias('digital_card_ind'), col('max(plastic_card_ind)').alias('plastic_card_ind'))
		.where(
			(col('plastic_card_ind')==1)
			|(col('digital_card_ind')==1)
		)
	)

	optin_info = (
		prof_optin
		.where(col('opt_int')==1)
		.withColumn('loyaltymail_optin_ind', when(col('optin_type')=='Loyalty', lit(1)).otherwise(lit(0)))
		.withColumn('hemamail_optin_ind', when(col('optin_type')=='Webshop', lit(1)).otherwise(lit(0)))
		.groupBy("hema_customer_id")
		.max('loyaltymail_optin_ind', 'hemamail_optin_ind')
		.select('hema_customer_id', col('max(hemamail_optin_ind)').alias('hemamail_optin_ind'), col('max(loyaltymail_optin_ind)').alias('loyaltymail_optin_ind'))
	)

	cust_country_temp = (
		prof_address
		.where(
			(col('country_code')!=',,')
			&(col('country_code')!='')
			&(col('country_code').isNotNull())
		)
		.groupBy('hema_customer_id', 'country_code')
		.agg(count('country_code'))
		.withColumnRenamed('count(country_code)', 'country_code_count')
	)

	cust_country_temp2 = (
		cust_country_temp
		.groupBy('hema_customer_id')
		.max('country_code_count')
		.withColumnRenamed('max(country_code_count)', 'max_country_code_count')
	)

	cust_country = (
		cust_country_temp
		.join(
			cust_country_temp2,
			(cust_country_temp.hema_customer_id==cust_country_temp2.hema_customer_id)
			&(cust_country_temp.country_code_count==cust_country_temp2.max_country_code_count)
			,'inner'
		)
		.select(cust_country_temp.hema_customer_id, cust_country_temp.country_code)
	)


	loy_mem_wk = (
		loy_mem_wk
		.where(
		(~col('calweek').isin(loy_calday_calweeks))
		&(~col('hema_id').isin(intersolve_excluded_test_user_ids))
		)
	)


	loy_mem_wk_temp = (
		loy_mem_wk.alias('l')
		.join(fisc_cal_wk.alias('cal_wk'), col('l.calweek')==col('cal_wk.calweek_previous'), 'inner')
		.join(loy_calday.alias('pl'), col('pl.calweek')==col('cal_wk.calweek'), 'inner')
		.join(cust_curr_wk.alias('po'), col('l.hema_id')==col('po.hema_id'), 'full')
		.join(loy_cards.alias('ic'), regexp_replace(col('l.hema_id'), '[{|}]', '')==col('ic.card_id'), 'left')
		.join(loy_buy_trx_last_yr.alias('it'), col('l.hema_id')==col('it.hema_customer_id'), 'left')
		.join(loy_buy_trx_last_wk.alias('itweek'), col('l.hema_id')==col('itweek.hema_customer_id'), 'left')
		.join(bonus_pts_reg.alias('itw'), col('l.hema_id')==col('itw.hema_customer_id'), 'left')
		.join(all_cust_cards.alias('card_ind'), col('l.hema_id')==col('card_ind.hema_customer_id'), 'left')
		.join(optin_info.alias('u'), col('u.hema_customer_id')==col('l.hema_id'), 'left')
		.join(cust_country.alias('a'), col('l.hema_id')==col('a.hema_customer_id'), 'left')
		.crossJoin(loy_calday.alias('p'))
		.select(
			coalesce(col('po.hema_id'), col('l.hema_id')).alias('hema_id')
			,col('p.calweek').alias('calweek')
			,coalesce(col('a.country_code'), lit('NL')).alias('country')
			,when(col('ic.balance').isNull(), lit(0)).otherwise(col('ic.balance')).alias('balance')
			,when(col('itw.loyalty_value').isNull(), lit(0)).otherwise(col('itw.loyalty_value')).alias('bonus_points_issued')
			,when(
				(col('l.hema_id').isNotNull())
				&(col('po.hema_id').isNull()) 
				&(col('l.loy_optout_ind')==1), 
			1).otherwise(0).alias('new_optout_ind')
			,when(col('l.hema_id').isNull(), lit(1)).otherwise(lit(0)).alias('new_member_ind')
			,when(col('po.hema_id').isNull(), lit(1)).otherwise(lit(0)).alias('loy_optout_ind')
			,when(col('it.hema_customer_id').isNotNull() & col('po.hema_id').isNotNull(), lit(1)).otherwise(lit(0)).alias('active_cust_ind')
			,when(col('it.hema_customer_id').isNull() & col('po.hema_id').isNotNull(), lit(1)).otherwise(lit(0)).alias('inactive_cust_ind')
			,when(col('itweek.hema_customer_id').isNotNull() & col('po.hema_id').isNotNull(), lit(1)).otherwise(lit(0)).alias('cw_active_cust_ind')
			,when(col('itweek.hema_customer_id').isNull() & col('po.hema_id').isNotNull(), lit(1)).otherwise(lit(0)).alias('cw_inactive_cust_ind')
			,when(
				(when(
					col('card_ind.plastic_card_ind').isNull(), 0).otherwise(col('card_ind.plastic_card_ind')
				)==1)
				&(when(
					col('card_ind.digital_card_ind').isNull(), 0).otherwise(col('card_ind.digital_card_ind')
				)==0)
				,lit(1)
			).otherwise(lit(0)).alias('plastic_card_ind')
			,when(
				(when(
					col('card_ind.plastic_card_ind').isNull(), 0).otherwise(col('card_ind.plastic_card_ind')
				)==0)
				&(when(
					col('card_ind.digital_card_ind').isNull(), 0).otherwise(col('card_ind.digital_card_ind')
				)==1)
				,lit(1)
			).otherwise(lit(0)).alias('digital_card_ind')
			,when(
				(when(
					col('card_ind.plastic_card_ind').isNull(), lit(0)).otherwise(col('card_ind.plastic_card_ind')
				)==1)
				&(when(
					col('card_ind.digital_card_ind').isNull(), lit(0)).otherwise(col('card_ind.digital_card_ind')
				)==1)
				,lit(1)
			).otherwise(lit(0)).alias('combination_cards_ind')
			,when(col('card_ind.hema_customer_id').isNull(), lit(1)).otherwise(lit(0)).alias('virtual_card_only_ind')
			,when(
				(col('po.hema_id').isNotNull()) 
				& (col('u.loyaltymail_optin_ind')==1)
				,lit(1)
			).otherwise(lit(0)).alias('loyaltymail_optin_ind')
			,when(
				(col('po.hema_id').isNotNull()) 
				& (coalesce(col('u.loyaltymail_optin_ind'),lit(0))==0)
				,lit(1)
			).otherwise(lit(0)).alias('loyaltymail_optout_ind')
			,when(
				(col('po.hema_id').isNotNull()) 
				& (col('u.hemamail_optin_ind')==1)
				,lit(1)
			).otherwise(lit(0)).alias('hemamail_optin_ind')
			,when(
				(col('po.hema_id').isNotNull()) 
				& (coalesce(col('u.hemamail_optin_ind'), lit(0))==0)
				,lit(1)
			).otherwise(lit(0)).alias('hemamail_optout_ind')
			,coalesce(col('po.insurance_ind'),lit(0)).alias('insurance_ind')
		)
	).withColumn('etl_date', to_date(lit(etl_date_str), 'yyyy/MM/dd'))

	loy_mem_wk_temp = loy_mem_wk_temp.drop_duplicates()
	loy_mem_wk = loy_mem_wk.unionByName(loy_mem_wk_temp)

	return loy_mem_wk