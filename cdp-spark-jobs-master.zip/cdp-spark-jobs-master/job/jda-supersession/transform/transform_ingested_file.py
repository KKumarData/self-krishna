from utils.modules import logger
from pyspark.sql.functions import lit, when, col, substring, lpad, to_date, year, month, dayofmonth

logger = logger()

def transform_jda_supersession(**kwargs):

    logger.info("Invoked TjdaPlanningDaily def")

    df = kwargs.get("df")
    df_collection = df.collect()
    header_row = df_collection[0][0]
    trail_row = df_collection[-1][0]
    ingestion_date = header_row[2:10]
    df = df.filter(~df._c0.isin([header_row, trail_row]))

    df = (
        df.withColumn("ETL_DATE", to_date(lit(ingestion_date), 'yyyyMMdd'))
        .withColumn("year", year('ETL_DATE'))
        .withColumn("month", month('ETL_DATE'))
        .withColumn("day", dayofmonth('ETL_DATE'))
        .withColumn('LOC', substring('_c0', 39, 4))
        .withColumn("locationid", lpad('LOC', 5, '0'))
        .withColumn('locationtype', when(col('LOC').isin(['0500', '0506']), 'D').otherwise('S'))
        .withColumn("productnumber", substring('_c0', 21, 18).cast('int'))
        .withColumn("rplproductnumber", substring('_c0', 3, 18).cast('int'))
        .withColumn('startdate', to_date(substring(col('_c0'), 43,  8), 'yyyyMMdd'))
        .withColumn('enddate', to_date(substring(col('_c0'), 51,  8), 'yyyyMMdd'))
    ).drop('LOC', '_c0')

    return df