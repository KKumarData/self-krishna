#!/bin/bash

sudo pip3 install boto3
aws s3 cp s3://hema-cdp-prod-spark-jobs/jda-supersession/ /home/hadoop/ --recursive
aws s3 cp s3://hema-cdp-prod-spark-jobs/utils/ /home/hadoop/utils/ --recursive

export SPARK_LOCAL_DIRS=/opt/spark/tmp