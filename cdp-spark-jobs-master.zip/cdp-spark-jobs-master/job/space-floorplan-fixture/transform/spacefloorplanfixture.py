import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TSpaceFloorPlanFixture(**kwargs):

    logger.info("Invoked TSpaceFloorPlanFixture def")

    dfspacefloorfixture = kwargs.get("df")

    columns = "flr_dbkey;str_number;flr_livedate;flrfix_dbkey;flrfix_partid;flrfix_type;flrfix_name;flrfix_x;flrfix_y;flrfix_z".split(";")
    
    oldColumns = dfspacefloorfixture.schema.names
    dfspacefloorfixture = reduce(lambda dfspacefloorfixture, idx: dfspacefloorfixture.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfspacefloorfixture)
    
    dfspacefloorfixture = dfspacefloorfixture.withColumn("filename_reverse", input_file_name())
    dfspacefloorfixture = dfspacefloorfixture.withColumn("filename_reverse", reverse(split(reverse(dfspacefloorfixture.filename_reverse), '/')[0]))

    dfspacefloorfixture = (
        dfspacefloorfixture.withColumn("flr_dbkey", col("flr_dbkey").cast("int"))
        .withColumn("flr_livedate", date_format(to_date(col("flr_livedate"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
        .withColumn("flrfix_dbkey", col("flrfix_dbkey").cast("int"))
        .withColumn("flrfix_x", col("flrfix_x").cast("decimal(8,3)"))
        .withColumn("flrfix_y", col("flrfix_y").cast("decimal(8,3)"))
        .withColumn("flrfix_z", col("flrfix_z").cast("decimal(8,3)"))
        .withColumn("creation_date", concat(lit('20'),substring('filename_reverse',22,6)))
        .withColumn(
                            "creation_date",
                            expr(
                                "concat(substring(creation_date,1,4),'-',substring(creation_date,5,2),'-',substring(creation_date,7,2))").cast("date")
                                )
        .withColumn("load_time", current_timestamp())
        .withColumnRenamed("creation_date","ingestion_date") \
        .withColumn("year", year("ingestion_date"))
        .withColumn("month", month("ingestion_date"))
        .withColumn("day", dayofmonth("ingestion_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse"))

    wdw = Window.partitionBy('flr_dbkey','flrfix_dbkey').orderBy(desc('ingestion_date'))
    dfspacefloorfixture = dfspacefloorfixture.withColumn('Rank',rank().over(wdw))
    dfspacefloorfixture = dfspacefloorfixture.filter(dfspacefloorfixture.Rank == 1).drop(dfspacefloorfixture.Rank)
    dfspacefloorfixture = dfspacefloorfixture.dropDuplicates(['flr_dbkey','str_number','flr_livedate','flrfix_dbkey','flrfix_partid','flrfix_type','flrfix_name','flrfix_x','flrfix_y','flrfix_z'])

    dfspacefloorfixture = dfspacefloorfixture.select("flr_dbkey","str_number","flr_livedate","flrfix_dbkey","flrfix_partid","flrfix_type","flrfix_name","flrfix_x","flrfix_y","flrfix_z","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info("End of TSpaceFloorPlanFixture")
    
    return dfspacefloorfixture
