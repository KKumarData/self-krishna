import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TjdaInventory(**kwargs):

    logger.info("Invoked TjdaInventory def")

    dfjdaInventory = kwargs.get("df")

    columns = "product_id|loc|availdate|expdate|project|store|qty|supplyid".split("|")
    oldColumns=dfjdaInventory.schema.names
    dfjdaInventory = reduce(lambda dfjdaInventory, idx: dfjdaInventory.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfjdaInventory)

    #New coloumn for Filename:
    dfjdaInventory= dfjdaInventory.withColumn("ingestion_file", input_file_name())
    #Converting the datatypes of columns:
    dfjdaInventory = dfjdaInventory.withColumn("product_id",col("product_id").cast("int"))\
                                    .withColumn("loc",col("loc").cast("string"))\
                                    .withColumn("availdate", to_date(col("availdate"),"yyyy-MM-dd").cast("date"))\
                                    .withColumn("expdate", to_date(col("expdate"),"yyyy-MM-dd").cast("date"))\
                                    .withColumn("project",col("project").cast("string"))\
                                    .withColumn("store",col("store").cast("string"))\
                                    .withColumn("qty",col("qty").cast("DECIMAL(20,3)"))\
                                    .withColumn("supplyid",col("supplyid").cast("string"))
    #Creation of Etl date:
    dfjdaInventory = dfjdaInventory.withColumn("year", year("availdate"))\
                                             .withColumn("month", month("availdate"))\
                                             .withColumn("day",dayofmonth("availdate"))
                                            
    #Final Select:
    dfjdaInventory = dfjdaInventory.select("product_id","loc","availdate","expdate","project",
                                               "store","qty","supplyid","ingestion_file","year","month","day")
                                                                                              
    logger.info("End of jda inventory def")
    

    return dfjdaInventory
