import os
import logging
import sys
from pyspark.sql.functions import *
from utils.modules import logger

# Instanciate Logger
logger = logger()


def TsfsOrders(**kwargs):

    logger.info("Invoked TsapPrice def")

    df = kwargs.get("df")
    
    df = df.withColumnRenamed("orderId","order_id") \
            .withColumnRenamed("@timestamp","timestamp") \
            .withColumnRenamed("orderCreateDateTime","order_create_datetime") \
            .withColumnRenamed("orderCanceled","order_canceled") \
            .withColumnRenamed("sfsAssignment","sfs_assignment") \
            .withColumnRenamed("sfsStoreId","sfs_storeId") \
            .withColumnRenamed("orderIsFromSFSEligibleSource","order_is_from_sfs_eligible_source") \
            .withColumnRenamed("sfsEligibleCheck.checkHomeDelivery","sfs_eligible_check_home_delivery") \
            .withColumnRenamed("sfsEligibleCheck.checkMaxOrderSize","sfs_eligible_check_max_order_size") \
            .withColumnRenamed("sfsEligibleCheck.checkShippingCost","sfs_eligible_check_shipping_cost") \
            .withColumnRenamed("sfsEligibleCheck.checkDeliveryDateEligibility","sfs_eligible_check_delivery_date_eligibility") \
            .withColumnRenamed("sfsEligibleCheck.checkOrderCharacteristics.ugly","sfs_eligible_check_order_characteristics_ugly") \
            .withColumnRenamed("sfsEligibleCheck.checkOrderCharacteristics.wine","sfs_eligible_check_order_characteristics_wine") \
            .withColumnRenamed("sfsStoreSelect.noStoreAvailable","sfs_store_select_no_store_available") \
            .withColumnRenamed("sfsStoreSelect.noStockAvailable","sfs_store_select_no_stock_available") \
            .withColumnRenamed("sfsStoreSelect.selectReason","sfs_store_select_select_reason") \
            .withColumnRenamed("sfsStoreSelect.selectPrio","sfs_store_select_prio") \
            .withColumnRenamed("sfsPickorder.pickingOrderStart","sfs_pickorder_picking_order_start") \
            .withColumnRenamed("sfsPickorder.pickingOrderStartAt","sfs_pickorder_picking_order_start_at") \
            .withColumnRenamed("sfsPickorder.expirationDatePickingOrder","sfs_pickorder_expiration_date_picking_order") \
            .withColumnRenamed("sfsPickorder.mispicked","sfs_pickorder_mispicked") \
            .withColumnRenamed("sfsPickorder.mispickedAt","sfs_pickorder_mispicked_at") \
            .withColumnRenamed("sfsPickorder.labelsPrinted","sfs_pickorder_labels_printed") \
            .withColumnRenamed("sfsPickorder.labelsPrintedAt","sfs_pickorder_labels_printed_at") \
            .withColumnRenamed("sfsPickorder.labels.envelope","sfs_pickorder_labels_envelope") \
            .withColumnRenamed("sfsPickorder.labels.small","sfs_pickorder_labels_small") \
            .withColumnRenamed("sfsPickorder.labels.medium","sfs_pickorder_labels_medium") \
            .withColumnRenamed("sfsPickorder.labels.large","sfs_pickorder_labels_large") \
            .withColumnRenamed("sfsPickorder.pickingOrderFinished","sfs_pickorder_picking_order_finished") \
            .withColumnRenamed("sfsPickorder.pickingOrderFinishedAt","sfs_pickorder_picking_order_finished_at") \
            .withColumnRenamed("numberOfOrderLines","number_of_order_lines") \
            .withColumnRenamed("numberOfArticles","number_of_articles") \
            .withColumn("timestamp", col("timestamp").cast("timestamp")) \
            .withColumn("order_create_datetime", col("order_create_datetime").cast("timestamp")) \
            .withColumn("load_time", current_timestamp()) \
            .withColumn("ingestion_date", current_date()) \
            .withColumn("year", year("timestamp")) \
            .withColumn("month", month("timestamp")) \
            .withColumn("day", dayofmonth("timestamp"))


    logger.info("End of TsapPrice def")

    return df
