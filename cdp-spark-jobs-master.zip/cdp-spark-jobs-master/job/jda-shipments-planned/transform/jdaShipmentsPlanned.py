import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name
from pyspark.sql.window import Window


# Instanciate Logger
logger = logger()

def TjdaShipmentsPlanned(**kwargs):

    logger.info("Invoked TjdaShipmentsPlanned def")

    dfjdaShipmentsPlanned = kwargs.get("df")
    period = kwargs.get("period")

    columns1 = "item|source_locations|destination_locations|quantity|shipment_date|arrival_date|departure_date|delivery_date|order_placed_date".split("|")
    columns2 = "item|source_locations|destination_locations|quantity|shipment_date|arrival_date|departure_date|delivery_date|order_placed_date|need_arrived_date|need_shipment_date".split("|")
    oldColumns=dfjdaShipmentsPlanned.schema.names
    
    if "NEEDARRIVDATE" not in oldColumns:
        dfjdaShipmentsPlanned = reduce(lambda dfjdaShipmentsPlanned, idx: dfjdaShipmentsPlanned.withColumnRenamed(oldColumns[idx], columns1[idx]), range(len(oldColumns)), dfjdaShipmentsPlanned)
    
        #New coloumn for Filename:
        dfjdaShipmentsPlanned= dfjdaShipmentsPlanned.withColumn("ingestion_file", input_file_name())
        #Converting the datatypes of columns:
        dfjdaShipmentsPlanned = dfjdaShipmentsPlanned.withColumn("item",col("item").cast("int"))\
                                                 .withColumn("shipment_date", date_format(to_date(col("shipment_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                 .withColumn("arrival_date", date_format(to_date(col("arrival_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                 .withColumn("departure_date", date_format(to_date(col("departure_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                 .withColumn("delivery_date", date_format(to_date(col("delivery_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                 .withColumn("order_placed_date", date_format(to_date(col("order_placed_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                 .withColumn("need_arrived_date",lit(None))\
                                                 .withColumn("need_shipment_date",lit(None))\
                                                 .withColumn("need_arrived_date", col("need_arrived_date").cast("date"))\
                                                 .withColumn("need_shipment_date", col("need_shipment_date").cast("date"))
    else:
        dfjdaShipmentsPlanned = reduce(lambda dfjdaShipmentsPlanned, idx: dfjdaShipmentsPlanned.withColumnRenamed(oldColumns[idx], columns2[idx]), range(len(oldColumns)), dfjdaShipmentsPlanned)
    
        #New coloumn for Filename:
        dfjdaShipmentsPlanned= dfjdaShipmentsPlanned.withColumn("ingestion_file", input_file_name())
        
        #Converting the datatypes of columns:
        dfjdaShipmentsPlanned = dfjdaShipmentsPlanned.withColumn("item",col("item").cast("int"))\
                                                 .withColumn("shipment_date", date_format(to_date(col("shipment_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                 .withColumn("arrival_date", date_format(to_date(col("arrival_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                 .withColumn("departure_date", date_format(to_date(col("departure_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                 .withColumn("delivery_date", date_format(to_date(col("delivery_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                 .withColumn("order_placed_date", date_format(to_date(col("order_placed_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                 .withColumn("need_arrived_date", date_format(to_date(col("need_arrived_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                 .withColumn("need_shipment_date", date_format(to_date(col("need_shipment_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))
    #Adding the date:
    dfjdaShipmentsPlanned = dfjdaShipmentsPlanned.withColumn("filename_reverse", input_file_name())

    dfjdaShipmentsPlanned = (dfjdaShipmentsPlanned.withColumn("fileday",reverse(split(reverse(dfjdaShipmentsPlanned.filename_reverse), '/')[1]))
                                .withColumn("filemonth",reverse(split(reverse(dfjdaShipmentsPlanned.filename_reverse), '/')[2]))
                                .withColumn("fileyear",reverse(split(reverse(dfjdaShipmentsPlanned.filename_reverse), '/')[3]))
                                .withColumn('creation_date', concat(col('fileyear'),lit('-'), col('filemonth'),lit('-'), col('fileday')).cast("date")))
    
    #Adding year,month,date:
    dfjdaShipmentsPlanned = (dfjdaShipmentsPlanned  .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("year", year("creation_date"))
        .withColumn("month", month("creation_date"))
        .withColumn("day", dayofmonth("creation_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse","fileday","filemonth","fileyear"))

    #Final Select:
    dfjdaShipmentsPlanned= dfjdaShipmentsPlanned.select("item","source_locations","destination_locations","quantity",
                                                        "shipment_date","arrival_date","departure_date","delivery_date",
                                                        "order_placed_date","need_arrived_date","need_shipment_date","creation_date","load_time","ingestion_date","ingestion_file","year","month","day")
    
    dfjdaShipmentsPlanned = dfjdaShipmentsPlanned.dropDuplicates(['item','delivery_date','destination_locations','source_locations','order_placed_date'])

    logger.info("End of jda shipments planned def")

    return dfjdaShipmentsPlanned
