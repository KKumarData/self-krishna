import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from utils.modules import flatten_df,logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TdfsapPromotionsbonusbuys(**kwargs):

    logger.info("Invoked TdfsapPromotionsbonusbuys def")

    dfsapPromotionsbonusbuys = kwargs.get("df")
    period = kwargs.get("period")

    dfsapPromotionsbonusbuys = flatten_df(dfsapPromotionsbonusbuys)
    dfsapPromotionitem = dfsapPromotionsbonusbuys
    dfsapPromotionitem = dfsapPromotionitem.withColumn("ingestion_filename", input_file_name())

    #Getting the file path:
    dfsapPromotionsbonusbuys = dfsapPromotionsbonusbuys.withColumn("ingestion_filename", input_file_name())

    #Extracting from the 1st array:
    dfsapPromotionsbonusbuys = dfsapPromotionsbonusbuys.withColumn("PROMOTION_HEADER_",explode("PROMOTION_HEADER")).drop("PROMOTION_HEADER")
    #Converting PROMOTION_HEADER_ from struct:
    dfsapPromotionsbonusbuys = dfsapPromotionsbonusbuys.select("PROMOTION_HEADER_.*", "*").drop("PROMOTION_HEADER_")

    #Extracting from the 2nd array:
    dfsapPromotionsbonusbuys = dfsapPromotionsbonusbuys.withColumn("BONUSBUY_HEADER_",explode("BONUSBUY_HEADER")).drop("BONUSBUY_HEADER")
    #Converting BONUSBUY_HEADER_ from struct:
    dfsapPromotionsbonusbuys = dfsapPromotionsbonusbuys.select("BONUSBUY_HEADER_.*", "*").drop("BONUSBUY_HEADER_")
    dfsapPromotionsbonusbuys = (dfsapPromotionsbonusbuys.withColumnRenamed("_ARTICLE_QTY", "bby_header_article_qty")\
                                                       .withColumnRenamed("_SALES_UNIT", "bby_header_sales_unit"))
    #Extracting from the 3rd array:
    dfsapPromotionsbonusbuys = dfsapPromotionsbonusbuys.withColumn("BONUSBUY_ITEM_",explode("BONUSBUY_ITEM")).drop("BONUSBUY_ITEM")
    #Converting BONUSBUY_ITEM_ from struct:
    dfsapPromotionsbonusbuys = dfsapPromotionsbonusbuys.select("BONUSBUY_ITEM_.*", "*").drop("BONUSBUY_ITEM_")
    dfsapPromotionsbonusbuys = (dfsapPromotionsbonusbuys.withColumnRenamed("_ART_GRP", "bby_grp")\
                                                       .withColumnRenamed("_ART_GRP_DESC", "bby_grp_desc")
                                                       .drop("PROMOTION_ITEM"))
    
    #Extracting from the 1st array:
    dfsapPromotionitem = dfsapPromotionitem.withColumn("PROMOTION_HEADER_",explode("PROMOTION_HEADER")).drop("PROMOTION_HEADER")
    #Converting PROMOTION_HEADER_ from struct:
    dfsapPromotionitem = dfsapPromotionitem.select("PROMOTION_HEADER_.*", "*").drop("PROMOTION_HEADER_")

    #Extracting from the 4th array:
    dfsapPromotionitem = dfsapPromotionitem.withColumn("PROMOTION_ITEM_",explode("PROMOTION_ITEM")).drop("PROMOTION_ITEM")
    #Converting PROMOTION_ITEM_ from struct:
    dfsapPromotionitem = dfsapPromotionitem.select("PROMOTION_ITEM_.*", "*").drop("PROMOTION_ITEM_")
    dfsapPromotionitem = (dfsapPromotionitem.withColumnRenamed("_SALES_UNIT", "promotion_item_sales_unit")
                                            .drop("BONUSBUY_HEADER"))
    

    #Final bonusbuy Required Columns:
    dfsapPromotionsbonusbuys = (dfsapPromotionsbonusbuys.select("bby_header_article_qty","_BBY_COND_TYPE",\
                                                                "_BBY_CURRENCY","_BBY_DESCRIPTION","_BBY_FIXED","_BBY_ID","_BBY_PERCENTAGE","bby_header_sales_unit",\
                                                                "_ARTICLE_NR","bby_grp","bby_grp_desc",\
                                                                "_CHANNEL","_PROMOTION_CATEGORY","_PROMOTION_ID","_PROMOTION_NAME","_PROMOTION_TYPE","_SALES_FROM",\
                                                                "_SALES_ORG","_SALES_TO","ingestion_filename"))
                                                                   
    #Renaming the columns:
    dfsapPromotionsbonusbuys = (dfsapPromotionsbonusbuys.withColumnRenamed("_BBY_COND_TYPE", "bby_cond_type")
                                                      .withColumnRenamed("_BBY_CURRENCY", "bby_currency")
                                                      .withColumnRenamed("_BBY_DESCRIPTION", "bby_description")
                                                      .withColumnRenamed("_BBY_FIXED", "bby_fixed")
                                                      .withColumnRenamed("_BBY_ID", "bby_id")
                                                      .withColumnRenamed("_BBY_PERCENTAGE", "bby_perc")
                                                      .withColumnRenamed("_ARTICLE_NR", "article_nr")
                                                      .withColumnRenamed("_CHANNEL", "channel")
                                                      .withColumnRenamed("_PROMOTION_CATEGORY", "promotion_category")
                                                      .withColumnRenamed("_PROMOTION_ID", "promotion_id")
                                                      .withColumnRenamed("_PROMOTION_NAME", "promotion_name")
                                                      .withColumnRenamed("_PROMOTION_TYPE", "promotion_type")
                                                      .withColumnRenamed("_SALES_FROM", "sales_from")
                                                      .withColumnRenamed("_SALES_ORG", "sales_org")
                                                      .withColumnRenamed("_SALES_TO", "sales_to"))
                                                                                                   
    dfsapPromotionsbonusbuys = (dfsapPromotionsbonusbuys.withColumn("bby_header_article_qty",col("bby_header_article_qty").cast('decimal(20,3)'))
            .withColumn("bby_fixed",col("bby_fixed").cast('decimal(20,3)'))
            .withColumn("bby_id",col("bby_id"))
            .withColumn("bby_perc",col("bby_perc").cast('decimal(20,3)'))
            .withColumn("article_nr",col("article_nr").cast("bigint"))
            .withColumn("bby_grp",col("bby_grp").cast("bigint"))
            .withColumn("promotion_id",col("promotion_id"))
            .withColumn(
                            "sales_from",
                            expr(
                                "concat(substring(sales_from,1,4),'-', substring(sales_from,5,2),'-',substring(sales_from,7,2))").cast("date")
                                )
            .withColumn(
                            "sales_to",
                            expr(
                                "concat(substring(sales_to,1,4),'-', substring(sales_to,5,2),'-',substring(sales_to,7,2))").cast("date")
                                )
            .withColumn("article",lit(None).cast("bigint"))
            .withColumn("sales_currency",lit(None))
            .withColumn("sales_price",lit(None).cast('decimal(20,3)'))
            .withColumn("promotion_item_sales_unit",lit(None))
            .withColumn("sp_per",lit(None).cast("int"))
            .withColumn("country",substring('promotion_name',6,2)))
    
    #===============================================================bonusbyendshere===========================================================================================

    #Final promotion item Required Columns:
    dfsapPromotionitem = (dfsapPromotionitem.select("_CHANNEL","_PROMOTION_CATEGORY","_PROMOTION_ID","_PROMOTION_NAME","_PROMOTION_TYPE","_SALES_FROM",\
                                                                "_SALES_ORG","_SALES_TO",\
                                                                "_ARTICLE","_SALES_CURRENCY","_SALES_PRICE","promotion_item_sales_unit","_SP_PER","ingestion_filename"))
                                                                   
    #Renaming the columns:
    dfsapPromotionitem = (dfsapPromotionitem.withColumnRenamed("_CHANNEL", "channel")
                                                      .withColumnRenamed("_PROMOTION_CATEGORY", "promotion_category")
                                                      .withColumnRenamed("_PROMOTION_ID", "promotion_id")
                                                      .withColumnRenamed("_PROMOTION_NAME", "promotion_name")
                                                      .withColumnRenamed("_PROMOTION_TYPE", "promotion_type")
                                                      .withColumnRenamed("_SALES_FROM", "sales_from")
                                                      .withColumnRenamed("_SALES_ORG", "sales_org")
                                                      .withColumnRenamed("_SALES_TO", "sales_to")
                                                      .withColumnRenamed("_ARTICLE", "article")
                                                      .withColumnRenamed("_SALES_CURRENCY", "sales_currency")
                                                      .withColumnRenamed("_SALES_PRICE", "sales_price")
                                                      .withColumnRenamed("_SP_PER", "sp_per"))
                                                                                                   
    dfsapPromotionitem = (dfsapPromotionitem.withColumn("promotion_id",col("promotion_id"))
            .withColumn(
                            "sales_from",
                            expr(
                                "concat(substring(sales_from,1,4),'-', substring(sales_from,5,2),'-',substring(sales_from,7,2))").cast("date")
                                )
            .withColumn(
                            "sales_to",
                            expr(
                                "concat(substring(sales_to,1,4),'-', substring(sales_to,5,2),'-',substring(sales_to,7,2))").cast("date")
                                )
            .withColumn("article",col("article").cast("bigint"))
            .withColumn("sales_price",col("sales_price").cast('decimal(20,3)'))
            .withColumn("sp_per",col("sp_per").cast("int"))
            .withColumn("bby_header_article_qty",lit(None).cast('decimal(20,3)'))
            .withColumn("bby_fixed",lit(None).cast('decimal(20,3)'))
            .withColumn("bby_id",lit(None))
            .withColumn("bby_perc",lit(None).cast('decimal(20,3)'))
            .withColumn("article_nr",lit(None).cast("bigint"))
            .withColumn("bby_grp",lit(None).cast("bigint"))
            .withColumn("bby_grp_desc",lit(None))
            .withColumn("bby_header_sales_unit",lit(None))
            .withColumn("bby_description",lit(None))
            .withColumn("bby_currency",lit(None))
            .withColumn("bby_cond_type",lit(None))
            .withColumn("country",substring('promotion_name',6,2)))

    dfsapfinal = dfsapPromotionitem.unionByName(dfsapPromotionsbonusbuys)

    dfsapfinal = (dfsapfinal.withColumn('bby_id', when(col('bby_id') == 'null', "0000000000")
                                                 .when(col('bby_id').isNull() ,"0000000000" )
                                                 .otherwise(col('bby_id')).cast("bigint"))
                           .withColumn('promotion_id',col("promotion_id").cast("bigint")))
    dfsapfinal = dfsapfinal.withColumn("article",coalesce(col('article'),col('article_nr')))
    dfsapfinal = dfsapfinal.withColumn("fileday",reverse(split(reverse(dfsapfinal.ingestion_filename), '/')[1]))
    dfsapfinal = dfsapfinal.withColumn("filemonth",reverse(split(reverse(dfsapfinal.ingestion_filename), '/')[2]))
    dfsapfinal = dfsapfinal.withColumn("fileyear",reverse(split(reverse(dfsapfinal.ingestion_filename), '/')[3]))
    dfsapfinal = dfsapfinal.withColumn('creation_date', concat(col('fileyear'),lit('-'), col('filemonth'),lit('-'), col('fileday')).cast("date"))
    dfsapfinal = (dfsapfinal.withColumn("load_time", current_timestamp())
        .drop("ingestion_filename","fileday","filemonth","fileyear","article_nr"))


    logger.info("End of sap promotion bonus buys def")

    return dfsapfinal
