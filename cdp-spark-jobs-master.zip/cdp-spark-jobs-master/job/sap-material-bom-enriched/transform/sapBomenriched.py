import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name
from pyspark.sql.window import Window


# Instanciate Logger
logger = logger()

def TsapBomEnriched(**kwargs):

    logger.info("Invoked TjdaLocations def")

    dfsapbom = kwargs.get("df")

    columns = "article;articleType;usage;bom;alternative;category;counter_alt;validfrom_h;baseuom;baseqty;bomstatus;node;validfrom_as;counter_pos;validfrom_pos;component;issuingsite;itemcategory;posnr;compuom;compqty;fixedqty;compscrap;opscrap".split(";")
    oldColumns = dfsapbom.schema.names
    dfsapbom = reduce(lambda dfsapbom, idx: dfsapbom.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfsapbom)

    dfsapbom = dfsapbom.withColumn("filename_reverse", input_file_name())
    dfsapbom = dfsapbom.withColumn("filename_reverse", reverse(split(reverse(dfsapbom.filename_reverse), '/')[0]))

    dfsapbom = (
        dfsapbom.withColumn("creation_date", reverse(split(reverse(dfsapbom.filename_reverse), '_')[0]))
        .withColumn(
                            "creation_date",
                            expr(
                                "concat(substring(creation_date,1,4),'-', substring(creation_date,5,2),'-',substring(creation_date,7,2))").cast("date")
                                )
        .withColumn("validfrom_h", date_format(to_date(col("validfrom_h"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
        .withColumn("baseqty", col("baseqty").cast('decimal(10,3)'))
        .withColumn("validfrom_as", date_format(to_date(col("validfrom_as"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
        .withColumn("validfrom_pos", date_format(to_date(col("validfrom_pos"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("etl_date",col("creation_date"))
        .withColumn("year", year("creation_date"))
        .withColumn("month", month("creation_date"))
        .withColumn("day", dayofmonth("creation_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse"))

    #w = Window.partitionBy('article','component','posnr','validfrom_h').orderBy(desc('creation_date'))
    #dfsapbom = dfsapbom.withColumn('Rank',rank().over(w))
    #dfsapbom = dfsapbom.filter(dfsapbom.Rank == 1).drop(dfsapbom.Rank)
    #dfsapbom = dfsapbom.dropDuplicates(['article','component','posnr','validfrom_h'])

    logger.info("End of jda locations def")
    
    return dfsapbom
