spark-submit --conf spark.driver.memory=4g main.py local sap-material-bom-enriched ./debug_file/ ./out/ 2021/02/02  csv delta "[['article','component','posnr','validfrom_h']]" > ./logs/logs.txt
