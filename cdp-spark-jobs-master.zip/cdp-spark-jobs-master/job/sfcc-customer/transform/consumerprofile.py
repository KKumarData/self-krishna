import os
import logging 
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
import hashlib
from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql.functions import input_file_name

# Enable Arrow-based columnar data transfers
#spark.conf.set("spark.sql.execution.arrow.enabled", "true")
# spark = SparkSession.builder.appName('consumer').getOrCreate()
# Instanciate Logger
logger = logger()

def TConsumerProfile(**kwargs):

    logger.info('Invoked TConsumerProfile def')

    dfConsProf = kwargs.get("df")

    columns = "hema_customer_id;first_name;infix;last_name;gender;user_type;company;email_address;telephone_number;mobile_number;registration_date;modification_date;hema_store;status;card_number;optin_loyalty;date_optin_loyalty;loyalty_card_token;date_of_birth;verzekerde_nr".split(";")
    oldColumns=dfConsProf.schema.names
    dfConsProf = reduce(lambda dfConsProf, idx: dfConsProf.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfConsProf)
    
    salt = "@)@!-@)#!"
    
    dfConsProf = dfConsProf.withColumn('email_address',when(dfConsProf.email_address.isNull(), "")
                                                      .when(dfConsProf.email_address == '', "") 
                                                      .otherwise(sha2(concat_ws(salt, trim(dfConsProf.email_address)), 256),)) \
                           .withColumn('first_name',sha2(concat_ws(salt, trim(dfConsProf.first_name)), 256),) \
                           .withColumn('last_name',sha2(concat_ws(salt, trim(dfConsProf.last_name)), 256),) \
                           .withColumn('telephone_number',sha2(concat_ws(salt, trim(dfConsProf.telephone_number)), 256),) \
                           .withColumn('mobile_number',sha2(concat_ws(salt, trim(dfConsProf.mobile_number)), 256),) \
                           .withColumn("load_time",current_timestamp()) \
                           .withColumn("ingestion_date",current_date()) \
                           .withColumn("year", year(current_date())) \
                           .withColumn("month", month(current_date())) \
                           .withColumn("day", dayofmonth(current_date())) \
                           .withColumn("ingestion_file", input_file_name())
    dfConsProf = dfConsProf.select("hema_customer_id","first_name","infix","last_name","gender","user_type","company","email_address","telephone_number","mobile_number","registration_date","modification_date","hema_store","status","card_number","optin_loyalty","date_optin_loyalty","loyalty_card_token","date_of_birth","verzekerde_nr","load_time","ingestion_date","ingestion_file","year","month","day")                  
    logger.info('End of TConsumerProfile def')

    return dfConsProf
