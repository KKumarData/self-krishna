import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TjdaAllocationOut(**kwargs):

    logger.info("Invoked TjdaAllocationOut def")

    dfjdaAllocationOut = kwargs.get("df")

    #Renaimg of the deafult columnname:
    columns = "dummy_col_daAllocationOut".split(";")
    oldColumns=dfjdaAllocationOut.schema.names
    dfjdaAllocationOut = reduce(lambda dfjdaAllocationOut, idx: dfjdaAllocationOut.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfjdaAllocationOut)

    #splitting header and footer:
    df_collection = dfjdaAllocationOut.collect()
    header_row = df_collection[0][0]
    trail_row = df_collection[-1][0]
    date_of_export = header_row[2:10]
    time_of_export = header_row[10:16]
    startweek = header_row[16:22]
    jda_allocation_id = header_row[22:32]
    allocation_table_type = header_row[32:36]
    purchase_organization_id = header_row[36:40]
    sell_from_date = header_row[40:48]
    process_indicator = header_row[48:49]

    #Adding filename:
    dfjdaAllocationOut = dfjdaAllocationOut.withColumn("ingestion_file", input_file_name())
    #Removing header and footer rows:
    dfjdaAllocationOut = dfjdaAllocationOut.filter(~dfjdaAllocationOut.dummy_col_daAllocationOut.isin([header_row, trail_row]))
    #creating new columns from header:
    dfjdaAllocationOut = dfjdaAllocationOut.withColumn('article_number', substring('dummy_col_daAllocationOut',3,18).cast("int"))\
                                           .withColumn('destination_location', substring('dummy_col_daAllocationOut',21,10))\
                                           .withColumn('planned_quantity', substring('dummy_col_daAllocationOut',31,13))\
                                           .withColumn('source_location', substring('dummy_col_daAllocationOut',44,13))\
                                           .withColumn('jda_allocgroup_id', lit(jda_allocation_id))\
                                           .withColumn('allocation_table_type', lit(allocation_table_type))\
                                           .withColumn('purchase_organization_id', lit(purchase_organization_id))\
                                           .withColumn('process_indicator', lit(process_indicator))\
                                           .withColumn("date_of_export", lit(date_of_export))\
                                           .withColumn("time_of_export", lit(time_of_export))\
                                           .withColumn("startweek", lit(startweek))\
                                           .withColumn("sell_from_date", lit(sell_from_date))

    #Removing zeros from the column:
    dfjdaAllocationOut = dfjdaAllocationOut.withColumn("planned_quantity", regexp_replace(dfjdaAllocationOut.planned_quantity, '0', ''))\
                                           .withColumn("source_location", substring('source_location',7,4))\
                                           .withColumn("destination_location", substring('destination_location',7,4))
    #Dropping the column:
    dfjdaAllocationOut = dfjdaAllocationOut.drop('dummy_col_daAllocationOut')                                   
    #Changing datatype of the columns:
    dfjdaAllocationOut = dfjdaAllocationOut.withColumn("date_of_export", date_format(to_date(col("date_of_export"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))\
                                           .withColumn("sell_from_date", date_format(to_date(col("sell_from_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))\
                                           .withColumn("etl_date", date_format(to_date(col("date_of_export"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))                               
    #Final Select:
    dfjdaAllocationOut = dfjdaAllocationOut.select("article_number","destination_location","planned_quantity","source_location",
                                                   "jda_allocgroup_id","allocation_table_type","purchase_organization_id","process_indicator",
                                                   "date_of_export","time_of_export","startweek","sell_from_date","etl_date","ingestion_file")
                                                   
    logger.info("End of jda allocation out def")
    return dfjdaAllocationOut
