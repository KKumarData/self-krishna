import os
import logging 
import sys
from pyspark.sql.functions import *
from utils.modules import logger
from functools import reduce
from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql.functions import input_file_name

logger = logger()

def TEcommerceBudget(**kwargs):

    logger.info('Invoked TEcommerceBudget def')

    dfEcomBudget = kwargs.get("df")

    columns = "calendar_week;country;refresh_type;doc_type;unit;hercat;budget".split(";")
    oldColumns=dfEcomBudget.schema.names
    dfEcomBudget = reduce(lambda dfEcomBudget, idx: dfEcomBudget.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfEcomBudget)
    
    dfEcomBudget = dfEcomBudget.withColumn("filename_reverse", input_file_name())
    dfEcomBudget = dfEcomBudget.withColumn("filename_reverse", reverse(split(reverse(dfEcomBudget.filename_reverse), '/')[0]))
    
    dfEcomBudget = dfEcomBudget.withColumn("load_time",current_timestamp()) \
                           .withColumnRenamed("filename_reverse","ingestion_file") \
                           .withColumn("ingestion_date",current_date())
    dfEcomBudget = dfEcomBudget.select("calendar_week","country","refresh_type","doc_type","unit","hercat","budget","load_time","ingestion_date","ingestion_file")
    logger.info('End of TEcommerceBudget def')

    return dfEcomBudget
