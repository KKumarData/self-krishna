from datetime import datetime
from functools import reduce
from struct import Struct
from utils.modules import logger
from transform.helpers import sum_over_weeks
from transform.helpers import max_over_weeks
from transform.create_runweeks import generate_runweeks
from transform.helpers import rename_aggregated_columns
from transform.helpers import generate_weeks_without_condition
from transform.helpers import generate_single_case_when_columns
from pyspark.sql.types import StructType, StructField, StringType, FloatType, IntegerType, DateType
from pyspark.sql.functions import lit,  when, col, coalesce, length, datediff, max, first

logger = logger()

def t_farweekly(**kwargs):

    logger.info("Invoked TjdaPlanningDaily def")

    sap_opt_cal_df = kwargs.get("sap_opt_cal")
    jda_planning_weekly_df = kwargs.get("jda_weekly_planning")
    jda_sku_replenishment_settings_df = kwargs.get("jda_sku_replenishment_settings")
    cdap_product_master_mv_df = kwargs.get("product_master_mv")
    calendar_fiscal_mv_df = kwargs.get("calendar_fiscal_mv")
    ingestion_date_str = kwargs.get("exc_period")
    ingestion_date = datetime.strptime(ingestion_date_str, '%Y-%m-%d').date()
    spark = kwargs.get("ss")

    # jda_sku_replenishment_settings_df.cache()
    # cdap_product_master_mv_df.cache()
    # calendar_fiscal_mv_df.cache()
    
    logger.info("Generating RUNWEEKS DataFrame")
    # generate run weeks
    runweeks = (
            spark.createDataFrame(
                generate_runweeks(etl_date=ingestion_date),
                ['RunWeek', 'RunWeek1', 'RunWeek2', 'RunWeek3', 'RunWeek4', 'RunWeek5', 'RunWeek6', 'RunWeek7', 'RunWeek8', 'RunWeek9', 'RunWeek10', 'RunWeek11', 'RunWeek12', 'RunWeek13', 'RunWeek14', 'RunWeek15',\
                'RunWeek16', 'RunWeek17', 'RunWeek18', 'RunWeek19', 'RunWeek20', 'RunWeek21', 'RunWeek22', 'RunWeek23', 'RunWeek24', 'RunWeek25', 'RunWeek26', 'RunWeek27', 'RunWeek28', 'RunWeek29', 'RunWeek30',\
                'RunWeek31', 'RunWeek32', 'RunWeek33', 'RunWeek34', 'RunWeek35', 'RunWeek36', 'RunWeek37', 'RunWeek38', 'RunWeek39', 'RunWeek40', 'RunWeek41', 'RunWeek42', 'RunWeek43', 'RunWeek44', 'RunWeek45', \
                'RunWeek46', 'RunWeek47', 'RunWeek48', 'RunWeek49', 'RunWeek50', 'RunWeek51', 'RunWeek52', 'RunWeek53', 'RunWeek54', 'RunWeek55', 'RunWeek56', 'RunWeek57', 'RunWeek58', 'RunWeek59', 'RunWeek60', \
                'RunWeek61', 'RunWeek62', 'RunWeek63', 'RunWeek64'])
            )

    farweekly_weeks_columns = ['week01', 'week02', 'week03', 'week04', 'week05', 'week06', 'week07', 'week08', 'week09', 'week10', 'week11', 'week12', 'week13', 'week14', 'week15', 'week16', 'week17', 'week18', 'week19',\
                        'week20', 'week21', 'week22', 'week23', 'week24', 'week25', 'week26', 'week27', 'week28', 'week29', 'week30', 'week31', 'week32', 'week33', 'week34', 'week35', 'week36', 'week37', 'week38', \
                        'week39', 'week40', 'week41', 'week42', 'week43', 'week44', 'week45', 'week46', 'week47', 'week48', 'week49', 'week50', 'week51', 'week52', 'week53', 'week54', 'week55', 'week56', 'week57', \
                        'week58', 'week59', 'week60', 'week61', 'week62', 'week63', 'week64', 'week65']
    
    logger.info("Generating RUNWEEKS DataFrame - Done")
    
    logger.info("Initializing empty Farweekly DataFrame")
    farweekly_struct_cols = list()
    farweekly_struct_cols.append(StructField('etl_date', DateType(), False))
    farweekly_struct_cols.append(StructField('locationtype', StringType(), False))
    farweekly_struct_cols.append(StructField('locationid', StringType(), False))
    farweekly_struct_cols.append(StructField('productnumber', IntegerType(), False))
    farweekly_struct_cols.append(StructField('fieldtype', IntegerType(), False))
    farweekly_struct_cols.append(StructField('vendornumber', StringType(), False))
    for x in range(1, 66):
        farweekly_struct_cols.append(StructField('week' + f'{x}'.zfill(2), FloatType(), False))

    farweekly_schema  = StructType(farweekly_struct_cols)

    farweekly_df = spark.createDataFrame(spark.sparkContext.emptyRDD(), farweekly_schema)

    jda_planning_weekly_df = (
        jda_planning_weekly_df
        .withColumn('VendorNumber', lit(''))
        .withColumnRenamed('ETLRundate', 'etl_date')
        .withColumnRenamed('ITEM', 'productnumber')
        .crossJoin(runweeks)
    )

    jda_weekly_s =     (
        jda_planning_weekly_df
        .where((col('locationtype') == 'S'))
    )

    # jda_weekly_s.cache()

    jda_weekly_d =     (
        jda_planning_weekly_df
        .where((col('locationtype') == 'D'))
    )

    # jda_weekly_d.cache()

    logger.info("Initializing empty Farweekly DataFrame - Done")
    
    logger.info("Generating Fieldtype 1 Location S DataFrame")
    jda_weekly_ft1_df = (
        jda_weekly_s
        .where((col('TotFcst') != 0))
        .withColumn('fieldtype', lit(1))
        )

    jda_weekly_ft1_df = generate_single_case_when_columns(df=jda_weekly_ft1_df, then_value=col('TotFcst'), else_value=0)
    jda_weekly_ft1_df = sum_over_weeks(df=jda_weekly_ft1_df)
    jda_weekly_ft1_df = rename_aggregated_columns(df=jda_weekly_ft1_df, aggregate_name='SUM', new_columns=farweekly_weeks_columns)
    

    logger.info("Generating Fieldtype 1 Location S DataFrame - Done")

    logger.info("Performing union between Fieldtype 1 Location S DataFrame and Farweekly Dataframe")

    farweekly_df = farweekly_df.union(jda_weekly_ft1_df)
    # farweekly_df.cache()
    
    logger.info("Performing union between Fieldtype 1 Location S DataFrame and Farweekly Dataframe - Done")


    logger.info("Generating Fieldtype 1 Location D DataFrame")
    jda_weekly_ft1_df = (
        jda_weekly_d
        .withColumn('fieldtype', lit(1))
        )

    jda_weekly_ft1_df = generate_single_case_when_columns(df=jda_weekly_ft1_df, then_value=col('PlanShip'), else_value=0)
    jda_weekly_ft1_df = sum_over_weeks(df=jda_weekly_ft1_df)
    jda_weekly_ft1_df = rename_aggregated_columns(df=jda_weekly_ft1_df, aggregate_name='SUM', new_columns=farweekly_weeks_columns)
    
   
    logger.info("Generating Fieldtype 1 Location D DataFrame - Done")

    logger.info("Performing union between Fieldtype 1 Location D DataFrame and Farweekly Dataframe")

    farweekly_df = farweekly_df.union(jda_weekly_ft1_df)
    # farweekly_df.cache()
    logger.info("Performing union between Fieldtype 1 Location D DataFrame and Farweekly Dataframe - Done")

    logger.info("Generating Fieldtype 72 Location S DataFrame")
    calendar_fiscal_ft72_df = (
        calendar_fiscal_mv_df
        .select('calendar_day','calendar_week')
        .where(col('weekday_nr') == 1)
    )

    # calendar_fiscal_ft72_df.cache()

    sap_fiscal_cal_df = (
        sap_opt_cal_df
        .join(calendar_fiscal_ft72_df, (sap_opt_cal_df.ordering_date +1).cast('date') == (calendar_fiscal_ft72_df.calendar_day))
        .select('location_id', 
                'headgroup', 
                (col('ordering_date') +1).cast('date').alias('ordering_date'),
                'delivery_date',
                (datediff(col('delivery_date'), col('ordering_date'))).alias('sap_fiscal_leadtime'),
                'vendor_number',
                'calendar_week'
            )
    )

    jda_weekly_ft72_df = (
        jda_weekly_s
        .join(jda_sku_replenishment_settings_df.select('item', 'loc', 'source', 'loc_type'), # product location
              (jda_weekly_s.productnumber == jda_sku_replenishment_settings_df.item) 
              & (jda_weekly_s.Locationid == jda_sku_replenishment_settings_df.loc)
              & (jda_weekly_s.locationtype == jda_sku_replenishment_settings_df.loc_type), 
              'inner')
        .join(cdap_product_master_mv_df.select('product_id', 'head_group_id'), # material 
              (jda_weekly_s.productnumber == cdap_product_master_mv_df.product_id) & (length(cdap_product_master_mv_df.product_id) <= 8),
              'inner')
        .join(sap_fiscal_cal_df.select('headgroup', 'location_id', 'calendar_week', 'vendor_number', 'sap_fiscal_leadtime'), 
               (cdap_product_master_mv_df.head_group_id == sap_fiscal_cal_df.headgroup.cast('int'))
             & (jda_weekly_s.Locationid ==  sap_fiscal_cal_df.location_id)
             & (jda_weekly_s.STARTWEEK == sap_fiscal_cal_df.calendar_week)
             & (
                 ((jda_sku_replenishment_settings_df.source.isin('0500', '0506')) & (sap_fiscal_cal_df.vendor_number == 'R500'))
                |((~jda_sku_replenishment_settings_df.source.isin('0500', '0506')) & (sap_fiscal_cal_df.vendor_number != 'R500')) 
               ),
             'inner')
        .drop('headgroup', 'location_id', 'calendar_week', 'vendor_number')
        .join(
            sap_opt_cal_df
            .groupBy(sap_opt_cal_df.location_id, sap_opt_cal_df.headgroup, sap_opt_cal_df.vendor_number)
            .agg(
                max(datediff(col('delivery_date'), col('ordering_date')))
            )
            ,cdap_product_master_mv_df.head_group_id == sap_opt_cal_df.headgroup
            ,'left'
        )
        .withColumnRenamed('max(datediff(delivery_date, ordering_date))', 'sap_leadtime')
        .withColumn('fieldtype', lit(72))
    )
    


    jda_weekly_ft72_df = generate_single_case_when_columns(df=jda_weekly_ft72_df, then_value=coalesce('sap_fiscal_leadtime', 'sap_leadtime', lit(1)), else_value=1)
    jda_weekly_ft72_df = max_over_weeks(df=jda_weekly_ft72_df)
    jda_weekly_ft72_df = rename_aggregated_columns(df=jda_weekly_ft72_df, aggregate_name='MAX', new_columns=farweekly_weeks_columns)
    farweekly_df = farweekly_df.union(jda_weekly_ft72_df)
    # farweekly_df.cache()
    logger.info("Generating Fieldtype 72 Location S DataFrame - Done ")

    logger.info("Generating Fieldtype 72 Location D 1 DataFrame")
    
    jda_weekly_ft72_df = (
        jda_weekly_d
        .withColumn('fieldtype', lit(72))
        .where(col('Locationid').isin('00500',  '00506'))
        .groupBy('etl_date', 'locationtype', 'Locationid', 'productnumber',  'VendorNumber')
        .agg(first('etl_date'),first('locationtype'), first('Locationid'), first('productnumber'), first('VendorNumber'))
    )

    jda_weekly_ft72_df = (
        jda_weekly_ft72_df
        .join(
            jda_sku_replenishment_settings_df.select
                                                (
                                                    'item', 
                                                    (
                                                          ((col('loaddur')/60)/24).cast('int') 
                                                        + ((col('unloaddur')/60)/24).cast('int') 
                                                        + ((col('totleadtimesd')/60)/24).cast('int')
                                                    ).alias('Leadtime')
                                                )
                                             .where(
                                                 (col('loc').isin('00500',  '00506')) 
                                                 & (col('loc_type') == 3)
                                                 & (when(col('loaddur').isNull(), 0).otherwise(col('loaddur').cast('int')) != 0)
                                                ),
            jda_weekly_d.productnumber == jda_sku_replenishment_settings_df.item,
            'left'
        )
        .select('etl_date', 'locationtype', 'Locationid', 'productnumber',  'VendorNumber', 'Leadtime', 'item')
    )


    jda_weekly_ft72_df  = generate_weeks_without_condition(df=jda_weekly_ft72_df, value=coalesce('Leadtime', lit(1))).drop('Leadtime')


    farweekly_df = farweekly_df.union(jda_weekly_ft72_df)
    # farweekly_df.cache()
    
    logger.info("Generating Fieldtype 72 Location D 1 DataFrame - Done")

    logger.info("Generating Fieldtype 72 Location D 2 DataFrame")

    jda_weekly_ft72_df = (
        jda_weekly_d
        .where((col('Locationid') == '00506'))
        .join(sap_fiscal_cal_df.where((col('location_id') == '00555') & (col('headgroup') == '102') & (col('vendor_number') == '0000088500'))
            ,jda_weekly_d.STARTWEEK == sap_fiscal_cal_df.calendar_week
            ,'left')
        .crossJoin(
            sap_opt_cal_df
            .where((col('location_id') == '00555') & (col('headgroup') == '102') & (col('vendor_number') == '0000088500'))
            .select(
                max(
                    datediff(col('delivery_date'), col('ordering_date'))
                ).alias('sap_leadtime')
            )
        )
        .withColumn('fieldtype', lit(72))
    )

    jda_weekly_ft72_df = generate_single_case_when_columns(df=jda_weekly_ft72_df, then_value=coalesce('sap_fiscal_leadtime', 'sap_leadtime', lit(1)), else_value=1)
    jda_weekly_ft72_df = max_over_weeks(df=jda_weekly_ft72_df)
    jda_weekly_ft72_df = rename_aggregated_columns(df=jda_weekly_ft72_df, aggregate_name='MAX', new_columns=farweekly_weeks_columns)
    farweekly_df = farweekly_df.union(jda_weekly_ft72_df)
    # farweekly_df.cache()
    logger.info("Generating Fieldtype 72 Location D 2 DataFrame - Done")

    logger.info("Updating Vendor numbers for all fieldtypes")
    farweekly_df = (
        farweekly_df
        .join(
            jda_sku_replenishment_settings_df.where(col('loc_type').isin(3, 6))
            ,(farweekly_df.productnumber == jda_sku_replenishment_settings_df.item)
              & (farweekly_df.locationid == jda_sku_replenishment_settings_df.loc)
            ,'left')
        .withColumn('vendornumber', coalesce(col('u_curr_vendor'), lit('')))
        .drop(*jda_sku_replenishment_settings_df.columns)
    )

    logger.info("Updating Vendor numbers for all fieldtypes - Done")


    return farweekly_df