from pyspark.sql.functions import when, col

def generate_single_case_when_columns(df, then_value, else_value):
    for x in range(0, 65):
        week = f'week{str(x+1).zfill(2)}'
        if x == 0:
            df = df.withColumn(week, when(col('RunWeek') == col('STARTWEEK'), then_value).otherwise(else_value))
        else:
            df = df.withColumn(week, when(col(f'RunWeek{x}') == col('STARTWEEK'), then_value).otherwise(else_value))
    return df

def generate_weeks_without_condition(df, value):
    for x in range(0, 65):
        df = df.withColumn(f'week{str(x+1).zfill(2)}', value)
    return df

def sum_over_weeks(df):
    df = (
        df
        .groupby('etl_date', 'locationtype', 'Locationid', 'productnumber',  'fieldtype', 'VendorNumber')
        .sum("week01","week02","week03","week04","week05","week06","week07","week08","week09","week10","week11","week12","week13","week14","week15","week16","week17","week18","week19","week20","week21","week22",\
            "week23","week24","week25","week26","week27","week28","week29","week30","week31","week32","week33","week34","week35","week36","week37","week38","week39","week40","week41","week42","week43","week44","week45",\
            "week46","week47","week48","week49","week50","week51","week52","week53","week54","week55","week56","week57","week58","week59","week60","week61","week62","week63","week64","week65")
        )
    return df

def max_over_weeks(df):
    df = (
        df
        .groupby('etl_date', 'locationtype', 'Locationid', 'productnumber',  'fieldtype', 'VendorNumber')
        .max("week01","week02","week03","week04","week05","week06","week07","week08","week09","week10","week11","week12","week13","week14","week15","week16","week17","week18","week19","week20","week21","week22",\
            "week23","week24","week25","week26","week27","week28","week29","week30","week31","week32","week33","week34","week35","week36","week37","week38","week39","week40","week41","week42","week43","week44","week45",\
            "week46","week47","week48","week49","week50","week51","week52","week53","week54","week55","week56","week57","week58","week59","week60","week61","week62","week63","week64","week65")
        )
    return df


def custom_value_as_weeks(df, custom_value):
    for x in range(65):
        df  = (
            df.withColumn(f'week{str(x+1).zfill(2)}', custom_value)
        )
    return df



def rename_aggregated_columns(df, aggregate_name, new_columns):
    for x in range(0, 65):
        week_col = new_columns[x]
        df = df.withColumnRenamed(f'{aggregate_name}({week_col})', week_col)
    return df