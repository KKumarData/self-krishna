from datetime import date, timedelta

def generate_runweeks(etl_date: date) -> list:
    runweeks = list()
    for x in range(0, 65):
        if x == 0:
            runweek = str(etl_date.year) + (etl_date+timedelta(days=1)).strftime("%V").zfill(2)
        else:
            runweek = str((etl_date+timedelta(days=(7*x))).year) + (etl_date+timedelta(days=(7*x))+timedelta(days=1)).strftime("%V").zfill(2)
        runweeks.append(int(runweek))
    return [tuple(runweeks)]