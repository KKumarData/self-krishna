import os
os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages "org.apache.hadoop:hadoop-aws:2.7.4" pyspark-shell'
''
# os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages "org.apache.hadoop:hadoop-aws:2.7.4" pyspark-shell'
# os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages "org.apache.hadoop:hadoop-aws:2.7.4" pyspark-shell'
import sys
import ast
import sys
import inspect
import boto3

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

from threading import Thread
from utils.modules import logger
from utils.writeS3 import WriteS3
from utils.extractS3 import ReadS3
from multiprocessing.pool import ThreadPool
from utils.sparkSession import SparkSessionFunc
from transform.create_farweekly import t_farweekly

logger = logger()

logger.info("Init of Main ")

def main(**kwargs):

    env = kwargs.get("env")
    app_name = kwargs.get("app_name")
    farweekly_curated_bucket = kwargs.get("farweekly_path")
    # farweekly_curated_bucket = 's3a://hema-cdp-prod-datalake-curated/cdap-farweekly/' 
    jda_planning_weekly_path = kwargs.get('jda_weekly_path')
    sap_opt_calendar_path = kwargs.get('sap_opt_cal_path')
    jda_sku_replenishment_settings_path = kwargs.get('jda_sku_repl_path')
    # jda_planning_weekly_path = 's3://hema-cdp-prod-curated/jda-weekly-planning/' 
    # jda_planning_weekly_path = '/home/daniel/Desktop/Clients/HEMA/HemaCom/cdp-eks-spark-jobs/jda-weekly-planning/debug_file/curated/jda-weekly-planning/'
    # sap_opt_calendar_path = 's3://hema-cdp-prod-curated/sap-opt-calendar/'
    # sap_opt_calendar_path = '/home/daniel/Desktop/Clients/HEMA/HemaCom/cdp-eks-spark-jobs/sap-opt-calendar/debug_file/curated/sap-opt-calendar/'
    # jda_sku_replenishment_settings_path = 's3://hema-cdp-prod-curated/jda-sku-replenishment-settings/'
    # jda_sku_replenishment_settings_path = '/home/daniel/Desktop/Clients/HEMA/HemaCom/cdp-eks-spark-jobs/jda-sku-replenishment-settings/debug_file/curated/'
    period = kwargs.get("execution_period")
    redshift_user='sa_app_redshift_etl'
    redshift_host='hema-cdp-prod-redshift.cchzyi7agvjz.eu-central-1'
    redshift_port='5439'
    redshift_db='cdap_datahub'
    redshift_schema='data_store'
    jdbc_file_format = 'jdbc_redshift'

    ssm_client = boto3.client('ssm', 'eu-central-1')
    redshift_pass_parameter = ssm_client.get_parameter(Name='/datalake-cdp-infra-datalake-redshift/cdap_datahub/user/etl_user/PASSWORD', WithDecryption=True)
    redshift_pass = redshift_pass_parameter['Parameter']['Value']


    # jda-planning-weekly
    # sap-opt-calendar
    # product-master-mv 
    # sku-replenishment-settings
    # jda-supersession

    logger.info("Create Spark Session")

    ss = SparkSessionFunc(app_name=app_name, env=env)

    ss.sparkContext.addPyFile('/opt/spark/jars/RedshiftJDBC42-no-awssdk-1.2.53.1080.jar')
   

    logger.info("Load newly jda-weekly-planning from S3 Curated")
    jda_planning_weekly_df = ReadS3(
        ss=ss,
        env=env,
        s3_bucket=jda_planning_weekly_path,
        file_format='parquet',
        compressed=False
    )
    logger.info("End load process for jda-weekly-planning from S3 Curated")

    logger.info("Load newly sap-opt-calendar from S3 Curated")
    sap_opt_cal_df = ReadS3(
        ss=ss,
        env=env,
        s3_bucket=sap_opt_calendar_path,
        file_format='parquet',
        compressed=False
    )
    logger.info("End load process for sap-opt-calendar from S3 Curated")

    logger.info("Load newly jda-sku-replenishment-settings from S3 Curated")
    jda_sku_replenishment_settings_df = ReadS3(
        ss=ss,
        env=env,
        s3_bucket=jda_sku_replenishment_settings_path,
        file_format='parquet',
        compressed=False
    )
    logger.info("End load process for jda-sku-replenishment-settings from S3 Curated")

    logger.info("Acquiring Redshift password from Parameter Store")
    
    
    logger.info("Redshift password acquired")
    
    logger.info("Load newly cdap-product-master-mv from Redshift")
    cdap_product_master_mv_df = ReadS3(
        ss=ss,
        env=env,
        file_format=jdbc_file_format,
        compressed=False,
        redshift_pass=redshift_pass,
        redshift_user=redshift_user,
        redshift_host=redshift_host,
        redshift_port=redshift_port,
        redshift_db=redshift_db,
        redshift_schema=redshift_schema,
        redshift_table='cdap_product_master_mv',
    )
    logger.info("End load process for cdap-product-master-mv from Redshift")


    logger.info("Load newly calendar-fiscal-mv from Redshift")
    calendar_fiscal_mv_df = ReadS3(
        ss=ss,
        env=env,
        file_format=jdbc_file_format,
        compressed=False,
        redshift_pass=redshift_pass,
        redshift_user=redshift_user,
        redshift_host=redshift_host,
        redshift_port=redshift_port,
        redshift_db=redshift_db,
        redshift_schema=redshift_schema,
        redshift_table='calendar_fiscal_mv',
    )
    logger.info("End load process for calendar-fiscal-mv from Redshift")


    logger.info("Start Farweekly transformation process")

    pool = ThreadPool(processes=50)

    q1 = (
        pool.apply_async(t_farweekly, kwds={
                                            "sap_opt_cal": sap_opt_cal_df, 
                                            "jda_weekly_planning": jda_planning_weekly_df, 
                                            "jda_sku_replenishment_settings": jda_sku_replenishment_settings_df,
                                            "product_master_mv": cdap_product_master_mv_df,
                                            "calendar_fiscal_mv":calendar_fiscal_mv_df,
                                            "exc_period": period,
                                            "ss": ss
                                         })
    )


    logger.info("Start Farweekly transformation process")

    farweekly_df = q1.get()

    logger.info("End Farweekly transformation process")

    logger.info("Start Farweekly DF write process")

    t1 = Thread(
        target=WriteS3,
        kwargs={
            "df": farweekly_df,
            "bucket": farweekly_curated_bucket,
            "env": env,
            "job_mode": job_mode,
            "ss": ss,
            "flag_partition": False
        },
    )

    t1.start()
    t1.join()


    logger.info("End Farweekly DF write write process")


if __name__ == "__main__":
    # for arg in sys.argv:
    #     logger.info(arg)
    env = sys.argv[1]
    app_name = sys.argv[2]
    execution_period = sys.argv[3]
    job_mode = sys.argv[4]
    jda_planning_weekly_path = sys.argv[5]
    sap_opt_calendar_path = sys.argv[6]
    jda_sku_replenishment_settings_path = sys.argv[7]
    curated_path = sys.argv[8]

    main(
            env=env,
            app_name=app_name,
            execution_period=execution_period,
            job_mode=job_mode,
            jda_weekly_path=jda_planning_weekly_path,
            sap_opt_cal_path=sap_opt_calendar_path,
            jda_sku_repl_path=jda_sku_replenishment_settings_path,
            farweekly_path=curated_path
        )
        
