import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import * 
from pyspark.sql.types import *
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name

logger = logger()

def TjdaSkuReplenishmentSettings(**kwargs):

  logger.info("Invoked TjdaSkuReplenishmentSettings def")

  dfjdaSkuReplenishmentSettings = kwargs.get("df")
  
  #Lowering the columns from caps:
  lower_coloumn_names = [c.lower() for c in dfjdaSkuReplenishmentSettings.columns]
  dfjdaSkuReplenishmentSettings = dfjdaSkuReplenishmentSettings.toDF(*lower_coloumn_names)

  #Padding the coloumn and converting datatypes:
  dfjdaSkuReplenishmentSettings = dfjdaSkuReplenishmentSettings.withColumn("loc",format_string("%05d", col("loc").cast("int")))\
                                                               .withColumn("item",col("item").cast("int"))\
                                                               .withColumn("loc_type",col("loc_type").cast("int"))\
                                                               .withColumn("etl_date", current_date())

  logger.info("End of TjdaSkuReplenishmentSettings def")
    
  return dfjdaSkuReplenishmentSettings

