import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime


# Instanciate Logger
logger = logger()

def TSapSalesDelivery(**kwargs):

    logger.info("Invoked TSapSalesDelivery def")

    dfsalesdelivery = kwargs.get("df")
    period = kwargs.get("period")

    # columns = "fiscal_year_variant;fiscal_year;calendar_year_or_quarter;quarter;fiscal_year_or_period;posting_period;calendar_year;calendar_year_or_month;calendar_month;calendar_year_or_week;calendar_day;weekday;product;material_type;material_category;article_xsite_status;season;season_year;colour_class_group;colour;size_class_group;size;generic_article;material;counter_available;assortment_grade_material;module_store;promo_article;promotion_indicator;promotion;sales_promotion_type;product_group;material_group;department;cluster;category;marketing_group;product_group_1;world;store;supplying_plant;postal_code;assortment;assortment_grade;customer;account_group;company_code;sales_organization;distribution_channel;billing_type;infoprov_indicator;fiscal_year_week;fiscal_year_wk_2;value_type;version;ass_gr_art_cl;top_800;indicator_push_or_pull;season_1;sales_unit;base_unit;local_currency;document_currency;sls_abs_cust_sun;total_sales_cust_bun;absslsc_retvalwthtax_rtsaexcust;ttl_sls_cstmr_sls_v_rtsaexcusv;abs_sales_cost_value;service_fee;bruto_margin_calc;rabat_herrabat;totsls_cus_inv_lns;net_value;gross_value;currency_type;absslsc_retvalwthtax_zmfsxcust;ttl_sls_cstmr_sls_v_zmfsxcusv;rabat_hercostab;rabat_herlvmrab;bic_z_kalsm;rabat_herspbijd".split(";")
    columns = "FISCVARNT;FISCYEAR;CALQUARTER;CALQUART1;FISCPER;FISCPER3;CALYEAR;CALMONTH;CALMONTH2;CALWEEK;CALDAY;WEEKDAY1;MATERIAL;MATL_TYPE;MATL_CAT;HERASTATX;RT_SEASON;RT_SEAYR;HERACLK1;HERACLK2;HERACLM1;HERACLM2;RT_CONFMAT;MAT_SALES;HERATNBNK;HERASGRAD;HERMODULE;RT_MAT_PRM;HERACTIND;RT_PROMO;RT_PROMOCT;HERHFG;MATL_GROUP;HERAFDEL;HERCLUST;HERCAT;HERMARKET;HERHFG01;HERDIVISI;PLANT;HERSSUPL;POSTAL_CD;RT_ASORT;RT_ASSGRAD;CUSTOMER;ACCNT_GRP;COMP_CODE;SALESORG;DISTR_CHAN;BILL_TYPE;HERIPIND;HE_FISWK;HE_FISWK2;VTYPE;VERSION;HERASGCLU;HERATOP8;HERAINDPL;HERASEAS;SALES_UNIT;BASE_UOM;LOC_CURRCY;DOC_CURRCY;CPSAEXCUSU;CPSAEXCUBU;RTSAEXCUST;RTSAEXCUSV;CPSAEXCUPV;HERDVERG;HERGRMARG;HERRABAT;CPSAEXCUNI;NETVAL_INV;GROSS_VAL;ZCURTYPE;ZMFSXCUST;ZMFSXCUSV;HERCOSTAB;HERLVMRAB;HERSPBIJD;Z_KALSM".split(";")
    
    oldColumns = dfsalesdelivery.schema.names
    dfsalesdelivery = reduce(lambda dfsalesdelivery, idx: dfsalesdelivery.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfsalesdelivery)

    dfsalesdelivery = dfsalesdelivery.withColumn("filename_reverse", input_file_name())
    
    dfsalesdelivery = (dfsalesdelivery.withColumn("fileday",reverse(split(reverse(dfsalesdelivery.filename_reverse), '/')[1]))
                                .withColumn("filemonth",reverse(split(reverse(dfsalesdelivery.filename_reverse), '/')[2]))
                                .withColumn("fileyear",reverse(split(reverse(dfsalesdelivery.filename_reverse), '/')[3]))
                                .withColumn('creation_date', concat(col('fileyear'),lit('-'), col('filemonth'),lit('-'), col('fileday')).cast("date"))
                                .withColumn('CPSAEXCUSU', expr("case when right(CPSAEXCUSU,1) = '-' then -1 * cast(replace(CPSAEXCUSU, '-', '') as double) else cast(CPSAEXCUSU as double) end"))
                                .withColumn('CPSAEXCUBU', expr("case when right(CPSAEXCUBU,1) = '-' then -1 * cast(replace(CPSAEXCUBU, '-', '') as double) else cast(CPSAEXCUBU as double) end"))
                                .withColumn('RTSAEXCUST', expr("case when right(RTSAEXCUST,1) = '-' then -1 * cast(replace(RTSAEXCUST, '-', '') as double) else cast(RTSAEXCUST as double) end"))
                                .withColumn('RTSAEXCUSV', expr("case when right(RTSAEXCUSV,1) = '-' then -1 * cast(replace(RTSAEXCUSV, '-', '') as double) else cast(RTSAEXCUSV as double) end"))
                                .withColumn('CPSAEXCUPV', expr("case when right(CPSAEXCUPV,1) = '-' then -1 * cast(replace(CPSAEXCUPV, '-', '') as double) else cast(CPSAEXCUPV as double) end"))
                                .withColumn('HERDVERG', expr("case when right(HERDVERG,1) = '-' then -1 * cast(replace(HERDVERG, '-', '') as double) else cast(HERDVERG as double) end"))
                                .withColumn('HERGRMARG', expr("case when right(HERGRMARG,1) = '-' then -1 * cast(replace(HERGRMARG, '-', '') as double) else cast(HERGRMARG as double) end"))
                                .withColumn('HERRABAT', expr("case when right(HERRABAT,1) = '-' then -1 * cast(replace(HERRABAT, '-', '') as double) else cast(HERRABAT as double) end"))
                                .withColumn('CPSAEXCUNI', expr("case when right(CPSAEXCUNI,1) = '-' then -1 * cast(replace(CPSAEXCUNI, '-', '') as int) else cast(CPSAEXCUNI as int) end"))
                                .withColumn('NETVAL_INV', expr("case when right(NETVAL_INV,1) = '-' then -1 * cast(replace(NETVAL_INV, '-', '') as double) else cast(NETVAL_INV as double) end"))
                                .withColumn('GROSS_VAL', expr("case when right(GROSS_VAL,1) = '-' then -1 * cast(replace(GROSS_VAL, '-', '') as double) else cast(GROSS_VAL as double) end"))
                                .withColumn('ZMFSXCUST', expr("case when right(ZMFSXCUST,1) = '-' then -1 * cast(replace(ZMFSXCUST, '-', '') as double) else cast(ZMFSXCUST as double) end"))
                                .withColumn('ZMFSXCUSV', expr("case when right(ZMFSXCUSV,1) = '-' then -1 * cast(replace(ZMFSXCUSV, '-', '') as double) else cast(ZMFSXCUSV as double) end"))
                                .withColumn('HERCOSTAB', expr("case when right(HERCOSTAB,1) = '-' then -1 * cast(replace(HERCOSTAB, '-', '') as double) else cast(HERCOSTAB as double) end"))
                                .withColumn('HERLVMRAB', expr("case when right(HERLVMRAB,1) = '-' then -1 * cast(replace(HERLVMRAB, '-', '') as double) else cast(HERLVMRAB as double) end"))
                                .withColumn('Z_KALSM', expr("case when right(Z_KALSM,1) = '-' then -1 * cast(replace(Z_KALSM, '-', '') as double) else cast(Z_KALSM as double) end"))
                                .withColumn("calendar_day",expr("concat(substring(CALDAY,1,4),'-', substring(CALDAY,5,2),'-',substring(CALDAY,7,2))").cast("date")))

    # dfsalesdelivery = dfsalesdelivery.withColumn("CPSAEXCUSU", col("CPSAEXCUSU").cast("double")) \
                                    #  .withColumn("CPSAEXCUBU", col("CPSAEXCUBU").cast("double")) \
                                    #  .withColumn("RTSAEXCUST", col("RTSAEXCUST").cast("double")) \
                                    #  .withColumn("RTSAEXCUSV", col("RTSAEXCUSV").cast("double")) \
                                    #  .withColumn("CPSAEXCUPV", col("CPSAEXCUPV").cast("double")) \
                                    #  .withColumn("HERDVERG", col("HERDVERG").cast("double")) \
                                    #  .withColumn("HERGRMARG", col("HERGRMARG").cast("double")) \
                                    #  .withColumn("HERRABAT", col("HERRABAT").cast("double")) \
                                    #  .withColumn("CPSAEXCUNI", col("CPSAEXCUNI").cast("int")) \
                                    #  .withColumn("NETVAL_INV", col("NETVAL_INV").cast("double")) \
                                    #  .withColumn("GROSS_VAL", col("GROSS_VAL").cast("double")) \
                                    #  .withColumn("ZMFSXCUST", col("ZMFSXCUST").cast("double")) \
                                    #  .withColumn("ZMFSXCUSV", col("ZMFSXCUSV").cast("double")) \
                                    #  .withColumn("HERCOSTAB", col("HERCOSTAB").cast("double")) \
                                    #  .withColumn("HERLVMRAB", col("HERLVMRAB").cast("double")) \
                                    #  .withColumn("Z_KALSM", col("Z_KALSM").cast("double")) \
                                    #  .withColumn("calendar_day",expr("concat(substring(CALDAY,1,4),'-', substring(CALDAY,5,2),'-',substring(CALDAY,7,2))").cast("date"))
    
    dfsalesdelivery = dfsalesdelivery.withColumn("load_time", current_timestamp()) \
        .withColumn("ingestion_date",col("creation_date")) \
        .withColumn("year", year("creation_date")) \
        .withColumn("month", month("creation_date")) \
        .withColumn("day", dayofmonth("creation_date")) \
        .withColumn("ingestion_file", input_file_name()) \
        .drop('filename_reverse')

#     wdw = Window.partitionBy('CALDAY','PLANT','MATERIAL','BILL_TYPE','CUSTOMER','herssupl', 'RTSAEXCUSV', 'ingestion_file').orderBy(desc('ingestion_date'))
#     dfsalesdelivery = dfsalesdelivery.withColumn('Rank',rank().over(wdw))
#     dfsalesdelivery = dfsalesdelivery.filter(dfsalesdelivery.Rank == 1).drop(dfsalesdelivery.Rank)

    dfsalesdelivery = dfsalesdelivery.select("FISCVARNT","FISCYEAR","CALQUARTER","CALQUART1","FISCPER","FISCPER3","CALYEAR","CALMONTH","CALMONTH2","CALWEEK","CALDAY","WEEKDAY1","MATERIAL","MATL_TYPE",
                                      "MATL_CAT","HERASTATX","RT_SEASON","RT_SEAYR","HERACLK1","HERACLK2","HERACLM1","HERACLM2","RT_CONFMAT","MAT_SALES","HERATNBNK","HERASGRAD","HERMODULE","RT_MAT_PRM","HERACTIND",
                                      "RT_PROMO","RT_PROMOCT","HERHFG","MATL_GROUP","HERAFDEL","HERCLUST","HERCAT","HERMARKET","HERHFG01","HERDIVISI","PLANT","HERSSUPL","POSTAL_CD","RT_ASORT","RT_ASSGRAD","CUSTOMER","ACCNT_GRP",
                                      "COMP_CODE","SALESORG","DISTR_CHAN","BILL_TYPE","HERIPIND","HE_FISWK","HE_FISWK2","VTYPE","VERSION","HERASGCLU","HERATOP8","HERAINDPL","HERASEAS","SALES_UNIT","BASE_UOM",
                                      "LOC_CURRCY","DOC_CURRCY","CPSAEXCUSU","CPSAEXCUBU","RTSAEXCUST","RTSAEXCUSV","CPSAEXCUPV","HERDVERG","HERGRMARG","HERRABAT","CPSAEXCUNI",
                                      "NETVAL_INV","GROSS_VAL","ZCURTYPE","ZMFSXCUST","ZMFSXCUSV","HERCOSTAB","HERLVMRAB","HERSPBIJD","Z_KALSM","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info("End of TSapsalesDelivery def")
    
    return dfsalesdelivery
