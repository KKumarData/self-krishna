import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from datetime import datetime


def TCalendar(**kwargs):

    df = kwargs.get("df")

    d = datetime.today()
    year = d.strftime("%Y")
    month = d.strftime("%m")
    day = d.strftime("%d")

    df = (
        df.withColumn("year", lit(year))
        .withColumn("month", lit(month))
        .withColumn("day", lit(day))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
    )

    return df
