import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.window import Window
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name

# Instanciate Logger
logger = logger()

def TGBQSessions(**kwargs):

    logger.info('Invoked TGBQSessions def')

    dfGBSes = kwargs.get("df")

    columns = "date;country;contains_nonpastry;platform;source;medium;channel_grouping;device;sessions;transactions_nonpastry;transactions_total;transaction_revenue_nonpastry;transaction_revenue_total".split(";")
    oldColumns=dfGBSes.schema.names
    dfGBSes = reduce(lambda dfGBSes, idx: dfGBSes.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfGBSes)
    
    dfGBSes = dfGBSes.withColumn("filename_reverse", input_file_name())
    dfGBSes = dfGBSes.withColumn("filename_reverse", reverse(split(reverse(dfGBSes.filename_reverse), '/')[0]))
    
    dfGBSes = dfGBSes.withColumn("column_date", substring('filename_reverse',1,8)) \
                            .withColumnRenamed("column_date", "file_date") \
                            .withColumn("transactions_nonpastry", col("transactions_nonpastry").cast("int")) \
                            .withColumn("transactions_total", col("transactions_total").cast("int")) \
                            .withColumn("transaction_revenue_nonpastry", col("transaction_revenue_nonpastry").cast("decimal(8,3)")) \
                            .withColumn("transaction_revenue_total", col("transaction_revenue_total").cast("decimal(8,3)")) \
                            .withColumn("load_time",current_timestamp()) \
                            .withColumnRenamed("filename_reverse","ingestion_file") \
                            .withColumn("file_date",date_format(to_date(col("file_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date")) \
                            .withColumnRenamed("file_date","ingestion_date") \
                            .withColumn("year", year("ingestion_date")) \
                            .withColumn("month", month("ingestion_date")) \
                            .withColumn("day", dayofmonth("ingestion_date")) \
                            .withColumn(
                                                  "date",
                                                  expr(
                                                       "concat(substring(date,1,4),'-', substring(date,5,2),'-',substring(date,7,2))").cast("date")
                                                      )
    wdw = Window.partitionBy("date","country","contains_nonpastry","platform","source","medium","channel_grouping","device","sessions").orderBy(desc("ingestion_date"))
    dfGBSes = dfGBSes.withColumn('Rank',rank().over(wdw))
    dfGBSes = dfGBSes.filter(dfGBSes.Rank == 1).drop(dfGBSes.Rank)
    dfGBSes = dfGBSes.dropDuplicates(['date','country','contains_nonpastry','platform','source','medium','channel_grouping','device','sessions','transactions_nonpastry','transactions_total','transaction_revenue_nonpastry','transaction_revenue_total'])

    dfGBSes = dfGBSes.select("date","country","contains_nonpastry","platform","source","medium","channel_grouping","device","sessions","transactions_nonpastry","transactions_total","transaction_revenue_nonpastry","transaction_revenue_total","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info('End of TGBQSessions def')

    return dfGBSes
