import os
import boto3
import ast
from boto3.session import Session
from pyspark.context import SparkContext
from pyspark.sql.functions import *
from utils.modules import logger
from utils.unzip import unzip_file
# Instanciate the logger
logger = logger()


def ReadS3(**kwargs):

    logger.info("Start of ReadS3 Function")

    logger.info("Reading arguments")

    spark = kwargs.get("ss")
    s3_bucket = kwargs.get("s3_bucket")
    env = kwargs.get("env")
    file_format = kwargs.get("file_format")
    file_sep = kwargs.get("sep")
    file_schema = kwargs.get("file_schema")
    xml_file_row_tag = kwargs.get("row_tag")
    header = kwargs.get("header")
    file_is_compressed = kwargs.get("compressed")
    file_is_compressed = False if file_is_compressed is None else file_is_compressed
    period = kwargs.get("period")
    redshift_host = kwargs.get('redshift_host')
    redshift_port = kwargs.get('redshift_port')
    redshift_db = kwargs.get('redshift_db')
    redshift_schema = kwargs.get('redshift_schema')
    redshift_table = kwargs.get('redshift_table')
    redshift_user = kwargs.get('redshift_user')
    redshift_pass = kwargs.get('redshift_pass')
    redshift_query_temp_dir_storage = kwargs.get('redshift_storage_temp_dir')

    logger.info("Set Spark Context")

    sc = spark.sparkContext

    logger.info(
        "If Cloud in Environment, Setting Additional params for S3 connection"
    )

    # SET CONFIG TO JSC S3 CERT

    logger.info(
        "Set Spark Session properties to use S3"
    )

    sc.setSystemProperty("com.amazonaws.services.s3.enableV4", "true")

    spark.sparkContext._jsc.hadoopConfiguration().set(
        "com.amazonaws.services.s3.enableV4", "true"
    )
    spark.sparkContext._jsc.hadoopConfiguration().set(
        "fs.s3a.aws.credentials.provider",
        "com.amazonaws.auth.InstanceProfileCredentialsProvider,com.amazonaws.auth.DefaultAWSCredentialsProviderChain",
    )
    spark.sparkContext._jsc.hadoopConfiguration().set(
        "spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem"
    )
    spark.sparkContext._jsc.hadoopConfiguration().set(
        "fs.AbstractFileSystem.s3a.impl", "org.apache.hadoop.fs.s3a.S3A"
    )
    spark.sparkContext._jsc.hadoopConfiguration().set(
        "fs.s3a.endpoint", "s3.eu-central-1.amazonaws.com"
    )

    logger.info("Checking the File Format and loading data")

    headerFlag = False
    if header == True:
        headerFlag = True
    
    if file_is_compressed:
        split_bucket = s3_bucket.split("/")
        bucket_name = split_bucket[2]
        dataset_name = split_bucket[3]
        logger.info(f"Unzipping file(s) in Bucket: {bucket_name}; dataset name: {dataset_name}; format: {file_format}; ingestion date: {period}")
        unzip_file(s3_bucket_name=bucket_name, dataset_name=dataset_name, file_extension=file_format, ingestion_date=period)

    logger.info("Load File")
    if "csv" in file_format:
        df = (spark.read.option("quote", "\"")
             .option("escape", "\"")
             .option("multiLine", "true")
             .csv(
            s3_bucket, sep=file_sep, schema=file_schema, header=headerFlag
        )
        )
        logger.info("Reading path to load %s CSV file" % (s3_bucket))
    elif "json" in file_format:
        df = (
            spark.read.option("inferTimestamp","false").option("prefersDecimal","false")
            .json(s3_bucket)
        )
        logger.info("Reading path to load %s JSON file" % (s3_bucket))
    elif "xml" in file_format:
        df = (
            spark.read.format("com.databricks.spark.xml").option("inferSchema","false").option("mode","FASTFAIL")
            .option("rowTag", xml_file_row_tag)
            .load(s3_bucket)
        )
        logger.info("Reading path to load %s XML file" % (s3_bucket))
    elif "parquet" in file_format:
        logger.info("Reading path to load %s PARQUET file" % (s3_bucket))
        df = spark.read.parquet(s3_bucket)
    elif "jdbc" in file_format:
        logger.info(f"Loading data from Redshift {redshift_schema}.{redshift_table}")
        df = (
                spark.read 
                .format("jdbc")
                .option("driver", "com.amazon.redshift.jdbc42.Driver") 
                .option("url", f"jdbc:postgresql://{redshift_host}.redshift.amazonaws.com:{redshift_port}/{redshift_db}") 
                .option("dbtable", f"{redshift_schema}.{redshift_table}") 
                .option("user", redshift_user) 
                .option("password", redshift_pass) 
                .load()
               )
        
    logger.info("End of ReadS3 function")

    return df
