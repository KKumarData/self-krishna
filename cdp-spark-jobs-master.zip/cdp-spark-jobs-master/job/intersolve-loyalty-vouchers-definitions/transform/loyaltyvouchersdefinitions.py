import os
import sys
import logging
import sys
import re
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse, instr, substring, udf
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name



#Instanciate Logger
logger = logger()

def inputSchema(**kwargs):

    logger.info("schema details")

    dummySchema = StructType([StructField('record_number',StringType(),True),
        StructField('voucher_id',StringType(),True),
            StructField('status',StringType(),True),
                StructField('ean',StringType(),True),
                    StructField('voucher_title',StringType(),True),
                        StructField('voucher_description',StringType(),True),
                            StructField('currency',StringType(),True),
                                StructField('category_id',StringType(),True),
                                    StructField('picture_url',StringType(),True),
                                        StructField('business_rules',StringType(),True),
                                            StructField('linked_vouchers',StringType(),True),
                                                StructField('authorized_objects',StringType(),True),
                                                    StructField('brand_types',StringType(),True),
                                                        StructField('matching_tags',StringType(),True),
                                                            StructField('voucher_points',StringType(),True),
                                                                StructField('picture_url2',StringType(),True),
                                                                    StructField('picture_url3',StringType(),True),
                                                                        StructField('additional_info',StringType(),True)])

    return dummySchema

def TLoyaltyVouDef(**kwargs):

    logger.info('Invoked TLoyaltyVouDef def')

    dfLoyDef = kwargs.get("df")

    columns = "record_number;voucher_id;status;ean;voucher_title;voucher_description;currency;category_id;picture_url;business_rules;linked_vouchers;authorized_objects;brand_types;matching_tags;voucher_points;picture_url2;picture_url3;additional_info".split(";")
    oldColumns=dfLoyDef.schema.names
    dfLoyDef = reduce(lambda dfLoyDef, idx: dfLoyDef.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfLoyDef)

    dfLoyDef = dfLoyDef.withColumn("filename_reverse", input_file_name())
    dfLoyDef = dfLoyDef.withColumn("filename_reverse", reverse(split(reverse(dfLoyDef.filename_reverse), '/')[0]))
    
    dfLoyDef = dfLoyDef.withColumn("voucher_title",regexp_replace(col("voucher_title"), "\n", " "))
    dfLoyDef = dfLoyDef.withColumn("voucher_description",regexp_replace(col("voucher_description"), "\n", " "))

    dfLoyDef = dfLoyDef.withColumn("voucher_points",col("voucher_points").cast("int")) \
                       .withColumn("column_date", substring('filename_reverse',15,8)) \
                       .withColumnRenamed("column_date", "file_date") \
                       .withColumn("load_time",current_timestamp()) \
                       .withColumnRenamed("filename_reverse","ingestion_file") \
                       .withColumn("file_date",date_format(to_date(col("file_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date")) \
                       .withColumnRenamed("file_date","ingestion_date") \
                       .withColumn("year", year("ingestion_date")) \
                       .withColumn("month", month("ingestion_date")) \
                       .withColumn("day", dayofmonth("ingestion_date"))

    wdw = Window.partitionBy('voucher_id').orderBy(desc('ingestion_date'))
    dfLoyDef = dfLoyDef.withColumn('Rank',rank().over(wdw))
    dfLoyDef = dfLoyDef.filter(dfLoyDef.Rank == 1).drop(dfLoyDef.Rank)                   

    dfLoyDef = dfLoyDef.select("record_number","voucher_id","status","ean","voucher_title","voucher_description","currency","category_id","picture_url","business_rules","linked_vouchers","authorized_objects","brand_types","matching_tags","voucher_points","picture_url2","picture_url3","additional_info","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info('End of TLoyaltyVouDef def')

    return dfLoyDef