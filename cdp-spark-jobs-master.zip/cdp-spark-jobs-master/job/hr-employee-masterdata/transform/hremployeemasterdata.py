import os
import logging 
import sys
from pyspark.sql.functions import *
from utils.modules import logger
from functools import reduce
from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql.functions import input_file_name
from pyspark.sql.types import StructType, ArrayType, StringType, StructField

logger = logger()

def inputSchema(**kwargs):

    logger.info("schema details")

    
    
    dummySchema = StructType([StructField('country',StringType(),True),
        StructField('period',StringType(),True),
        StructField('cost_center',StringType(),True),
        StructField('store_number',StringType(),True),
        StructField('employee_id',StringType(),True),
        StructField('gender',StringType(),True),
        StructField('nationality',StringType(),True),
        StructField('date_of_birth',StringType(),True),
        StructField('date_in_service',StringType(),True),
        StructField('job_title',StringType(),True),
        StructField('job_grade',StringType(),True),
        StructField('date_in_job_position',StringType(),True),
        StructField('manager_employee_id',StringType(),True),
        StructField('hourly_wage',StringType(),True),
        StructField('monthly_salary',StringType(),True),
        StructField('currency',StringType(),True),
        StructField('contract_type',StringType(),True),
        StructField('contract_end_date',StringType(),True),
        StructField('contractual_hours',StringType(),True),
        StructField('parttime_percentage',StringType(),True),
        StructField('sick_reports',StringType(),True),
        StructField('sickness_hours',StringType(),True),
        StructField('sickness_days',StringType(),True),
        StructField('contract_termination_date',StringType(),True),
        StructField('leave_type',StringType(),True),
        StructField('leave_reason',StringType(),True)])

    return dummySchema

def THREmployeeMasterData(**kwargs):

    logger.info('Invoked THREmployeeMasterData def')

    dfEmployeeData = kwargs.get("df")
    period = kwargs.get("period")

    # columns = "country;period;cost_center;store_number;employee_id;gender;nationality;date_of_birth;date_of_service;job_title;job_grade;date_in_job_position;manager_employee_id;hourly_wage;monthly_salary;currency;contract_type;contract_end_date;contractual_hours;parttime_percentage;sick_reports;sickness_hours;sickness_days;contract_termination_date;leave_type;leave_reason".split(";")
    # oldColumns=dfEmployeeData.schema.names
    # dfEmployeeData = reduce(lambda dfEmployeeData, idx: dfEmployeeData.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfEmployeeData)
    
    dfEmployeeData = dfEmployeeData.withColumn("filename_reverse", input_file_name())
    dfEmployeeData = dfEmployeeData.withColumn("filename_reverse", reverse(split(reverse(dfEmployeeData.filename_reverse), '/')[0]))
    
    dfEmployeeData = dfEmployeeData.withColumn("date_of_birth",date_format(to_date(col("date_of_birth"),"dd-M-yyyy"),"yyyy-MM-dd").cast("date")) \
                           .withColumn("date_in_service",date_format(to_date(col("date_in_service"),"dd-M-yyyy"),"yyyy-MM-dd").cast("date")) \
                           .withColumn("date_in_job_position",date_format(to_date(col("date_in_job_position"),"dd-M-yyyy"),"yyyy-MM-dd").cast("date")) \
                           .withColumn("contract_end_date",date_format(to_date(col("contract_end_date"),"dd-M-yyyy"),"yyyy-MM-dd").cast("date")) \
                           .withColumn("contract_termination_date",date_format(to_date(col("contract_termination_date"),"dd-M-yyyy"),"yyyy-MM-dd").cast("date")) \
                           .withColumn("hourly_wage", col("hourly_wage").cast("decimal(7,2)")) \
                           .withColumn("monthly_salary", col("monthly_salary").cast("decimal(10,2)")) \
                           .withColumn("contractual_hours", col("contractual_hours").cast("decimal(6,2)")) \
                           .withColumn("parttime_percentage", col("parttime_percentage").cast("decimal(6,2)")) \
                           .withColumn("sickness_hours", col("sickness_hours").cast("decimal(6,1)")) \
                           .withColumn("sick_reports", col("sick_reports").cast("int")) \
                           .withColumn("sickness_days", col("sickness_days").cast("int")) \
                           .withColumn("period", lit(period).cast('date'))

    dfEmployeeData = dfEmployeeData.withColumn("load_time",current_timestamp()) \
                           .withColumnRenamed("filename_reverse","ingestion_file") \
                           .withColumn("year", year(dfEmployeeData.period)) \
                           .withColumn("month", month(dfEmployeeData.period)) \
                           .withColumn("day", dayofmonth(dfEmployeeData.period)) \
                           .withColumn("ingestion_date",current_date())
    dfEmployeeData = dfEmployeeData.select("country","period","cost_center","store_number","employee_id","gender","nationality","date_of_birth","date_in_service","job_title","job_grade","date_in_job_position","manager_employee_id","hourly_wage","monthly_salary","currency","contract_type","contract_end_date","contractual_hours","parttime_percentage","sick_reports","sickness_hours","sickness_days","contract_termination_date","leave_type","leave_reason","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info('End of THREmployeeMasterData def')

    return dfEmployeeData
