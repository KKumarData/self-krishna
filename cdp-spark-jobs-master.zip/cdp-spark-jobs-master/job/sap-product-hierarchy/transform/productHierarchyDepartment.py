import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, logger, camelToUnderscores

# Instanciate Logger
logger = logger()


def Thierarchydepartment(**kwargs):

    logger.info("Invoked Thierarchydepartment def")

    df = kwargs.get("df")
    dfhierarchydepartment = flatten_df(df)

    dfhierarchydepartment = dfhierarchydepartment.withColumn(
        "department",explode("AFDELING")
    ).drop("AFDELING").selectExpr(
        "department.*","HEADER__BESTANDSNAAM","HEADER__VERZENDDATUM","HEADER__EAN_ZENDER","HEADER__SYSTEEM"
    ).drop("_VALUE")

    dfhierarchydepartment = (
        dfhierarchydepartment.withColumn(
            "header_send_date",
            expr(
                "case when length(HEADER__VERZENDDATUM)=8 then concat(substring(HEADER__VERZENDDATUM,5,4),'-', substring(HEADER__VERZENDDATUM,3,2),'-',substring(HEADER__VERZENDDATUM,1,2)) ELSE concat(substring(HEADER__VERZENDDATUM,4,4),'-', substring(HEADER__VERZENDDATUM,2,2),'-','0',substring(HEADER__VERZENDDATUM,1,1)) END"
            ).cast("date"),
        )
        .withColumn("year", year("header_send_date"))
        .withColumn("month", month("header_send_date"))
        .withColumn("day", dayofmonth("header_send_date"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumnRenamed("_AFDELINGNUMMER","department_id")
        .withColumnRenamed("_OMSCHRIJVING", "department_description")
        .withColumnRenamed("_DIVISIECODE", "division_id")
        .withColumnRenamed("_TAALCODE", "language_code")
        .withColumnRenamed("HEADER__BESTANDSNAAM", "file_name")
        .withColumnRenamed("HEADER__EAN_ZENDER", "ean_sender")
        .withColumnRenamed("HEADER__SYSTEEM", "system")

    ).drop("HEADER__VERZENDDATUM")

    logger.info("End of Thierarchydepartment def")

    return dfhierarchydepartment
