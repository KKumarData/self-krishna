import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, logger, camelToUnderscores

# Instanciate Logger
logger = logger()


def Thierarchyassortment(**kwargs):

    logger.info("Invoked Thierarchyassortment def")

    df = kwargs.get("df")
    dfhierarchyassortment = flatten_df(df)

    dfhierarchyassortment = dfhierarchyassortment.withColumn(
        "ASSORTMENT",explode("ASSORTMENTGROUP")
    ).drop("ASSORTMENTGROUP").selectExpr(
        "ASSORTMENT.*","HEADER__BESTANDSNAAM","HEADER__VERZENDDATUM","HEADER__EAN_ZENDER","HEADER__SYSTEEM"
    ).drop("_VALUE")

    dfhierarchyassortment = (
        dfhierarchyassortment.withColumn(
            "header_send_date",
            expr(
                "case when length(HEADER__VERZENDDATUM)=8 then concat(substring(HEADER__VERZENDDATUM,5,4),'-', substring(HEADER__VERZENDDATUM,3,2),'-',substring(HEADER__VERZENDDATUM,1,2)) ELSE concat(substring(HEADER__VERZENDDATUM,4,4),'-', substring(HEADER__VERZENDDATUM,2,2),'-','0',substring(HEADER__VERZENDDATUM,1,1)) END"
            ).cast("date"),
        )
        .withColumn("year", year("header_send_date"))
        .withColumn("month", month("header_send_date"))
        .withColumn("day", dayofmonth("header_send_date"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumnRenamed("_CODE", "assortment_group_id")
        .withColumnRenamed("_OMSCHRIJVING", "description")
        .withColumnRenamed("_TAALCODE", "language_code")
        .withColumnRenamed("HEADER__BESTANDSNAAM", "file_name")
        .withColumnRenamed("HEADER__EAN_ZENDER", "ean_sender")
        .withColumnRenamed("HEADER__SYSTEEM", "system")

    ).drop("HEADER__VERZENDDATUM")

    logger.info("End of Thierarchyassortment def")

    return dfhierarchyassortment
