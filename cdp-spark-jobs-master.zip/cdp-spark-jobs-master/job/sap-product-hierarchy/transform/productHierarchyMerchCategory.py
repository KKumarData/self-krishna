import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, logger, camelToUnderscores

# Instanciate Logger
logger = logger()


def ToilSalesmerchcat(**kwargs):

    logger.info("Invoked ToilSalesmerchcat def")

    df = kwargs.get("df")
    dfhierarchymerchcat = flatten_df(df)
    
    dfhierarchymerchcat = dfhierarchymerchcat.withColumn(
        "CATEGORY",explode("MERCH_CAT")
    ).drop("MERCH_CAT").selectExpr(
        "CATEGORY.*","HEADER__BESTANDSNAAM","HEADER__VERZENDDATUM","HEADER__EAN_ZENDER","HEADER__SYSTEEM"
    ).drop("_VALUE")

    dfhierarchymerchcat = (
        dfhierarchymerchcat.withColumn(
            "header_send_date",
            expr(
                "case when length(HEADER__VERZENDDATUM)=8 then concat(substring(HEADER__VERZENDDATUM,5,4),'-', substring(HEADER__VERZENDDATUM,3,2),'-',substring(HEADER__VERZENDDATUM,1,2)) ELSE concat(substring(HEADER__VERZENDDATUM,4,4),'-', substring(HEADER__VERZENDDATUM,2,2),'-','0',substring(HEADER__VERZENDDATUM,1,1)) END"
            ).cast("date"),
        )
        .withColumn("year", year("header_send_date"))
        .withColumn("month", month("header_send_date"))
        .withColumn("day", dayofmonth("header_send_date"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumnRenamed("_MERCH_CAT", "merch_category_id")
        .withColumn("cluster_id",expr("case when _CLUSTER=='' then 'NOCLUSTERTID' ELSE _CLUSTER END"))
        .withColumnRenamed("_HOOFDGROEP", "headgroup_id")
        .withColumn("merch_category_description",expr("case when _OMSCHRIJVING=='' then 'NODESCRIPTION' ELSE _OMSCHRIJVING END"))
        .withColumn("language_code",expr("case when _TAALCODE=='' then 'NOCODE' ELSE _TAALCODE END"))
        .withColumnRenamed("HEADER__BESTANDSNAAM", "file_name")
        .withColumnRenamed("HEADER__EAN_ZENDER", "ean_sender")
        .withColumnRenamed("HEADER__SYSTEEM", "system")

    ).drop("HEADER__VERZENDDATUM").drop("_TAALCODE").drop("_CLUSTER").drop("_OMSCHRIJVING")

    logger.info("End of ToilSalesmerchcat def")

    return dfhierarchymerchcat
