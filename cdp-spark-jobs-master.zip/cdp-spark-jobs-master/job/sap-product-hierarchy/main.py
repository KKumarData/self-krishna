import os
import sys
import inspect
import datetime
import ast
import sys

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

from threading import Thread
from multiprocessing.pool import ThreadPool


from utils.modules import flatten_df, logger
from utils.sparkSession import SparkSessionFunc
from utils.extractS3 import ReadS3
from transform.productHierarchyAssortmentGroup import Thierarchyassortment
from transform.productHierarchyCategory import Thierarchycategory
from transform.productHierarchyCluster import Thierarchycluster
from transform.productHierarchyDepartment import Thierarchydepartment
from transform.productHierarchyDivision import Thierarchydivision
from transform.productHierarchyHeadGroup import Thierarchyheadgroup
from transform.productHierarchyMerchCategory import ToilSalesmerchcat
from transform.productHierarchyWorld import Thierarchyworld
from utils.writeS3 import WriteS3
from pyspark.sql.functions import *

# Instanciate the Log
logger = logger()

# Start App
logger.info("Init of Main ")


def main(**kwargs):

    env = kwargs.get("env")
    app_name = kwargs.get("app_name")
    raw_bucket = kwargs.get("raw_path")
    curated_bucket = kwargs.get("curated_path")
    period = kwargs.get("execution_period")
    file_format = kwargs.get("file_format")
    job_mode = kwargs.get("job_mode")
    row_tag = kwargs.get("row_tag")

    # Create Spark Session
    logger.info("Create Spark Session")

    ss = SparkSessionFunc(app_name=app_name, env=env)

    ss.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

    # Load data from S3
    logger.info("Load data from S3")

    df = ReadS3(
        ss=ss,
        env=env,
        s3_bucket=raw_bucket + "/ingestion_date=%s" % (period),
        # s3_bucket= raw_bucket,
        file_format=file_format,
        load_type=job_mode,
        period=period,
        row_tag = row_tag
    )

    logger.info("End load process from S3")
    # Set Transformation Process using ThreadPool

    logger.info("Start Transformation process")
    pool = ThreadPool(processes=50)

    q1 = pool.apply_async(Thierarchyassortment, kwds={"df": df})
    dfhierarchyassortment = q1.get()

    q2 = pool.apply_async(Thierarchycategory, kwds={"df": df})
    dfhierarchycategory = q2.get()

    q3 = pool.apply_async(Thierarchycluster, kwds={"df": df})
    dfhierarchycluster = q3.get()

    q4 = pool.apply_async(Thierarchydepartment, kwds={"df": df})
    dfhierarchydepartment = q4.get()

    q5 = pool.apply_async(Thierarchydivision, kwds={"df": df})
    dfhierarchydivision = q5.get()

    q6 = pool.apply_async(Thierarchyheadgroup, kwds={"df": df})
    dfhierarchyheadgroup = q6.get()

    q7 = pool.apply_async(ToilSalesmerchcat, kwds={"df": df})
    dfhierarchymerchcat = q7.get()

    q8 = pool.apply_async(Thierarchyworld, kwds={"df": df})
    dfhierarchyworld = q8.get()


    logger.info("End Transformation process")

    #########################################################################################################

    logger.info("Start Write process")

    if "local" in env:
        curated_bucket = "/home/govind/My_Repos/cdp-eks-spark-jobs/sap-products-hierarchy/out "

    t1 = Thread(
        target=WriteS3,
        kwargs={
            "df": dfhierarchyassortment,
            "bucket": curated_bucket + "product_hierarchy_assortment/",
            "env": env,
            "job_mode": job_mode,
            "ss": ss,
        },
    )

    t2 = Thread(
        target=WriteS3,
        kwargs={
            "df": dfhierarchycategory,
            "bucket": curated_bucket + "product_hierarchy_category/",
            "env": env,
            "job_mode": job_mode,
            "ss": ss,
        },
    )

    t3 = Thread(
        target=WriteS3,
        kwargs={
            "df": dfhierarchycluster,
            "bucket": curated_bucket + "product_hierarchy_cluster/",
            "env": env,
            "job_mode": job_mode,
            "ss": ss,
        },
    )

    t4 = Thread(
        target=WriteS3,
        kwargs={
            "df": dfhierarchydepartment,
            "bucket": curated_bucket + "product_hierarchy_department/",
            "env": env,
            "job_mode": job_mode,
            "ss": ss,
        },
    )

    t5 = Thread(
        target=WriteS3,
        kwargs={
            "df": dfhierarchydivision,
            "bucket": curated_bucket + "product_hierarchy_division/",
            "env": env,
            "job_mode": job_mode,
            "ss": ss,
        },
    )

 
    t6 = Thread(
        target=WriteS3,
        kwargs={
            "df": dfhierarchyheadgroup,
            "bucket": curated_bucket + "product_hierarchy_headgroup/",
            "env": env,
            "job_mode": job_mode,
            "ss": ss,
        },
    )

    t7 = Thread(
        target=WriteS3,
        kwargs={
            "df": dfhierarchymerchcat,
            "bucket": curated_bucket + "product_hierarchy_merchcategory/",
            "env": env,
            "job_mode": job_mode,
            "ss": ss,
        },
    )

    t8 = Thread(
        target=WriteS3,
        kwargs={
            "df": dfhierarchyworld,
            "bucket": curated_bucket + "product_hierarchy_world/",
            "env": env,
            "job_mode": job_mode,
            "ss": ss,
        },
    )


    t1.start()
    t2.start()
    t3.start()
    t4.start()
    t5.start()
    t6.start()
    t7.start()
    t8.start()

    logger.info("End Write process")


if __name__ == "__main__":

    env = sys.argv[1]
    app_name = sys.argv[2]
    raw_path = sys.argv[3]
    curated_path = sys.argv[4]
    execution_period = sys.argv[5]
    file_format = sys.argv[6]
    job_mode = sys.argv[7]
    row_tag = sys.argv[8]

    if "delta" not in job_mode:
        for period in ast.literal_eval(execution_period):
            try:
                main(
                    env=env,
                    app_name=app_name,
                    raw_path=raw_path,
                    curated_path=curated_path,
                    execution_period=period,
                    file_format=file_format,
                    job_mode=job_mode,
                    row_tag=row_tag,
                )
            except:
                pass
    else:
        main(
            env=env,
            app_name=app_name,
            raw_path=raw_path,
            curated_path=curated_path,
            execution_period=execution_period,
            file_format=file_format,
            job_mode=job_mode,
            row_tag=row_tag,
        )
