import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TSpacePlanogramFixture(**kwargs):

    logger.info("Invoked TSpacePlanogramFixture def")

    dfspaceplanofixture = kwargs.get("df")

    columns = "pog_dbkey;pog_assortment;pog_livedate;seg_number;fix_dbkey;fix_partid;fix_name;fix_type;fix_width;fix_height;fix_depth;fix_linear;fix_square;fix_cubic;fix_spacelinear;fix_spacesquare;fix_spacecubic;fix_availablelinear;fix_availablesquare;fix_availablecubic;fix_numberofdividers;fix_dividerwidth;fix_dividerheight;fix_dividerdepth;fix_x;fix_y;fix_z;fix_angle;fix_slope;fix_roll;fix_merchspace;fix_locationid".split(";")
    
    oldColumns = dfspaceplanofixture.schema.names
    dfspaceplanofixture = reduce(lambda dfspaceplanofixture, idx: dfspaceplanofixture.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfspaceplanofixture)
    
    dfspaceplanofixture = dfspaceplanofixture.withColumn("filename_reverse", input_file_name())
    dfspaceplanofixture = dfspaceplanofixture.withColumn("filename_reverse", reverse(split(reverse(dfspaceplanofixture.filename_reverse), '/')[0]))

    dfspaceplanofixture = (
        dfspaceplanofixture.withColumn("pog_dbkey", col("pog_dbkey").cast("int"))
        .withColumn("pog_livedate", date_format(to_date(col("pog_livedate"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
        .withColumn("seg_number", col("seg_number").cast("int"))
        .withColumn("fix_dbkey", col("fix_dbkey").cast("int"))
        .withColumn("fix_width", col("fix_width").cast("decimal(8,3)"))
        .withColumn("fix_height", col("fix_height").cast("decimal(8,3)"))
        .withColumn("fix_depth", col("fix_depth").cast("decimal(8,3)"))
        .withColumn("fix_linear", col("fix_linear").cast("decimal(8,3)"))
        .withColumn("fix_square", col("fix_square").cast("decimal(10,3)"))
        .withColumn("fix_cubic", col("fix_cubic").cast("decimal(10,3)"))
        .withColumn("fix_spacelinear", col("fix_spacelinear").cast("decimal(10,3)"))
        .withColumn("fix_spacesquare", col("fix_spacesquare").cast("decimal(10,3)"))
        .withColumn("fix_spacecubic", col("fix_spacecubic").cast("decimal(12,3)"))
        .withColumn("fix_availablelinear", col("fix_availablelinear").cast("decimal(10,3)"))
        .withColumn("fix_availablesquare", col("fix_availablesquare").cast("decimal(10,3)"))
        .withColumn("fix_availablecubic", col("fix_availablecubic").cast("decimal(12,3)"))
        .withColumn("fix_dividerwidth", col("fix_dividerwidth").cast("decimal(8,3)"))
        .withColumn("fix_dividerheight", col("fix_dividerheight").cast("decimal(8,3)"))
        .withColumn("fix_dividerdepth", col("fix_dividerdepth").cast("decimal(8,3)"))
        .withColumn("fix_numberofdividers", col("fix_numberofdividers").cast("short"))
        .withColumn("fix_x", col("fix_x").cast("decimal(8,3)"))
        .withColumn("fix_y", col("fix_y").cast("decimal(8,3)"))
        .withColumn("fix_z", col("fix_z").cast("decimal(8,3)"))
        .withColumn("fix_angle", col("fix_angle").cast("int"))
        .withColumn("fix_slope", col("fix_slope").cast("int"))
        .withColumn("fix_roll", col("fix_roll").cast("byte"))
        .withColumn("fix_merchspace", col("fix_merchspace").cast("int"))
        .withColumn("fix_locationid", col("fix_locationid").cast("short"))
        .withColumn("creation_date", concat(lit('20'),substring('filename_reverse',22,6)))
        .withColumn(
                            "creation_date",
                            expr(
                                "concat(substring(creation_date,1,4),'-',substring(creation_date,5,2),'-',substring(creation_date,7,2))").cast("date")
                                )
        .withColumn("load_time", current_timestamp())
        .withColumnRenamed("creation_date","ingestion_date") \
        .withColumn("year", year("ingestion_date"))
        .withColumn("month", month("ingestion_date"))
        .withColumn("day", dayofmonth("ingestion_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse"))

    wdw = Window.partitionBy('pog_dbkey','fix_dbkey').orderBy(desc('ingestion_date'))
    dfspaceplanofixture = dfspaceplanofixture.withColumn('Rank',rank().over(wdw))
    dfspaceplanofixture = dfspaceplanofixture.filter(dfspaceplanofixture.Rank == 1).drop(dfspaceplanofixture.Rank)
    dfspaceplanofixture = dfspaceplanofixture.dropDuplicates(['pog_dbkey','pog_assortment','pog_livedate','seg_number','fix_dbkey','fix_partid','fix_name','fix_type','fix_width','fix_height','fix_depth','fix_linear','fix_square','fix_cubic','fix_spacelinear','fix_spacesquare','fix_spacecubic','fix_availablelinear','fix_availablesquare','fix_availablecubic','fix_numberofdividers','fix_dividerwidth','fix_dividerheight','fix_dividerdepth','fix_x','fix_y','fix_z','fix_angle','fix_slope','fix_roll','fix_merchspace','fix_locationid'])

    dfspaceplanofixture = dfspaceplanofixture.select("pog_dbkey","pog_assortment","pog_livedate","seg_number","fix_dbkey","fix_partid","fix_name","fix_type","fix_width","fix_height","fix_depth","fix_linear","fix_square","fix_cubic","fix_spacelinear","fix_spacesquare","fix_spacecubic","fix_availablelinear","fix_availablesquare","fix_availablecubic","fix_numberofdividers","fix_dividerwidth","fix_dividerheight","fix_dividerdepth","fix_x","fix_y","fix_z","fix_angle","fix_slope","fix_roll","fix_merchspace","fix_locationid","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info("End of TSpacePlanogramFixture")
    
    return dfspaceplanofixture
