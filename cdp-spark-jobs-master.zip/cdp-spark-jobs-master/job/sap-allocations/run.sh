spark-submit --conf spark.driver.memory=4g main.py local sap-allocations ./debug_file/ ./out/ 2021/02/02  csv delta "[['ABELN','MATERIAL','PLANT','ABELP','load_time']]"
