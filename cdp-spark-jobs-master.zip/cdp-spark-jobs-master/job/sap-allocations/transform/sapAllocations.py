import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TsapAllocations(**kwargs):

    logger.info("Invoked TsapAllocations def")

    dfsapallocations = kwargs.get("df")

    columns = "ABELN;ABELP;ABELG;ABELF;AUFAR;BEZCH;ASTAK;PSTAK;SPERK;ERDAT_K;AFDAT;VKSDT_K;TD_ALLOCATION_ID;ASTAP;PSTAP;SPERP;ERDAT_P;MATERIAL;VZWRK;LIFNR;SBELN;ASTRA;VKSDT_P;PLANT;PMNGU;IMNGU;WMNGE;AUFME;AAVIT;ABFDT;ABFST;ABAST;TDFQ;TDSOQ;PSOQ_RECEIVE;RA_DATE;IMNGA_A;IMNGA_B;WMERF;BMERF".split(";")
    
    oldColumns = dfsapallocations.schema.names
    dfsapallocations = reduce(lambda dfsapallocations, idx: dfsapallocations.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfsapallocations)
    
    dfsapallocations = dfsapallocations.withColumn("filename_reverse", input_file_name())
    dfsapallocations = dfsapallocations.withColumn("filename_reverse", reverse(split(reverse(dfsapallocations.filename_reverse), '/')[0]))

    dfsapallocations = (
        dfsapallocations.withColumn("ABELP", col("ABELP").cast("int"))
        .withColumn("ABELG", col("ABELG").cast("int"))
        .withColumn("ABELF", col("ABELF").cast("int"))
        .withColumn(
                            "ERDAT_K",
                            expr(
                                "concat(substring(ERDAT_K,1,4),'-', substring(ERDAT_K,5,2),'-',substring(ERDAT_K,7,2))").cast("date")
                                )
        .withColumn(
                            "AFDAT",
                            expr(
                                "concat(substring(AFDAT,1,4),'-', substring(AFDAT,5,2),'-',substring(AFDAT,7,2))").cast("date")
                                )
        .withColumn(
                            "VKSDT_K",
                            expr(
                                "concat(substring(VKSDT_K,1,4),'-', substring(VKSDT_K,5,2),'-',substring(VKSDT_K,7,2))").cast("date")
                                )
        .withColumn("TD_ALLOCATION_ID", col("TD_ALLOCATION_ID").cast("int"))
        .withColumn(
                            "ERDAT_P",
                            expr(
                                "concat(substring(ERDAT_P,1,4),'-', substring(ERDAT_P,5,2),'-',substring(ERDAT_P,7,2))").cast("date")
                                )
        .withColumn(
                            "VKSDT_P",
                            expr(
                                "concat(substring(VKSDT_P,1,4),'-', substring(VKSDT_P,5,2),'-',substring(VKSDT_P,7,2))").cast("date")
                                )
        .withColumn("PMNGU", col("PMNGU").cast('decimal(13,3)'))
        .withColumn("IMNGU", col("IMNGU").cast('decimal(13,3)'))
        .withColumn("WMNGE", col("WMNGE").cast('decimal(13,3)'))
        .withColumn(
                            "ABFDT",
                            expr(
                                "concat(substring(ABFDT,1,4),'-', substring(ABFDT,5,2),'-',substring(ABFDT,7,2))").cast("date")
                                )
        .withColumn("TDFQ", col("TDFQ").cast('decimal(13,3)'))
        .withColumn("TDSOQ", col("TDSOQ").cast('decimal(13,3)'))
        .withColumn(
                            "RA_DATE",
                            expr(
                                "concat(substring(RA_DATE,1,4),'-', substring(RA_DATE,5,2),'-',substring(RA_DATE,7,2))").cast("date")
                                )
        .withColumn("IMNGA_A", col("IMNGA_A").cast('decimal(13,3)'))
        .withColumn("IMNGA_B", col("IMNGA_B").cast('decimal(13,3)'))
        .withColumn("creation_date", reverse(split(reverse(dfsapallocations.filename_reverse), '_')[0]))
        .withColumn(
                            "creation_date",
                            expr(
                                "concat(substring(creation_date,1,4),'-', substring(creation_date,5,2),'-',substring(creation_date,7,2))").cast("date")
                                )
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("year", year("creation_date"))
        .withColumn("month", month("creation_date"))
        .withColumn("day", dayofmonth("creation_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse"))

    dfsapallocations = dfsapallocations.dropDuplicates(['ABELN','MATERIAL','PLANT','ABELP','load_time'])

    logger.info("End of sap allocations def")
    
    return dfsapallocations
