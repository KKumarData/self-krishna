import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType, DateType
from utils.modules import flatten_df, logger

# Instanciate Logger
logger = logger()


def TsapProductMaster(**kwargs):

    logger.info("Invoked Products def")

    dfMasterProduct = kwargs.get("df")
    dfMasterProduct = flatten_df(dfMasterProduct)
    
    
    ## FOR HIST PROCESS

    dfMasterProduct = dfMasterProduct.withColumn("artikel", explode_outer("ARTICLE_ARTIKEL"))
    dfMasterProduct = flatten_df(dfMasterProduct)
    dfMasterProduct = dfMasterProduct.withColumn("artikel_details", explode_outer("artikel_ARTIKEL_ALGEMEEN"))
    dfMasterProduct = flatten_df(dfMasterProduct)

    cols_filtered = [
            c
            for c in dfMasterProduct.schema.names
            if isinstance(dfMasterProduct.schema[c].dataType, (ArrayType, StructType))
        ]

    dfMasterProduct = dfMasterProduct.drop(*cols_filtered)

    dfMasterProduct = dfMasterProduct.drop("artikel_ARTIKEL_INHOUD", "_xmlns")

    dfMasterProduct.printSchema()

    dfMasterProduct = (
        dfMasterProduct.withColumnRenamed("ARTICLE_HEADER_BESTANDSNAAM", "header_filename")
        .withColumnRenamed("ARTICLE_HEADER_EAN_ONTVANGER", "header_ean_receiver")
        .withColumnRenamed("ARTICLE_HEADER_EAN_ZENDER", "header_ean_sender")
        .withColumnRenamed("ARTICLE_HEADER_SYSTEEM", "header_system")
        .withColumnRenamed("artikel_details_ARCHIVERING_STATUS", "archiving_status")
        .withColumnRenamed("artikel_details_ARTIKELNUMMER", "product_id")
        .withColumnRenamed("artikel_details_ARTIKEL_CATEGORY", "product_category")
        .withColumnRenamed("artikel_details_ARTIKEL_OMSCHRIJVING", "product_description")
        .withColumnRenamed("artikel_details_ARTIKEL_SOORT", "product_type")
        .withColumnRenamed("artikel_details_ARTIKEL_STATUS", "product_status")
        .withColumnRenamed("artikel_details_BASE_UNIT_OF_MEASURE", "base_unit_of_measure")
        .withColumnRenamed("artikel_details_CATEGORIE", "category")
        .withColumnRenamed("artikel_details_CATEGORIE_NAAM", "category_name")
        .withColumnRenamed("artikel_details_COMMODITY_CODE", "commodity_code")
        .withColumnRenamed("artikel_details_CREATIEDATUM", "creation_date")
        .withColumnRenamed("artikel_details_DIVISIE_CODE", "division_code")
        .withColumnRenamed("artikel_details_DIVISIE_OMSCHRIJVING", "division_description")
        .withColumnRenamed("artikel_details_EAN", "ean")
        .withColumnRenamed("artikel_details_GENERIEK_ARTIKELNUMMER", "generic_product_id")
        .withColumnRenamed("artikel_details_HOOFDGROEP", "main_group")
        .withColumnRenamed("artikel_details_HOUDBAARHEID_EENHEID", "shelf_life_unit")
        .withColumnRenamed("artikel_details_LEVERANCIER_ART_NR", "supplier_product_id")
        .withColumnRenamed("artikel_details_MERCHANDISE_CATEGORY", "merchandise_category")
        .withColumnRenamed("artikel_details_MINIMUM_HOUDBAARHEID", "minimum_shelf_life")
        .withColumnRenamed("artikel_details_POS", "pos")
        .withColumnRenamed("artikel_details_TAALCODE", "language_code")
        .withColumnRenamed("artikel_details_TOTAAL_HOUDBAARHEID", "total_shelf_life")
        .withColumn("product_id", col("product_id").cast("bigint"))
        .withColumn(
            "creation_date",
            expr(
                "concat(substring(creation_date,1,4),'-', substring(creation_date,5,2),'-',substring(creation_date,7,2))"
            ).cast("date"),
        )
        .withColumn("generic_product_id", col("generic_product_id").cast("bigint"))
        .withColumn("header_ean_sender", col("header_ean_sender").cast("string"))
        .withColumn(
            "header_send_date",
            expr(
                "case when length(ARTICLE_HEADER_VERZENDDATUM)=8 then concat(substring(ARTICLE_HEADER_VERZENDDATUM,5,4),'-', substring(ARTICLE_HEADER_VERZENDDATUM,3,2),'-',substring(ARTICLE_HEADER_VERZENDDATUM,1,2)) ELSE concat(substring(ARTICLE_HEADER_VERZENDDATUM,4,4),'-', substring(ARTICLE_HEADER_VERZENDDATUM,2,2),'-','0',substring(ARTICLE_HEADER_VERZENDDATUM,1,1)) END"
            ).cast("date"),
        )
        .withColumnRenamed("ARTICLE_HEADER_VERZENDTIJD", "header_send_time")
        .withColumn("header_send_time", col("header_send_time").cast("string"))
        .withColumn("product_category", col("product_category").cast("string"))
        .withColumn("category", col("category").cast("string"))
        .withColumn("commodity_code", col("commodity_code").cast("string"))
        .withColumn("ean", col("ean").cast("string"))
        .withColumn("main_group", col("main_group").cast("string"))
        .withColumn("merchandise_category", col("merchandise_category").cast("string"))
        .withColumn("minimum_shelf_life", col("minimum_shelf_life").cast("string"))
        .withColumn("pos", col("pos").cast("string"))
        .withColumn("total_shelf_life", col("total_shelf_life").cast("string"))
        .withColumn("year", year("header_send_date"))
        .withColumn("month", month("header_send_date"))
        .withColumn("day", dayofmonth("header_send_date"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .drop("HEADER_VALUE", "HEADER_VERZENDDATUM", "artikel_ARTIKEL", "artikel_details_VALUE", "ARTICLE_xmlns", "ARTICLE_HEADER_VERZENDDATUM", "artikel_ARTIKEL_INHOUD_ARTIKELNUMMER", "artikel_ARTIKEL_INHOUD_BRUTO_INHOUD", "artikel_ARTIKEL_INHOUD_INHOUDSEENHEID", "artikel_ARTIKEL_INHOUD_NETTO_INHOUD", "artikel_ARTIKEL_INHOUD_VERGELIJKINGSPRIJSEENHEID")
    )    

    logger.info("End Products def")    
    
    return dfMasterProduct
