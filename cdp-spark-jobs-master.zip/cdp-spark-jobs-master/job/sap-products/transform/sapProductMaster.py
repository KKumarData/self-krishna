import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType, DateType
from utils.modules import flatten_df, logger

# Instanciate Logger
logger = logger()


def TsapProductMaster(**kwargs):

    logger.info("Invoked Products def")

    dfMasterProduct = kwargs.get("df")
    dfMasterProduct = flatten_df(dfMasterProduct)
    
    
    try:

        dfMasterProduct = dfMasterProduct.withColumn("artikel", explode_outer("ARTIKEL"))
        dfMasterProduct = flatten_df(dfMasterProduct)
        dfMasterProduct = dfMasterProduct.drop("artikel_ARTIKEL_INHOUD", "_xmlns")
        # # dfMasterProduct = flatten_df(dfMasterProduct)
        dfMasterProduct = dfMasterProduct.withColumn("artikel_details", explode_outer("artikel_ARTIKEL_ALGEMEEN"))
        dfMasterProduct = flatten_df(dfMasterProduct)

    except :
        
        dfMasterProduct = dfMasterProduct.withColumn("artikel_details", explode_outer("artikel_ARTIKEL_ALGEMEEN"))
        dfMasterProduct = flatten_df(dfMasterProduct)
        dfMasterProduct = dfMasterProduct.drop("artikel_ARTIKEL_INHOUD", "_xmlns")
        dfMasterProduct = flatten_df(dfMasterProduct).drop("ARTIKEL_ARTIKEL_INHOUD__ARTIKELNUMMER","ARTIKEL_ARTIKEL_INHOUD__BRUTO_INHOUD"
        ,"ARTIKEL_ARTIKEL_INHOUD__INHOUDSEENHEID","ARTIKEL_ARTIKEL_INHOUD__NETTO_INHOUD","ARTIKEL_ARTIKEL_INHOUD__VALUE","ARTIKEL_ARTIKEL_INHOUD__VERGELIJKINGSPRIJSEENHEID")
        print("Only one record is in the delta file")
        pass

 
    
    cols_filtered = [
        c
        for c in dfMasterProduct.schema.names
        if isinstance(dfMasterProduct.schema[c].dataType, (ArrayType, StructType))
    ]

    dfMasterProduct = dfMasterProduct.drop(*cols_filtered)

    
    
    # # # Added try/except to catch the delta file with only one record #
    # # try:
    # #     dfMasterProduct = dfMasterProduct.withColumn(
    # #     "ARTIKEL_",explode("ARTIKEL")
    # # ).drop("ARTIKEL")
    # #     dfMasterProduct = dfMasterProduct.withColumn(
    # #     "ARTIKEL_ALGEMEEN", explode("ARTIKEL_.ARTIKEL_ALGEMEEN")
    # # ).drop("ARTIKEL_")
    # #     dfMasterProduct = dfMasterProduct.select(
    # #     "ARTIKEL_ALGEMEEN.*","*"
    # # ).drop("_VALUE","ARTIKEL_ALGEMEEN","_xmlns")
    
    # # except :
        # dfMasterProduct = dfMasterProduct.withColumn("ARTIKEL", explode("ARTIKEL_ARTIKEL_ALGEMEEN")).drop("ARTIKEL_ARTIKEL_ALGEMEEN")
        # dfMasterProduct=dfMasterProduct.select("ARTIKEL.*","HEADER__BESTANDSNAAM","HEADER__VERZENDDATUM","HEADER__EAN_ONTVANGER","HEADER__EAN_ZENDER","HEADER__SYSTEEM","HEADER__VALUE"
        # ,"HEADER__VERZENDTIJD").drop("_VALUE")
    # #     print("Only one record is in the delta file")
    # #     pass
    
    dfMasterProduct = (
        dfMasterProduct
        # .withColumnRenamed("HEADER__BESTANDSNAAM", "header_filename")
        # .withColumnRenamed("HEADER__EAN_ONTVANGER", "header_ean_receiver")
        .withColumnRenamed("HEADER__EAN_ZENDER", "header_ean_sender")
        # .withColumnRenamed("HEADER__SYSTEEM", "header_system")
        .withColumnRenamed("artikel_details__ARCHIVERING_STATUS", "archiving_status")
        .withColumnRenamed("artikel_details__ARTIKELNUMMER", "product_id")
        .withColumnRenamed("artikel_details__ARTIKEL_CATEGORY", "product_category")
        .withColumnRenamed("artikel_details__ARTIKEL_OMSCHRIJVING", "product_description")
        .withColumnRenamed("artikel_details__ARTIKEL_SOORT", "product_type")
        .withColumnRenamed("artikel_details__ARTIKEL_STATUS", "product_status")
        .withColumnRenamed("artikel_details__BASE_UNIT_OF_MEASURE", "base_unit_of_measure")
        .withColumnRenamed("artikel_details__CATEGORIE", "category")
        .withColumnRenamed("artikel_details__CATEGORIE_NAAM", "category_name")
        .withColumnRenamed("artikel_details__COMMODITY_CODE", "commodity_code")
        .withColumnRenamed("artikel_details__CREATIEDATUM", "creation_date")
        .withColumnRenamed("artikel_details__DIVISIE_CODE", "division_code")
        .withColumnRenamed("artikel_details__DIVISIE_OMSCHRIJVING", "division_description")
        .withColumnRenamed("artikel_details__EAN", "ean")
        .withColumnRenamed("artikel_details__GENERIEK_ARTIKELNUMMER", "generic_product_id")
        .withColumnRenamed("artikel_details__HOOFDGROEP", "main_group")
        .withColumnRenamed("artikel_details__HOUDBAARHEID_EENHEID", "shelf_life_unit")
        .withColumnRenamed("artikel_details__LEVERANCIER_ART_NR", "supplier_product_id")
        .withColumnRenamed("artikel_details__MERCHANDISE_CATEGORY", "merchandise_category")
        .withColumnRenamed("artikel_details__MINIMUM_HOUDBAARHEID", "minimum_shelf_life")
        .withColumnRenamed("artikel_details__POS", "pos")
        .withColumnRenamed("artikel_details__TAALCODE", "language_code")
        .withColumnRenamed("artikel_details__TOTAAL_HOUDBAARHEID", "total_shelf_life")
        .withColumn("product_id", col("product_id").cast("bigint"))
        .withColumn(
            "creation_date",
            expr(
                "concat(substring(creation_date,1,4),'-', substring(creation_date,5,2),'-',substring(creation_date,7,2))"
            ).cast("date"),
        )
        .withColumn("generic_product_id", col("generic_product_id").cast("bigint"))
        .withColumn("header_ean_sender", col("header_ean_sender").cast("string"))
        .withColumn(
            "header_send_date",
            expr(
                "case when length(HEADER__VERZENDDATUM)=8 then concat(substring(HEADER__VERZENDDATUM,5,4),'-', substring(HEADER__VERZENDDATUM,3,2),'-',substring(HEADER__VERZENDDATUM,1,2)) ELSE concat(substring(HEADER__VERZENDDATUM,4,4),'-', substring(HEADER__VERZENDDATUM,2,2),'-','0',substring(HEADER__VERZENDDATUM,1,1)) END"
            ).cast("date"),
        )
        .withColumnRenamed("HEADER__VERZENDTIJD", "header_send_time")
        .withColumn("header_send_time", col("header_send_time").cast("string"))
        .withColumn("product_category", col("product_category").cast("string"))
        .withColumn("category", col("category").cast("string"))
        .withColumn("commodity_code", col("commodity_code").cast("string"))
        .withColumn("ean", col("ean").cast("string"))
        .withColumn("main_group", col("main_group").cast("string"))
        .withColumn("merchandise_category", col("merchandise_category").cast("string"))
        .withColumn("minimum_shelf_life", col("minimum_shelf_life").cast("string"))
        .withColumn("pos", col("pos").cast("string"))
        .withColumn("total_shelf_life", col("total_shelf_life").cast("string"))
        .withColumn("year", year("header_send_date"))
        .withColumn("month", month("header_send_date"))
        .withColumn("day", dayofmonth("header_send_date"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .drop("HEADER__VALUE", "HEADER__VERZENDDATUM", "artikel__ARTIKEL", "artikel_details__VALUE", "HEADER__BESTANDSNAAM", "HEADER__EAN_ONTVANGER", "header_ean_sender", "HEADER__SYSTEEM")
        .dropDuplicates()
    )

    dfProductMaxFile = dfMasterProduct.groupBy("product_id", "generic_product_id", "language_code") \
                                     .agg(max("ingestion_file").alias("ingestionFile")) \
                                     .selectExpr("product_id as product_id_file", "generic_product_id as generic_product_id_file", "language_code as language_code_file", "ingestionFile")    

    dfMasterProduct = dfMasterProduct.join(
        dfProductMaxFile, 
        (dfMasterProduct.product_id == dfProductMaxFile.product_id_file)
        & (dfMasterProduct.generic_product_id == dfProductMaxFile.generic_product_id_file)
        & (dfMasterProduct.language_code == dfProductMaxFile.language_code_file)
        & (dfMasterProduct.ingestion_file == dfProductMaxFile.ingestionFile)
    )

    logger.info("End of TsapProductMaster def")

    return dfMasterProduct
