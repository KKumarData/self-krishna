import os
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType
from utils.modules import logger
from functools import reduce
from pyspark.sql.functions import input_file_name

# Instanciate Logger
logger = logger()


def TcurtainStock(**kwargs):

    logger.info("Invoked TcurtainStock def")

    dfcurtainStock = kwargs.get("df")

    oldColumns = dfcurtainStock.schema.names
    dfcurtainStock = reduce(
        lambda dfEdcStocks, idx: dfcurtainStock.withColumnRenamed(
            oldColumns[idx], "curtaindata"),
        range(len(oldColumns)),
        dfcurtainStock)

    #Extract Creation_date, store_id and Seq_number from header
    logger.info("Extracting creation_date, store_id  and seq_number from header")

    header_df = dfcurtainStock.filter(col("curtaindata").startswith("00AFCON"))
    header_df = (
        header_df.withColumn("store_id", substring('curtaindata',19,4))
        .withColumn("creation_date", substring('curtaindata',25,8))
        .withColumn(
            "creation_date",
            expr(
                "concat(substring(creation_date,1,4),'-', substring(creation_date,5,2),'-',substring(creation_date,7,2))").cast("date")
                )
        .withColumn("seq_number", substring('curtaindata',45,8))
        .withColumn("ingestion_file", input_file_name())
        .drop("curtaindata"))
    
    logger.info("Extraction of creation_date, store_id  and seq_number from header completed")

    #Removing header and footer from file
    logger.info("Removing header and footer from file")

    dfcurtainStock = dfcurtainStock[~dfcurtainStock.curtaindata.contains("00AFCON")]
    dfcurtainStock = dfcurtainStock[~dfcurtainStock.curtaindata.contains("99BIVOD")] 
    
    logger.info("Detailed data creation starts here")

    dfcurtainStock = (
        dfcurtainStock.withColumn("rec_code", substring('curtaindata',0,2))
        .withColumn("filedid_an",substring('curtaindata',3,2))
        .withColumn("product_id",substring('curtaindata',5,8))
        .withColumn("fieldid_qc",substring('curtaindata',30,2))
        .withColumn("stock_quantity",substring('curtaindata',32,8))
        .withColumn("stock_sign",substring('curtaindata',40,1))
        .withColumn("fieldid_st",substring('curtaindata',41,2))
        .withColumn("stock_type",substring('curtaindata',43,3))
        .withColumn("fieldid_ac",substring('curtaindata',46,2))
        .withColumn("actie",substring('curtaindata',48,1))
        .withColumn("ingestion_file", input_file_name())
        .drop("curtaindata"))

    logger.info("Joining header_df with detailed data")
    dfcurtainStock = dfcurtainStock.join(header_df, on='ingestion_file')

    dfcurtainStock = (
        dfcurtainStock.withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("year", year("creation_date"))
        .withColumn("month", month("creation_date"))
        .withColumn("day", dayofmonth("creation_date"))
        )
        
    dfcurtainStock = dfcurtainStock.select("rec_code","filedid_an","product_id", "fieldid_qc", "stock_quantity",\
         "stock_sign", "fieldid_st", "stock_type", "fieldid_ac", "actie",\
          "store_id", "seq_number", "creation_date","load_time","ingestion_date",\
           "year", "month", "day", "ingestion_file"\
           )
    dfcurtainStock = dfcurtainStock.distinct()
    
    logger.info("Detailed data creation ends here")

    logger.info("End of dfcurtainStock def")

    return dfcurtainStock
