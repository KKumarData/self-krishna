import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, logger
from pyspark.sql.window import Window


# Instanciate Logger
logger = logger()


def TsapPrice(**kwargs):

    logger.info("Invoked TsapPrice def")

    df = kwargs.get("df")
    dfMasterPrice = flatten_df(df)
    dfMasterPrice = flatten_df(dfMasterPrice)
    
    #PRINT
    # dfMasterPrice.show(truncate=0)
    
    try:
        dfMasterPrice = flatten_df(df)
        dfMasterPrice = dfMasterPrice.withColumn("ARTIKEL", explode_outer("ARTIKEL"))
        dfMasterPrice = flatten_df(dfMasterPrice)
        dfMasterPrice = flatten_df(dfMasterPrice)
        dfMasterPrice = flatten_df(dfMasterPrice)
        dfMasterPrice = dfMasterPrice.withColumn(
            "ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND",
            explode("ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND"),
        )
        
        dfMasterPrice = flatten_df(dfMasterPrice)
        
    except:
        

        dfMasterPrice = dfMasterPrice.withColumn(
            "ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND",
            explode("ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND")
        )
        dfMasterPrice = flatten_df(dfMasterPrice)
        dfMasterPrice = dfMasterPrice.withColumn(
            "ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND",
            explode("ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND")
        )
        dfMasterPrice = flatten_df(dfMasterPrice)
        
        

    #PRINT
    # dfMasterPrice.printSchema()
    
    # FIX JSON SCHEMA WHEN NOT CONTAIN CUSTOMER
    if not 'ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__SITE' in dfMasterPrice.columns:
        dfMasterPrice = dfMasterPrice.withColumn('ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__SITE', lit('0'))

    if not 'ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__BEGIN' in dfMasterPrice.columns:
        dfMasterPrice = dfMasterPrice.withColumn('ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__BEGIN', lit(0))

    if not 'ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__EIND' in dfMasterPrice.columns:
        dfMasterPrice = dfMasterPrice.withColumn('ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__EIND', lit(0))

    if not 'ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__LOYALTY_ONLY' in dfMasterPrice.columns:
        dfMasterPrice = dfMasterPrice.withColumn('ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__LOYALTY_ONLY', lit('0'))

    if not 'ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__PROMOTIENR' in dfMasterPrice.columns:
        dfMasterPrice = dfMasterPrice.withColumn('ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__PROMOTIENR', lit(0))

    if not 'ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__PROMOTIENR' in dfMasterPrice.columns:
        dfMasterPrice = dfMasterPrice.withColumn('ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__PROMOTIENR', lit(0))

    if not 'ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__VALUE' in dfMasterPrice.columns:
        dfMasterPrice = dfMasterPrice.withColumn('ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__VALUE', lit(''))

    if not 'ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__VKORG' in dfMasterPrice.columns:
        dfMasterPrice = dfMasterPrice.withColumn('ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__VKORG', lit(''))

    if not 'ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__WAARDE' in dfMasterPrice.columns:
        dfMasterPrice = dfMasterPrice.withColumn('ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__WAARDE', lit(0.00))

    dfMasterPrice = (
        dfMasterPrice.withColumnRenamed("HEADER__BESTANDSNAAM", "header_filename")
        .withColumnRenamed("HEADER__EAN_ONTVANGER", "header_ean_receiver")
        .withColumnRenamed("HEADER__EAN_ZENDER", "header_ean_sender")
        .withColumnRenamed("HEADER__SYSTEEM", "header_system")
        .withColumnRenamed("HEADER__VALUE", "header_value")
        .withColumn(
            "header_send_date",
            expr(
                "case when length(HEADER__VERZENDDATUM) <= 8 THEN concat(substring(HEADER__VERZENDDATUM,4,4),'-', substring(HEADER__VERZENDDATUM,2,2),'-', '0' ,substring(HEADER__VERZENDDATUM,1,1)) ELSE concat(substring(HEADER__VERZENDDATUM,5,4),'-', substring(HEADER__VERZENDDATUM,3,2),'-', '0' ,substring(HEADER__VERZENDDATUM,1,2)) END"
            ).cast("date"),
        )
        .withColumnRenamed("HEADER__VERZENDTIJD", "header_send_time")
        .withColumnRenamed("ARTIKEL__ARTIKEL", "product_id")
        .withColumn("product_id", col("product_id").cast("bigint"))
        .withColumnRenamed(
            "ARTIKEL_ARTIKEL_PRIJZEN__ARTIKELNUMMER", "price_product_id_number"
        )
        .withColumnRenamed(
            "ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND__CONDITIE", "price_condition"
        )
        .withColumnRenamed(
            "ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__BEGIN",
            "price_condition_start",
        )
        .withColumn(
            "price_condition_start",
            expr(
                "concat(substring(price_condition_start, 1,4), '-', substring(price_condition_start, 5,2), '-', substring(price_condition_start, 7,2))"
            ).cast("date"),
        )
        .withColumnRenamed(
            "ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__EIND",
            "price_condition_end",
        )
        .withColumn(
            "price_condition_end",
            expr(
                "concat(substring(price_condition_end, 1,4), '-', substring(price_condition_end, 5,2), '-', substring(price_condition_end, 7,2))"
            ).cast("date"),
        )
        .withColumnRenamed(
            "ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__LOYALTY_ONLY",
            "price_condition_loyalty_only",
        )
        .withColumnRenamed(
            "ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__PROMOTIENR",
            "price_condition_promotion_number",
        )
        .withColumnRenamed(
            "ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__SITE",
            "price_condition_store",
        )
        .withColumnRenamed(
            "ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__VALUE",
            "price_condition_value",
        )
        .withColumnRenamed(
            "ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__VKORG",
            "price_condition_sales_organisation",
        )
        .withColumnRenamed(
            "ARTIKEL_ARTIKEL_PRIJZEN_ARTIKEL_COND_ARTIKEL_COND__WAARDE",
            "price_condition__value",
        )
        .withColumn(
            "price_condition__value", col("price_condition__value").cast("double")
        )
        .withColumn("year", year("price_condition_start"))
        .withColumn("month", month("price_condition_start"))
        .withColumn("day", dayofmonth("price_condition_start"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .withColumn("rank", dense_rank().over(Window.partitionBy("product_id", "price_condition", "price_condition_sales_organisation").orderBy(asc("price_condition_start"))))
        .select(
            "product_id",
            "price_product_id_number",
            "price_condition",
            "price_condition_start",
            "price_condition_end",
            "price_condition_loyalty_only",
            "price_condition_promotion_number",
            "price_condition_store",
            "price_condition_value",
            "price_condition_sales_organisation",
            "price_condition__value",
            "year",
            "month",
            "day",
            "load_time",
            "ingestion_date",
            "ingestion_file",
            "rank"
        )
        .dropDuplicates(['product_id', 'price_condition','price_condition_sales_organisation', 'price_condition_start', 'price_condition_end'])
    )

    logger.info("End of TsapPrice def")


    return dfMasterPrice
