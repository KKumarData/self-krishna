DO
$do$
declare var_job_name varchar = 			'space-planogram-product';
var_raw_path varchar = 					's3a://hema-cdp-prod-datalake-raw/space-planogram-product/';
var_curated_path varchar = 				's3a://hema-cdp-prod-datalake-curated/space-planogram-product/';
var_file_format varchar = 				'csv';
var_dcl_channel varchar = 				'space-planogram-product'; 
var_flag_enable boolean = 				'1';
var_job_mode varchar = 					'delta'; 
var_job_env varchar = 					'cloud';
var_partition_columns varchar = 		$$"['year','month','day']"$$; 
var_start_date varchar = 				'2021-05-12';
var_execution_date_formatted varchar = 	'YYYY-MM-DD'; 
var_delta_period varchar = 				$$['2021-05-12']$$;
var_job_location varchar =  			'/home/hadoop/main.py'; 
var_redshift_tables varchar = 			$$['space_planogram_product']$$; 
var_redshift_views varchar = 			$$['space_planogram_product_mv']$$; 
var_job_type varchar = 					'pyspark';
var_row_tag varchar =					'';
var_is_zipped_in_dcl int =				0;
var_schedule_interval varchar =			'0 5 * * *';
var_redshift_schema varchar =			'curated';
var_redshift_database varchar =			'cdap_datalake';
var_data_retention_period_raw int =		null;
var_data_retention_period_curated int =	null;
var_dcl_timezone varchar =				'Europe/Amsterdam';
var_flag_hist boolean = 				'';
var_rowkey varchar =					$$[['pog_dbkey','fix_dbkey','prod_id']]$$;
BEGIN
   IF EXISTS (SELECT 1 FROM data_pipeline.job where job_name = var_job_name) 
   THEN
      UPDATE data_pipeline.job 
     	SET raw_path = var_raw_path,
     		curated_path = var_curated_path,
     		file_format = var_file_format,
     		dcl_channel = var_dcl_channel,
     		flag_enable = var_flag_enable,
     		job_mode = var_job_mode,
     		job_env = var_job_env,
     		partition_columns = var_partition_columns,
     		start_date = var_start_date,
     		execution_date_formatted = var_execution_date_formatted,
     		delta_period = var_delta_period,
     		job_location = var_job_location,
     		redshift_tables = var_redshift_tables,
     		redshift_views = var_redshift_views,
     		job_type = var_job_type,
			row_tag = var_row_tag,
			is_zipped_in_dcl = var_is_zipped_in_dcl,
			schedule_interval = var_schedule_interval,
			redshift_schema = var_redshift_schema,
			data_retention_period_raw = var_data_retention_period_raw,
			data_retention_period_curated = var_data_retention_period_curated,
			dcl_timezone = var_dcl_timezone,
			flag_hist = var_flag_hist,
			rowkey = var_rowkey
		WHERE job_name = var_job_name
     	;
   ELSE
     insert into data_pipeline.job (job_name, raw_path, curated_path, file_format, dcl_channel, flag_enable, job_mode, job_env, partition_columns, start_date, 
     								execution_date_formatted, job_location, delta_period, redshift_tables, redshift_views, job_type, row_tag, is_zipped_in_dcl,
										schedule_interval, redshift_schema, data_retention_period_raw, data_retention_period_curated, dcl_timezone, flag_hist, rowkey)
     select var_job_name, var_raw_path, var_curated_path, var_file_format, var_dcl_channel, var_flag_enable, var_job_mode, var_job_env, var_partition_columns,
     		var_start_date, var_execution_date_formatted, var_delta_period, var_job_location, var_redshift_tables, var_redshift_views, var_job_type, var_row_tag, var_is_zipped_in_dcl, var_schedule_interval, var_redshift_schema, var_data_retention_period_raw, var_data_retention_period_curated, var_dcl_timezone,  var_flag_hist, var_rowkey
    ;
   END IF;
END
$do$