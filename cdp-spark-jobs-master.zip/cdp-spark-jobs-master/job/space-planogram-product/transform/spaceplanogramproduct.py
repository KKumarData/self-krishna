import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TSpacePlanogramProduct(**kwargs):

    logger.info("Invoked TSpacePlanogramProduct def")

    dfspaceplanoproduct = kwargs.get("df")

    columns = "pog_dbkey;pog_assortment;pog_livedate;seg_number;fix_dbkey;prod_id;pos_width;pos_height;pos_depth;pos_linear;pos_square;pos_cubic;pos_angle;pos_slope;pos_roll;pos_x;pos_y;pos_z;pos_capacity;pos_hfacings;pos_vfacings;pos_dfacings;pos_xnested;pos_ynested;pos_znested;pos_xcapped;pos_ycapped;pos_zcapped;prod_width;prod_height;prod_depth;prod_nest_width;prod_nest_height;prod_nest_depth;pos_merchstyle;pos_rankx;pos_ranky;pos_rankz;pos_ind_peg;pos_ind_localspaceproduct".split(";")
    
    oldColumns = dfspaceplanoproduct.schema.names
    dfspaceplanoproduct = reduce(lambda dfspaceplanoproduct, idx: dfspaceplanoproduct.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfspaceplanoproduct)
    
    dfspaceplanoproduct = dfspaceplanoproduct.withColumn("filename_reverse", input_file_name())
    dfspaceplanoproduct = dfspaceplanoproduct.withColumn("filename_reverse", reverse(split(reverse(dfspaceplanoproduct.filename_reverse), '/')[0]))

    dfspaceplanoproduct = (
        dfspaceplanoproduct.withColumn("pog_dbkey", col("pog_dbkey").cast("int"))
        .withColumn("pog_livedate", date_format(to_date(col("pog_livedate"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
        .withColumn("seg_number", col("seg_number").cast("short"))
        .withColumn("fix_dbkey", col("fix_dbkey").cast("int"))
        .withColumn("pos_width", col("pos_width").cast("decimal(8,3)"))
        .withColumn("pos_height", col("pos_height").cast("decimal(8,3)"))
        .withColumn("pos_depth", col("pos_depth").cast("decimal(8,3)"))
        .withColumn("pos_linear", col("pos_linear").cast("decimal(8,3)"))
        .withColumn("pos_square", col("pos_square").cast("decimal(8,3)"))
        .withColumn("pos_cubic", col("pos_cubic").cast("decimal(10,3)"))
        .withColumn("pos_angle", col("pos_angle").cast("short"))
        .withColumn("pos_slope", col("pos_slope").cast("short"))
        .withColumn("pos_roll", col("pos_roll").cast("short"))
        .withColumn("pos_x", col("pos_x").cast("decimal(8,3)"))
        .withColumn("pos_y", col("pos_y").cast("decimal(8,3)"))
        .withColumn("pos_z", col("pos_z").cast("decimal(8,3)"))
        .withColumn("pos_capacity", col("pos_capacity").cast("short"))
        .withColumn("pos_hfacings", col("pos_hfacings").cast("short"))
        .withColumn("pos_vfacings", col("pos_vfacings").cast("short"))
        .withColumn("pos_dfacings", col("pos_dfacings").cast("short"))
        .withColumn("pos_xnested", col("pos_xnested").cast("byte"))
        .withColumn("pos_ynested", col("pos_ynested").cast("byte"))
        .withColumn("pos_znested", col("pos_znested").cast("byte"))
        .withColumn("pos_xcapped", col("pos_xcapped").cast("byte"))
        .withColumn("pos_ycapped", col("pos_ycapped").cast("byte"))
        .withColumn("pos_zcapped", col("pos_zcapped").cast("byte"))
        .withColumn("prod_width", col("prod_width").cast("decimal(8,3)"))
        .withColumn("prod_height", col("prod_height").cast("decimal(8,3)"))
        .withColumn("prod_depth", col("prod_depth").cast("decimal(8,3)"))
        .withColumn("prod_nest_width", col("prod_nest_width").cast("decimal(8,3)"))
        .withColumn("prod_nest_height", col("prod_nest_height").cast("decimal(8,3)"))
        .withColumn("prod_nest_depth", col("prod_nest_depth").cast("decimal(8,3)"))
        .withColumn("pos_rankx", col("pos_rankx").cast("short"))
        .withColumn("pos_ranky", col("pos_ranky").cast("short"))
        .withColumn("pos_rankz", col("pos_rankz").cast("short"))
        .withColumn("pos_ind_peg", col("pos_ind_peg").cast("short"))
        .withColumn("pos_ind_localspaceproduct", col("pos_ind_localspaceproduct").cast("byte"))
        .withColumn("creation_date", concat(lit('20'),substring('filename_reverse',22,6)))
        .withColumn(
                            "creation_date",
                            expr(
                                "concat(substring(creation_date,1,4),'-',substring(creation_date,5,2),'-',substring(creation_date,7,2))").cast("date")
                                )
        .withColumn("load_time", current_timestamp())
        .withColumnRenamed("creation_date","ingestion_date") \
        .withColumn("year", year("ingestion_date"))
        .withColumn("month", month("ingestion_date"))
        .withColumn("day", dayofmonth("ingestion_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse"))

    wdw = Window.partitionBy('pog_dbkey','pog_assortment','seg_number','fix_dbkey','prod_id').orderBy(desc('ingestion_date'))
    dfspaceplanoproduct = dfspaceplanoproduct.withColumn('Rank',rank().over(wdw))
    dfspaceplanoproduct = dfspaceplanoproduct.filter(dfspaceplanoproduct.Rank == 1).drop(dfspaceplanoproduct.Rank)
    dfspaceplanoproduct = dfspaceplanoproduct.dropDuplicates(['pog_dbkey','pog_assortment','pog_livedate','seg_number','fix_dbkey','prod_id','pos_width','pos_height','pos_depth','pos_linear','pos_square','pos_cubic','pos_angle','pos_slope','pos_roll','pos_x','pos_y','pos_z','pos_capacity','pos_hfacings','pos_vfacings','pos_dfacings','pos_xnested','pos_ynested','pos_znested','pos_xcapped','pos_ycapped','pos_zcapped','prod_width','prod_height','prod_depth','prod_nest_width','prod_nest_height','prod_nest_depth','pos_merchstyle','pos_rankx','pos_ranky','pos_rankz','pos_ind_peg','pos_ind_localspaceproduct'])
    
    dfspaceplanoproduct = dfspaceplanoproduct.select("pog_dbkey","pog_assortment","pog_livedate","seg_number","fix_dbkey","prod_id","pos_width","pos_height","pos_depth","pos_linear","pos_square","pos_cubic","pos_angle","pos_slope","pos_roll","pos_x","pos_y","pos_z","pos_capacity","pos_hfacings","pos_vfacings","pos_dfacings","pos_xnested","pos_ynested","pos_znested","pos_xcapped","pos_ycapped","pos_zcapped","prod_width","prod_height","prod_depth","prod_nest_width","prod_nest_height","prod_nest_depth","pos_merchstyle","pos_rankx","pos_ranky","pos_rankz","pos_ind_peg","pos_ind_localspaceproduct","load_time","ingestion_date","ingestion_file","year","month","day").dropDuplicates()
    logger.info("End of TSpacePlanogramProduct")
    
    return dfspaceplanoproduct
