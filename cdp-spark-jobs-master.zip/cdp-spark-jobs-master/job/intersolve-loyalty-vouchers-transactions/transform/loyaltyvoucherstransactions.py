import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name

# Instanciate Logger
logger = logger()

def inputSchema(**kwargs):

    logger.info("defining file like schema")

    loyaltySchema = StructType([StructField('record_number',StringType(),True),
        StructField('coupon_id',StringType(),True),
            StructField('card_id',StringType(),True),
                StructField('hema_customer_id',StringType(),True),
                    StructField('transaction_type',StringType(),True),
                        StructField('transaction_date_time',StringType(),True),
                            StructField('client_reference',StringType(),True),
                                StructField('host_reference',StringType(),True),
                                    StructField('pos_id',StringType(),True),
                                        StructField('voucher_value',StringType(),True),
                                            StructField('currency',StringType(),True),
                                                StructField('voucher_code',StringType(),True),
                                                    StructField('retailer_id',StringType(),True),
                                                        StructField('cancelled_host_reference',StringType(),True),
                                                            StructField('na',StringType(),True)])

    return loyaltySchema

def TLoyaltyVouchersTransactions(**kwargs):

    logger.info('Invoked TLoyaltyVouchersTransactions def')

    dfLoyVouTxs = kwargs.get("df")

    dfLoyVouTxs = dfLoyVouTxs.withColumn("filename_reverse", input_file_name())
    dfLoyVouTxs = dfLoyVouTxs.withColumn("filename_reverse", reverse(split(reverse(dfLoyVouTxs.filename_reverse), '/')[0]))

    dfLoyVouTxs = dfLoyVouTxs.withColumn("column_date", substring('filename_reverse',11,8)) \
                           .withColumn("hema_customer_id",expr("concat('{',hema_customer_id,'}')")) \
                           .withColumnRenamed("column_date", "file_date") \
                           .withColumn(
                            "file_date",
                            expr(
                                "concat(substring(file_date,1,4),'-', substring(file_date,5,2),'-',substring(file_date,7,2))").cast("date")
                                ) \
                           .withColumn("load_time",current_timestamp()) \
                           .withColumn("file_date",date_format(to_date(col("file_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date")) \
                           .withColumnRenamed("file_date","ingestion_date") \
                           .withColumn("year", year("ingestion_date")) \
                           .withColumn("month", month("ingestion_date")) \
                           .withColumn("day", dayofmonth("ingestion_date")) \
                           .withColumn("ingestion_file", input_file_name()) \
                           .drop('filename_reverse') \

    wdw = Window.partitionBy('card_id','transaction_date_time','host_reference').orderBy(desc('ingestion_date'))
    dfLoyVouTxs = dfLoyVouTxs.withColumn('Rank',rank().over(wdw))
    dfLoyVouTxs = dfLoyVouTxs.filter(dfLoyVouTxs.Rank == 1).drop(dfLoyVouTxs.Rank)
    dfLoyVouTxs = dfLoyVouTxs.dropDuplicates(['coupon_id','card_id','hema_customer_id','transaction_type','transaction_date_time','client_reference','host_reference','pos_id','voucher_value','currency','voucher_code','retailer_id','cancelled_host_reference','na'])

    dfLoyVouTxs = dfLoyVouTxs.select("record_number","coupon_id","card_id","hema_customer_id","transaction_type","transaction_date_time","client_reference","host_reference","pos_id","voucher_value","currency","voucher_code","retailer_id","cancelled_host_reference","na","load_time","ingestion_date","ingestion_file","year","month","day")

    logger.info('End of TLoyaltyVouchersTransactions def')

    return dfLoyVouTxs