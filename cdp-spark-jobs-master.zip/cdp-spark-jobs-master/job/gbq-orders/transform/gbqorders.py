import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name

# Instanciate Logger
logger = logger()

def TGBQOrders(**kwargs):

    logger.info('Invoked TGBQOrders def')

    dfGBOrd = kwargs.get("df")

    columns = "date;country;contains_nonpastry;platform;transaction_id;device;source;medium;campaign;default_channel_grouping;transactions".split(";")
    oldColumns=dfGBOrd.schema.names
    dfGBOrd = reduce(lambda dfGBOrd, idx: dfGBOrd.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfGBOrd)
    
    dfGBOrd = dfGBOrd.withColumn("filename_reverse", input_file_name())
    dfGBOrd = dfGBOrd.withColumn("filename_reverse", reverse(split(reverse(dfGBOrd.filename_reverse), '/')[0]))
    
    dfGBOrd = dfGBOrd.withColumn("column_date", substring('filename_reverse',1,8)) \
                           .withColumnRenamed("column_date", "file_date") \
                           .withColumn("load_time",current_timestamp()) \
                           .withColumnRenamed("filename_reverse","ingestion_file") \
                           .withColumn("file_date",date_format(to_date(col("file_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date")) \
                           .withColumnRenamed("file_date","ingestion_date") \
                           .withColumn("year", year("ingestion_date")) \
                           .withColumn("month", month("ingestion_date")) \
                           .withColumn("day", dayofmonth("ingestion_date")) \
                           .withColumn(
                                                  "date",
                                                  expr(
                                                       "concat(substring(date,1,4),'-', substring(date,5,2),'-',substring(date,7,2))").cast("date")
                                                      )

    wdw = Window.partitionBy('date','country','transaction_id').orderBy(desc('ingestion_date'))
    dfGBOrd = dfGBOrd.withColumn('Rank',rank().over(wdw))
    dfGBOrd = dfGBOrd.filter(dfGBOrd.Rank == 1).drop(dfGBOrd.Rank)
    dfGBOrd = dfGBOrd.dropDuplicates(['date','country','contains_nonpastry','platform','transaction_id','device','source','medium','campaign','default_channel_grouping','transactions'])

    dfGBOrd = dfGBOrd.select("date","country","contains_nonpastry","platform","transaction_id","device","source","medium","campaign","default_channel_grouping","transactions","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info('End of TGBQOrders def')

    return dfGBOrd
