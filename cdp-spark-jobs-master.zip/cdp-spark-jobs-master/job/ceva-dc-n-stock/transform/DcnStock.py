import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import *
from utils.modules import logger
from functools import reduce
from datetime import datetime

# Instanciate Logger
logger = logger()


def TDcnStockDaily(**kwargs):

    logger.info("Invoked TDcnStockDaily def")
    
    dfDcnStock = kwargs.get("df")
    
    columns = "dummy_col_dcnstock;".split(";")
    
    oldColumns=dfDcnStock.schema.names
    dfDcnStock = reduce(lambda dfDcnStock, idx: dfDcnStock.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfDcnStock)

    #Removing of header and Footer
    dfDcnStock = dfDcnStock[~dfDcnStock.dummy_col_dcnstock.contains(":000MD")]
    dfDcnStock = dfDcnStock[~dfDcnStock.dummy_col_dcnstock.contains(":999MD")]

    #Creation of few new columns
    dfDcnStock=dfDcnStock.withColumn('date_code',substring('dummy_col_dcnstock',7,8))\
	   .withColumn('sequence_number',substring('dummy_col_dcnstock',17,6))\
       .withColumn('site_type',substring('dummy_col_dcnstock',25,4))\
	   .withColumn('article_number',substring('dummy_col_dcnstock',31,10))\
	   .withColumn('article_number',rtrim(col('article_number')))\
	   .withColumn('quantity',substring('dummy_col_dcnstock',51,7))\
	   .withColumn('sales_office',substring('dummy_col_dcnstock',60,4))\
	   .withColumn('stock_status',substring('dummy_col_dcnstock',74,3))\
	   .withColumn('pj',substring('dummy_col_dcnstock',77,2))

    #Dropping dummy column
    dfDcnStock = dfDcnStock.drop('dummy_col_dcnstock')

    #Converting datatypes
    dfDcnStock =dfDcnStock.withColumn("quantity", col("quantity").cast("int"))\
                          .withColumn("article_number", col("article_number").cast("bigint"))\
	                      .withColumn("date_code",expr("concat(substring(date_code,1,4),'-', substring(date_code,5,2),'-',substring(date_code,7,2))")\
                          .cast("date"))

    dfDcnStock = dfDcnStock.withColumn("ingestion_date",col("date_code"))\
                            .withColumn("ingestion_file", input_file_name()) \
	                        .withColumn("load_time",current_timestamp())\
                            .withColumn("year", year("ingestion_date"))\
	                       .withColumn("month", month("ingestion_date"))\
	                       .withColumn("day", dayofmonth("ingestion_date"))

    dfDcnStock=dfDcnStock.select( "date_code","sequence_number","site_type","article_number","quantity", 
                                    "sales_office","stock_status","pj","load_time","ingestion_date","ingestion_file",
                                    "year","month","day")
                           
    logger.info("End of TDcnStockDaily def")
    
    return dfDcnStock