import os
import logging 
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
import hashlib
from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql.functions import input_file_name

logger = logger()

def TLoyaltyCardHolder(**kwargs):

    logger.info('Invoked TLoyaltyCardHolder def')

    dfLoyCardHold = kwargs.get("df")

    columns = "record_number;hema_customer_id;status;global_group_code;retailer_id;registration_date_time;custom_na;customer_title;initials;firstname;middlename;familyname;street;street_number;street_number_suffix;zipcode;city;country;email;phone_home;phone_work;phone_mobile;gender;dateofbirth;custom_1;custom_2;custom_3;custom_4;custom_5;login_username;login_password;must_renew_password;mutation_code;directmail;custom_6;custom_7;custom_8;custom_9;custom_10;culture".split(";")
    oldColumns=dfLoyCardHold.schema.names
    dfLoyCardHold = reduce(lambda dfLoyCardHold, idx: dfLoyCardHold.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfLoyCardHold)
    
    dfLoyCardHold = dfLoyCardHold.withColumn("filename_reverse", input_file_name())
    dfLoyCardHold = dfLoyCardHold.withColumn("filename_reverse", reverse(split(reverse(dfLoyCardHold.filename_reverse), '/')[0]))

    salt = "@)@!-@)#!"
    
    dfLoyCardHold = dfLoyCardHold.withColumn('firstname',sha2(concat_ws(salt, trim(dfLoyCardHold.firstname)), 256),) \
						   .withColumn("hema_customer_id",expr("concat('{',hema_customer_id,'}')")) \
                           .withColumn('middlename',sha2(concat_ws(salt, trim(dfLoyCardHold.middlename)), 256),) \
                           .withColumn('familyname',sha2(concat_ws(salt, trim(dfLoyCardHold.familyname)), 256),) \
                           .withColumn('street',sha2(concat_ws(salt, trim(dfLoyCardHold.street)), 256),) \
                           .withColumn('street_number',sha2(concat_ws(salt, trim(dfLoyCardHold.street_number)), 256),) \
                           .withColumn('street_number_suffix',sha2(concat_ws(salt, trim(dfLoyCardHold.street_number_suffix)), 256),) \
                           .withColumn("email", when(dfLoyCardHold.email == "" ,"")
                                                .when(dfLoyCardHold.email.isNull() ,"" )
                                                .otherwise(sha2(concat_ws(salt, trim(dfLoyCardHold.email)), 256),)) \
                           .withColumn('phone_home',sha2(concat_ws(salt, trim(dfLoyCardHold.phone_home)), 256),) \
                           .withColumn('phone_work',sha2(concat_ws(salt, trim(dfLoyCardHold.phone_work)), 256),) \
                           .withColumn('phone_mobile',sha2(concat_ws(salt, trim(dfLoyCardHold.phone_mobile)), 256),) \
                           .withColumn('login_username',sha2(concat_ws(salt, trim(dfLoyCardHold.login_username)), 256),) \
                           .withColumn('login_password',sha2(concat_ws(salt, trim(dfLoyCardHold.login_password)), 256),) \
                           .withColumn("column_date", substring('filename_reverse',11,8)) \
                           .withColumnRenamed("column_date", "file_date") \
                           .withColumn("load_time",current_timestamp()) \
                           .withColumnRenamed("filename_reverse","ingestion_file") \
                           .withColumn("file_date",date_format(to_date(col("file_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date")) \
                           .withColumnRenamed("file_date","ingestion_date") \
                           .withColumn("year", year("ingestion_date")) \
                           .withColumn("month", month("ingestion_date")) \
                           .withColumn("day", dayofmonth("ingestion_date"))
    dfLoyCardHold = dfLoyCardHold.select("record_number","hema_customer_id","status","global_group_code","retailer_id","registration_date_time","custom_na","customer_title","initials","firstname","middlename","familyname","street","street_number","street_number_suffix","zipcode","city","country","email","phone_home","phone_work","phone_mobile","gender","dateofbirth","custom_1","custom_2","custom_3","custom_4","custom_5","login_username","login_password","must_renew_password","mutation_code","directmail","custom_6","custom_7","custom_8","custom_9","custom_10","culture","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info('End of TLoyaltyCardHolder def')

    return dfLoyCardHold
