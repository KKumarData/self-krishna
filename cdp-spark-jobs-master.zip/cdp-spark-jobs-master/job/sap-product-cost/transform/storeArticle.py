import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import * 
from pyspark.sql.types import *
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def inputSchema(**kwargs):

    logger.info("creating schema")

    dummySchema = StructType([StructField('row_type',StringType(),True),
        StructField('product_id',LongType(),True),
            StructField('product_status',StringType(),True),
                StructField('shelf_location',StringType(),True),
                    StructField('warehouse_flag',StringType(),True),
							StructField('warehouse_location',StringType(), True),
								StructField('moving_average_price',StringType(),True),
									StructField('unit',IntegerType(),True),
										StructField('base_unit',StringType(),True)])

    return dummySchema


def TstoreArticle(**kwargs):

    logger.info("Invoked TstoreStock def")

    dfstoreArticle = kwargs.get("df")

    ################################### HEADER DATA CAPTURE FROM FILE ###################################
    print( '********************  Data capture of Header Data started. ***********************')

    #Filtering only Header data:
    dfstoreArticleHeader = dfstoreArticle.where(col("row_type")=="00")
    #Renaming Columns:
    dfstoreArticleHeader = dfstoreArticleHeader.withColumnRenamed("warehouse_flag","currency")\
                                             .withColumnRenamed("shelf_location","header_store_id")
    #Extracting date from header: 
    dfstoreArticleHeader = dfstoreArticleHeader.withColumn("header_calendar_day", substring('product_status',0,8))\
                                             .withColumn("header_calendar_day",expr("concat(substring(header_calendar_day,1,4),'-',\
                                              substring(header_calendar_day,5,2),'-',substring(header_calendar_day,7,2))").cast("date"))
    #Final Select of header columns:
    dfstoreArticleHeader = dfstoreArticleHeader.select("header_store_id","header_calendar_day","Currency")

    print( '********************  Data capture of Header Data completed. ***********************')

    ################################### DETAIL DATA CAPTURE FROM FILE ###################################
    print( '********************  Data capture of Detailed Data started. ***********************')

    #Picking Filename:
    dfstoreArticle = dfstoreArticle.withColumn("ingestion_file", input_file_name())

    #Creation of store_id & calender_day:
    dfstoreArticle = dfstoreArticle.withColumn("filename_reverse", reverse(split(reverse(dfstoreArticle.ingestion_file), '/')[0]))
    dfstoreArticle = dfstoreArticle.withColumn("store_id", substring('filename_reverse',17,4))\
                                 .withColumn("calendar_day", substring('filename_reverse',22,8))\
                                 .withColumn("calendar_day",expr(
                                  "concat(substring(calendar_day,1,4),'-', substring(calendar_day,5,2),\
                                  '-',substring(calendar_day,7,2))").cast("date"))
    #Replacing ',' with '.' in the moving_average_price:
    dfstoreArticle = dfstoreArticle.withColumn('moving_average_price', translate('moving_average_price', ',', '.').cast('Double'))
    #Creation of Columns:
    dfstoreArticle = dfstoreArticle.withColumn("load_time", current_timestamp())\
                                 .withColumn("ingestion_date", current_date())\
                                 .withColumn("ingestion_file", input_file_name())
                                 .withColumn("year", year("calendar_day"))\
                                 .withColumn("month", month("calendar_day"))\
                                 .withColumn("day", dayofmonth("calendar_day"))
    #Dropping of Columns:
    dfstoreArticle = dfstoreArticle.drop("filename_reverse")
    #Datatype Conversion:
    dfstoreArticle = dfstoreArticle.withColumn("product_id", col("product_id").cast("bigint"))
    #Deletion of Header:
    dfstoreArticle = dfstoreArticle.where(col("row_type")!="00")
    #Deletion of footer:
    dfstoreArticle = dfstoreArticle.where(col("row_type")!="99")

    print( '********************  Data capture of Detailed Data completed. ***********************')


    #persisting the data:
    dfstoreArticle = dfstoreArticle.persist()
    dfstoreArticleHeader = dfstoreArticleHeader.persist()

    ################################### JOINING OF DATAFRAMES FOR BRINGING CURRENCY FROM HEADER ###################################
    dfstoreArticle = dfstoreArticle.join(dfstoreArticleHeader, ((dfstoreArticle.store_id == dfstoreArticleHeader.header_store_id) \
                                  & (dfstoreArticle.calendar_day == dfstoreArticleHeader.header_calendar_day)),\
                                  how='inner').drop("header_store_id","header_calendar_day")
    #Final Select of merged dataframes:
    dfstoreArticle = dfstoreArticle.select("store_id","calendar_day","row_type","product_id","product_status","shelf_location","warehouse_flag",
                                        "warehouse_location","currency","moving_average_price","unit","base_unit",
                                        "ingestion_date","load_time","year","month","day","ingestion_file").distinct()
                                        
    logger.info("End of store stock def")
    
    return dfstoreArticle
