import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def inputSchema(**kwargs):

    logger.info("schema details")

    
    
    dummySchema = StructType([StructField('promo',StringType(),True),
        StructField('promo_pos',StringType(),True),
        StructField('promo_text',StringType(),True),
        StructField('article_number',StringType(),True),
        StructField('article_description',StringType(),True),
        StructField('promo_number_nl',StringType(),True),
        StructField('promo_number_be',StringType(),True),
        StructField('promo_number_lu',StringType(),True),
        StructField('promo_description_nl',StringType(),True),
        StructField('promo_description_be',StringType(),True),
        StructField('promo_description_lu',StringType(),True),
        StructField('start_promotion_nl',StringType(),True),
        StructField('end_promotion_nl',StringType(),True),
        StructField('start_promotion_be',StringType(),True),
        StructField('end_promotion_be',StringType(),True),
        StructField('start_promotion_lu',StringType(),True),
        StructField('end_promotion_lu',StringType(),True),
        StructField('division',StringType(),True),
        StructField('category',StringType(),True),
        StructField('main_group',StringType(),True),
        StructField('cluster_code',StringType(),True),
        StructField('reference_on',StringType(),True),
        StructField('reference_rule',StringType(),True),
        StructField('promotion_group_name',StringType(),True),
        StructField('promotion_group_number',StringType(),True),
        StructField('characteristic',StringType(),True),
        StructField('generic',StringType(),True),
        StructField('open_to_buy',StringType(),True),
        StructField('active_mechanism',StringType(),True),
        StructField('art_type',StringType(),True),
        StructField('slim_art',StringType(),True),
        StructField('bonus_buy',StringType(),True),
        StructField('in_out',StringType(),True),
        StructField('prepack',StringType(),True),
        StructField('number_in_prepack',StringType(),True),
        StructField('prepack_pr',StringType(),True),
        StructField('sales_pr_nl',StringType(),True),
        StructField('sales_pr_belu',StringType(),True),
        StructField('afw_tkpr_nl',StringType(),True),
        StructField('afw_tkpr_belu',StringType(),True),
        StructField('afw_ppdd_nl',StringType(),True),
        StructField('afw_ppdd_belu',StringType(),True),
        StructField('kortingsperc',StringType(),True),
        StructField('actpr_nl',StringType(),True),
        StructField('actpr_belu',StringType(),True),
        StructField('start_toonblist',StringType(),True),
        StructField('eind_toonblist',StringType(),True),
        StructField('zave',StringType(),True),
        StructField('andere_ave',StringType(),True),
        StructField('assrt_grade_nl',StringType(),True),
        StructField('assrt_grade_bel',StringType(),True),
        StructField('maat',StringType(),True),
        StructField('kleur',StringType(),True),
        StructField('status',StringType(),True),
        StructField('rp_profiel',StringType(),True),
        StructField('goed_stroom',StringType(),True),
        StructField('art_via_d2d',StringType(),True),
        StructField('upload_in_sap',StringType(),True),
        StructField('intekenen',StringType(),True),
        StructField('andere_sleutel',StringType(),True),
        StructField('depot',StringType(),True),
        StructField('genereer_po',StringType(),True),
        StructField('internet_jn',StringType(),True),
        StructField('norm_aant_ev',StringType(),True),
        StructField('norm_aant_ab',StringType(),True),
        StructField('norm_aant_bv',StringType(),True),
        StructField('norm_aant_lv',StringType(),True),
        StructField('norm_aant_hint',StringType(),True),
        StructField('norm_aant_int',StringType(),True),
        StructField('norm_aantallen',StringType(),True),
        StructField('actie_aant_ev',StringType(),True),
        StructField('actie_aant_ab',StringType(),True),
        StructField('actie_aant_bv',StringType(),True),
        StructField('actie_aant_lv',StringType(),True),
        StructField('actie_aant_hint',StringType(),True),
        StructField('actie_aant_int',StringType(),True),
        StructField('actie_aantallen',StringType(),True),
        StructField('add_aant_ev',StringType(),True),
        StructField('add_aant_ab',StringType(),True),
        StructField('add_aant_bv',StringType(),True),
        StructField('add_aant_lv',StringType(),True),
        StructField('add_aant_hint',StringType(),True),
        StructField('add_aant_int',StringType(),True),
        StructField('add_aantal',StringType(),True),
        StructField('real_corr_act',StringType(),True),
        StructField('verw_aant_ev',StringType(),True),
        StructField('verw_aant_av',StringType(),True),
        StructField('verw_aant_ab',StringType(),True),
        StructField('verw_aant_be',StringType(),True),
        StructField('verw_aant_lu',StringType(),True),
        StructField('verw_aant_fr',StringType(),True),
        StructField('verw_aant_inl',StringType(),True),
        StructField('verw_aant_ifr',StringType(),True),
        StructField('verw_aant_ibe',StringType(),True),
        StructField('verw_aant_tot',StringType(),True),
        StructField('norm_omz_ev',StringType(),True),
        StructField('norm_omz_ab',StringType(),True),
        StructField('norm_omz_bv',StringType(),True),
        StructField('norm_omz_lv',StringType(),True),
        StructField('norm_omz_hint',StringType(),True),
        StructField('norm_omz_int',StringType(),True),
        StructField('norm_omzet',StringType(),True),
        StructField('actie_omz_ev',StringType(),True),
        StructField('actie_omz_ab',StringType(),True),
        StructField('actie_omz_bv',StringType(),True),
        StructField('actie_omz_lv',StringType(),True),
        StructField('actie_omz_hint',StringType(),True),
        StructField('actie_omz_int',StringType(),True),
        StructField('actie_omzet',StringType(),True),
        StructField('add_omzet_ev',StringType(),True),
        StructField('add_omzet_ab',StringType(),True),
        StructField('add_omzet_bv',StringType(),True),
        StructField('add_omzet_lv',StringType(),True),
        StructField('add_omzet_hint',StringType(),True),
        StructField('add_omzet_int',StringType(),True),
        StructField('add_omzet',StringType(),True),
        StructField('zmap',StringType(),True),
        StructField('norm_marg_ev',StringType(),True),
        StructField('norm_marg_ab',StringType(),True),
        StructField('norm_marg_bv',StringType(),True),
        StructField('norm_marg_lv',StringType(),True),
        StructField('norm_marg_hint',StringType(),True),
        StructField('norm_marg_int',StringType(),True),
        StructField('norm_marge',StringType(),True),
        StructField('prom_marg_ev',StringType(),True),
        StructField('prom_marg_ab',StringType(),True),
        StructField('prom_marg_bv',StringType(),True),
        StructField('prom_marg_lv',StringType(),True),
        StructField('prom_marg_hint',StringType(),True),
        StructField('prom_marg_int',StringType(),True),
        StructField('promo_marge',StringType(),True),
        StructField('add_marge_ev',StringType(),True),
        StructField('add_marge_ab',StringType(),True),
        StructField('add_marge_bv',StringType(),True),
        StructField('add_marge_lv',StringType(),True),
        StructField('add_marge_hint',StringType(),True),
        StructField('add_marge_int',StringType(),True),
        StructField('add_marge',StringType(),True),
        StructField('veract_pv_ev',StringType(),True),
        StructField('veract_pv_ab',StringType(),True),
        StructField('veract_pv_bv',StringType(),True),
        StructField('veract_pv_lv',StringType(),True),
        StructField('veract_pv_hint',StringType(),True),
        StructField('veract_pv_int',StringType(),True),
        StructField('verw_act_pv',StringType(),True),
        StructField('lift_factor',StringType(),True),
        StructField('actie_pv',StringType(),True),
        StructField('tot_fcstunitsnl',StringType(),True),
        StructField('tot_fcstunitsbe',StringType(),True),
        StructField('tot_fcstunitslu',StringType(),True),
        StructField('tot_fcstunitsin',StringType(),True),
        StructField('def_aant_ev',StringType(),True),
        StructField('def_aant_ab',StringType(),True),
        StructField('def_aant_av',StringType(),True),
        StructField('def_aant_be',StringType(),True),
        StructField('def_aant_lu',StringType(),True),
        StructField('def_aant_fr',StringType(),True),
        StructField('def_aant_ibe',StringType(),True),
        StructField('def_aant_ifr',StringType(),True),
        StructField('def_aant_int',StringType(),True),
        StructField('def_aant_tot',StringType(),True),
        StructField('v_ink_d2d_nl',StringType(),True),
        StructField('v_ink_d2d_be',StringType(),True),
        StructField('v_ink_d2d_lu',StringType(),True),
        StructField('v_ink_d2d_int',StringType(),True),
        StructField('ing_vs_v_ev',StringType(),True),
        StructField('ing_vs_v_ab',StringType(),True),
        StructField('ing_vs_v_av',StringType(),True),
        StructField('ing_vs_v_be',StringType(),True),
        StructField('ing_vs_v_lu',StringType(),True),
        StructField('ing_vs_v_fr',StringType(),True),
        StructField('ing_vs_v_int',StringType(),True),
        StructField('ing_vs_v_int_b',StringType(),True),
        StructField('ing_vs_v_int_f',StringType(),True),
        StructField('ing_vs_v_tot',StringType(),True),
        StructField('vdo',StringType(),True),
        StructField('filter_status',StringType(),True),
        StructField('bby_nl',StringType(),True),
        StructField('bby_be',StringType(),True),
        StructField('bby_lu',StringType(),True),
        StructField('setprijs_nl',StringType(),True),
        StructField('setprijs_be',StringType(),True),
        StructField('setprijs_lu',StringType(),True),
        StructField('kperc_nl',StringType(),True),
        StructField('kperc_be',StringType(),True),
        StructField('kperc_lu',StringType(),True),
        StructField('bby_special_nl',StringType(),True),
        StructField('bby_special_be',StringType(),True),
        StructField('bby_special_lu',StringType(),True),
        StructField('freegoods_nl',StringType(),True),
        StructField('freegoods_be',StringType(),True),
        StructField('freegoods_lu',StringType(),True),
        StructField('bby_korting_nl',StringType(),True),
        StructField('bby_korting_be',StringType(),True),
        StructField('bby_korting_lu',StringType(),True),
        StructField('bby_prijsset_nl',StringType(),True),
        StructField('bby_prijsset_be',StringType(),True),
        StructField('bby_prijsset_lu',StringType(),True),
        StructField('loyalty_nl',StringType(),True),
        StructField('loyalty_be',StringType(),True),
        StructField('loyalty_lu',StringType(),True),
        StructField('kasbontxt_nl',StringType(),True),
        StructField('kasbontxt_be',StringType(),True),
        StructField('kasbontxt_benl',StringType(),True),
        StructField('kasbontxt_lu',StringType(),True),
        StructField('artgrp',StringType(),True),
        StructField('aant_halen',StringType(),True),
        StructField('aant_betalen',StringType(),True),
        StructField('pr_eur_nl',StringType(),True),
        StructField('pr_eur_be',StringType(),True),
        StructField('pr_eur_lu',StringType(),True),
        StructField('is_identiek',StringType(),True),
        StructField('assorti',StringType(),True),
        StructField('art_label',StringType(),True),
        StructField('promotiemiddel',StringType(),True),
        StructField('promotiemidd_be',StringType(),True),
        StructField('brochure_week',StringType(),True),
        StructField('pagtp_blauwdr',StringType(),True),
        StructField('broch_num_nl',StringType(),True),
        StructField('broch_num_belu',StringType(),True),
        StructField('pagina_nl',StringType(),True),
        StructField('pagina_belu',StringType(),True),
        StructField('pag_positie_nl',StringType(),True),
        StructField('pag_positie_bl',StringType(),True),
        StructField('art_desc_comm',StringType(),True),
        StructField('art_info',StringType(),True),
        StructField('overig_opm',StringType(),True),
        StructField('kleur_comm',StringType(),True),
        StructField('fotowens',StringType(),True),
        StructField('sample_av',StringType(),True),
        StructField('foto_exist',StringType(),True),
        StructField('foto_broch',StringType(),True),
        StructField('add_foto',StringType(),True),
        StructField('assrt_grade_pro',StringType(),True),
        StructField('dtppr_nl',StringType(),True),
        StructField('dtppr_belu',StringType(),True),
        StructField('dtp_datum',StringType(),True),
        StructField('aanb_type_nl',StringType(),True),
        StructField('aanb_type_be',StringType(),True),
        StructField('aanb_type_lu',StringType(),True),
        StructField('real_prom_aant',StringType(),True),
        StructField('real_lift_fact',StringType(),True),
        StructField('real_add_aanta',StringType(),True),
        StructField('rea_omzet',StringType(),True),
        StructField('rea_add_omzet',StringType(),True),
        StructField('eff_perc',StringType(),True),
        StructField('real_eff_perc',StringType(),True),
        StructField('real_promo_mar',StringType(),True),
        StructField('real_add_marge',StringType(),True),
        StructField('real_act_pv',StringType(),True),
        StructField('kasbontxt_de',StringType(),True),
        StructField('kasbontxt_fr',StringType(),True),
        StructField('lbb_local',StringType(),True),
        StructField('lbb_city',StringType(),True),
        StructField('lbb_land',StringType(),True),
        StructField('lbb_prio',StringType(),True),
        StructField('stock_clearance',StringType(),True),
        StructField('btw_nl',StringType(),True),
        StructField('btw_be',StringType(),True),
        StructField('btw_lu',StringType(),True),
        StructField('lock_key',StringType(),True),
        StructField('bbynr_nl',StringType(),True),
        StructField('bbynr_be',StringType(),True),
        StructField('bbynr_lu',StringType(),True),
        StructField('verkpr_old_nl',StringType(),True),
        StructField('wijzdat_vp_nl',StringType(),True),
        StructField('verkpr_old_belu',StringType(),True),
        StructField('wijzdat_vp_belu',StringType(),True),
        StructField('na',StringType(),True)])


    return dummySchema
def TSapPromo(**kwargs):

    logger.info("Invoked TSapPromo def")

    dfsappromotions = kwargs.get("df")

    # columns = "promo;promo_pos;promo_text;article_number;article_description;promo_number_nl;promo_number_be;promo_number_lu;promo_description_nl;promo_description_be;promo_description_lu;start_promotion_nl;end_promotion_nl;start_promotion_be;end_promotion_be;start_promotion_lu;end_promotion_lu;division;category;main_group;cluster_code;reference_on;reference_rule;promotion_group_name;promotion_group_number;characteristic;generic;open_to_buy;active_mechanism;art_type;slim_art;bonus_buy;in_out;prepack;number_in_prepack;prepack_pr;sales_pr_nl;sales_pr_belu;afw_tkpr_nl;afw_tkpr_belu;afw_ppdd_nl;afw_ppdd_belu;kortingsperc;actpr_nl;actpr_belu;start_toonblist;eind_toonblist;zave;andere_ave;assrt_grade_nl;assrt_grade_bel;maat;kleur;status;rp_profiel;goed_stroom;art_via_d2d;upload_in_sap;intekenen;andere_sleutel;depot;genereer_po;internet_jn;norm_aant_ev;norm_aant_ab;norm_aant_bv;norm_aant_lv;norm_aant_hint;norm_aant_int;norm_aantallen;actie_aant_ev;actie_aant_ab;actie_aant_bv;actie_aant_lv;actie_aant_hint;actie_aant_int;actie_aantallen;add_aant_ev;add_aant_ab;add_aant_bv;add_aant_lv;add_aant_hint;add_aant_int;add_aantal;real_corr_act;verw_aant_ev;verw_aant_av;verw_aant_ab;verw_aant_be;verw_aant_lu;verw_aant_fr;verw_aant_inl;verw_aant_ifr;verw_aant_ibe;verw_aant_tot;norm_omz_ev;norm_omz_ab;norm_omz_bv;norm_omz_lv;norm_omz_hint;norm_omz_int;norm_omzet;actie_omz_ev;actie_omz_ab;actie_omz_bv;actie_omz_lv;actie_omz_hint;actie_omz_int;actie_omzet;add_omzet_ev;add_omzet_ab;add_omzet_bv;add_omzet_lv;add_omzet_hint;add_omzet_int;add_omzet;zmap;norm_marg_ev;norm_marg_ab;norm_marg_bv;norm_marg_lv;norm_marg_hint;norm_marg_int;norm_marge;prom_marg_ev;prom_marg_ab;prom_marg_bv;prom_marg_lv;prom_marg_hint;prom_marg_int;promo_marge;add_marge_ev;add_marge_ab;add_marge_bv;add_marge_lv;add_marge_hint;add_marge_int;add_marge;veract_pv_ev;veract_pv_ab;veract_pv_bv;veract_pv_lv;veract_pv_hint;veract_pv_int;verw_act_pv;lift_factor;actie_pv;tot_fcstunitsnl;tot_fcstunitsbe;tot_fcstunitslu;tot_fcstunitsin;def_aant_ev;def_aant_ab;def_aant_av;def_aant_be;def_aant_lu;def_aant_fr;def_aant_ibe;def_aant_ifr;def_aant_int;def_aant_tot;v_ink_d2d_nl;v_ink_d2d_be;v_ink_d2d_lu;v_ink_d2d_int;ing_vs_v_ev;ing_vs_v_ab;ing_vs_v_av;ing_vs_v_be;ing_vs_v_lu;ing_vs_v_fr;ing_vs_v_int;ing_vs_v_int_b;ing_vs_v_int_f;ing_vs_v_tot;vdo;filter_status;bby_nl;bby_be;bby_lu;setprijs_nl;setprijs_be;setprijs_lu;kperc_nl;kperc_be;kperc_lu;bby_special_nl;bby_special_be;bby_special_lu;freegoods_nl;freegoods_be;freegoods_lu;bby_korting_nl;bby_korting_be;bby_korting_lu;bby_prijsset_nl;bby_prijsset_be;bby_prijsset_lu;loyalty_nl;loyalty_be;loyalty_lu;kasbontxt_nl;kasbontxt_be;kasbontxt_benl;kasbontxt_lu;artgrp;aant_halen;aant_betalen;pr_eur_nl;pr_eur_be;pr_eur_lu;is_identiek;assorti;art_label;promotiemiddel;promotiemidd_be;brochure_week;pagtp_blauwdr;broch_num_nl;broch_num_belu;pagina_nl;pagina_belu;pag_positie_nl;pag_positie_bl;art_desc_comm;art_info;overig_opm;kleur_comm;fotowens;sample_av;foto_exist;foto_broch;add_foto;assrt_grade_pro;dtppr_nl;dtppr_belu;dtp_datum;aanb_type_nl;aanb_type_be;aanb_type_lu;real_prom_aant;real_lift_fact;real_add_aanta;rea_omzet;rea_add_omzet;eff_perc;real_eff_perc;real_promo_mar;real_add_marge;real_act_pv;kasbontxt_de;kasbontxt_fr;lbb_local;lbb_city;lbb_land;lbb_prio;stock_clearance;btw_nl;btw_be;btw_lu;lock_key;bbynr_nl;bbynr_be;bbynr_lu;verkpr_old_nl;wijzdat_vp_nl;verkpr_old_belu;wijzdat_vp_belu;na;".split(";")
    
    # oldColumns = dfsappromotions.schema.names
    # dfsappromotions = reduce(lambda dfsappromotions, idx: dfsappromotions.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfsappromotions)
    
    dfsappromotions = dfsappromotions.withColumn("filename_reverse", input_file_name())
    dfsappromotions = dfsappromotions.withColumn("filename_reverse", reverse(split(reverse(dfsappromotions.filename_reverse), '/')[0]))

    dfsappromotions = (
        dfsappromotions.withColumn("start_promotion_nl", date_format(to_date(col("start_promotion_nl"),"dd-MM-yyyy"),"yyyy-MM-dd").cast("date"))
        .withColumn("end_promotion_nl", date_format(to_date(col("end_promotion_nl"),"dd-MM-yyyy"),"yyyy-MM-dd").cast("date"))
        .withColumn("start_promotion_be", date_format(to_date(col("start_promotion_be"),"dd-MM-yyyy"),"yyyy-MM-dd").cast("date"))
        .withColumn("end_promotion_be", date_format(to_date(col("end_promotion_be"),"dd-MM-yyyy"),"yyyy-MM-dd").cast("date"))
        .withColumn("start_promotion_lu", date_format(to_date(col("start_promotion_lu"),"dd-MM-yyyy"),"yyyy-MM-dd").cast("date"))
        .withColumn("end_promotion_lu", date_format(to_date(col("end_promotion_lu"),"dd-MM-yyyy"),"yyyy-MM-dd").cast("date"))
        .withColumn("number_in_prepack", col("number_in_prepack").cast("int"))
        .withColumn("prepack_pr", col("prepack_pr").cast("decimal(17,2)"))
        .withColumn("sales_pr_nl", col("sales_pr_nl").cast("decimal(17,2)"))
        .withColumn("sales_pr_belu", col("sales_pr_belu").cast("decimal(17,2)"))
        .withColumn("afw_tkpr_nl", col("afw_tkpr_nl").cast("decimal(17,2)"))
        .withColumn("afw_tkpr_belu", col("afw_tkpr_belu").cast("decimal(17,2)"))
        .withColumn("afw_ppdd_nl", date_format(to_date(col("afw_ppdd_nl"),"MM-dd-yyyy"),"yyyy-MM-dd").cast("date"))
        .withColumn("afw_ppdd_belu", date_format(to_date(col("afw_ppdd_belu"),"MM-dd-yyyy"),"yyyy-MM-dd").cast("date"))
        .withColumn("kortingsperc", col("kortingsperc").cast("decimal(17,2)"))
        .withColumn("actpr_nl", col("actpr_nl").cast("decimal(17,2)"))
        .withColumn("actpr_belu", col("actpr_belu").cast("decimal(17,2)"))
        .withColumn("start_toonblist", date_format(to_date(col("start_toonblist"),"MM-dd-yyyy"),"yyyy-MM-dd").cast("date"))
        .withColumn("eind_toonblist", date_format(to_date(col("eind_toonblist"),"MM-dd-yyyy"),"yyyy-MM-dd").cast("date"))
        .withColumn("zave", col("zave").cast("int"))
        .withColumn("andere_ave", col("andere_ave").cast("int"))
        .withColumn("norm_aant_ev", col("norm_aant_ev").cast("int"))
        .withColumn("norm_aant_ab", col("norm_aant_ab").cast("int"))
        .withColumn("norm_aant_bv", col("norm_aant_bv").cast("int"))
        .withColumn("norm_aant_lv", col("norm_aant_lv").cast("int"))
        .withColumn("norm_aant_hint", col("norm_aant_hint").cast("int"))
        .withColumn("norm_aant_int", col("norm_aant_int").cast("int"))
        .withColumn("norm_aantallen", col("norm_aantallen").cast("int"))
        .withColumn("actie_aant_ev", col("actie_aant_ev").cast("int"))
        .withColumn("actie_aant_ab", col("actie_aant_ab").cast("int"))
        .withColumn("actie_aant_bv", col("actie_aant_bv").cast("int"))
        .withColumn("actie_aant_lv", col("actie_aant_lv").cast("int"))
        .withColumn("actie_aant_hint", col("actie_aant_hint").cast("int"))
        .withColumn("actie_aant_int", col("actie_aant_int").cast("int"))
        .withColumn("actie_aantallen", col("actie_aantallen").cast("int"))
        .withColumn("add_aant_ev", col("add_aant_ev").cast("int"))
        .withColumn("add_aant_ab", col("add_aant_ab").cast("int"))
        .withColumn("add_aant_bv", col("add_aant_bv").cast("int"))
        .withColumn("add_aant_lv", col("add_aant_lv").cast("int"))
        .withColumn("add_aant_hint", col("add_aant_hint").cast("int"))
        .withColumn("add_aant_int", col("add_aant_int").cast("int"))
        .withColumn("add_aantal", col("add_aantal").cast("int"))
        .withColumn("real_corr_act", col("real_corr_act").cast("int"))
        .withColumn("verw_aant_ev", col("verw_aant_ev").cast("int"))
        .withColumn("verw_aant_av", col("verw_aant_av").cast("int"))
        .withColumn("verw_aant_ab", col("verw_aant_ab").cast("int"))
        .withColumn("verw_aant_be", col("verw_aant_be").cast("int"))
        .withColumn("verw_aant_lu", col("verw_aant_lu").cast("int"))
        .withColumn("verw_aant_fr", col("verw_aant_fr").cast("int"))
        .withColumn("verw_aant_inl", col("verw_aant_inl").cast("int"))
        .withColumn("verw_aant_ifr", col("verw_aant_ifr").cast("int"))
        .withColumn("verw_aant_ibe", col("verw_aant_ibe").cast("int"))
        .withColumn("verw_aant_tot", col("verw_aant_tot").cast("int"))
        .withColumn("norm_omz_ev", col("norm_omz_ev").cast("decimal(17,2)"))
        .withColumn("norm_omz_ab", col("norm_omz_ab").cast("decimal(17,2)"))
        .withColumn("norm_omz_bv", col("norm_omz_bv").cast("decimal(17,2)"))
        .withColumn("norm_omz_lv", col("norm_omz_lv").cast("decimal(17,2)"))
        .withColumn("norm_omz_hint", col("norm_omz_hint").cast("decimal(17,2)"))
        .withColumn("norm_omz_int", col("norm_omz_int").cast("decimal(17,2)"))
        .withColumn("norm_omzet", col("norm_omzet").cast("decimal(17,2)"))
        .withColumn("actie_omz_ev", col("actie_omz_ev").cast("decimal(17,2)"))
        .withColumn("actie_omz_ab", col("actie_omz_ab").cast("decimal(17,2)"))
        .withColumn("actie_omz_bv", col("actie_omz_bv").cast("decimal(17,2)"))
        .withColumn("actie_omz_lv", col("actie_omz_lv").cast("decimal(17,2)"))
        .withColumn("actie_omz_hint", col("actie_omz_hint").cast("decimal(17,2)"))
        .withColumn("actie_omz_int", col("actie_omz_int").cast("decimal(17,2)"))
        .withColumn("actie_omzet", col("actie_omzet").cast("decimal(17,2)"))
        .withColumn("add_omzet_ev", col("add_omzet_ev").cast("decimal(17,2)"))
        .withColumn("add_omzet_ab", col("add_omzet_ab").cast("decimal(17,2)"))
        .withColumn("add_omzet_bv", col("add_omzet_bv").cast("decimal(17,2)"))
        .withColumn("add_omzet_lv", col("add_omzet_lv").cast("decimal(17,2)"))
        .withColumn("add_omzet_hint", col("add_omzet_hint").cast("decimal(17,2)"))
        .withColumn("add_omzet_int", col("add_omzet_int").cast("decimal(17,2)"))
        .withColumn("add_omzet", col("add_omzet").cast("decimal(17,2)"))
        .withColumn("zmap", col("zmap").cast("decimal(17,2)"))
        .withColumn("norm_marg_ev", col("norm_marg_ev").cast("decimal(17,2)"))
        .withColumn("norm_marg_ab", col("norm_omz_ab").cast("decimal(17,2)"))
        .withColumn("norm_marg_bv", col("norm_marg_bv").cast("decimal(17,2)"))
        .withColumn("norm_marg_lv", col("norm_marg_lv").cast("decimal(17,2)"))
        .withColumn("norm_marg_hint", col("norm_marg_hint").cast("decimal(17,2)"))
        .withColumn("norm_marg_int", col("norm_marg_int").cast("decimal(17,2)"))
        .withColumn("norm_marge", col("norm_marge").cast("decimal(17,2)"))
        .withColumn("prom_marg_ev", col("prom_marg_ev").cast("decimal(17,2)"))
        .withColumn("prom_marg_ab", col("prom_marg_ab").cast("decimal(17,2)"))
        .withColumn("prom_marg_bv", col("prom_marg_bv").cast("decimal(17,2)"))
        .withColumn("prom_marg_lv", col("prom_marg_lv").cast("decimal(17,2)"))
        .withColumn("prom_marg_hint", col("prom_marg_hint").cast("decimal(17,2)"))
        .withColumn("prom_marg_int", col("prom_marg_int").cast("decimal(17,2)"))
        .withColumn("promo_marge", col("promo_marge").cast("decimal(17,2)"))
        .withColumn("add_marge_ev", col("add_marge_ev").cast("decimal(17,2)"))
        .withColumn("add_marge_ab", col("add_marge_ab").cast("decimal(17,2)"))
        .withColumn("add_marge_bv", col("add_marge_bv").cast("decimal(17,2)"))
        .withColumn("add_marge_lv", col("add_marge_lv").cast("decimal(17,2)"))
        .withColumn("add_marge_hint", col("add_marge_hint").cast("decimal(17,2)"))
        .withColumn("add_marge_int", col("add_marge_int").cast("decimal(17,2)"))
        .withColumn("add_marge", col("add_marge").cast("decimal(17,2)"))
        .withColumn("veract_pv_ev", col("veract_pv_ev").cast("decimal(17,2)"))
        .withColumn("veract_pv_ab", col("veract_pv_ab").cast("decimal(17,2)"))
        .withColumn("veract_pv_bv", col("veract_pv_bv").cast("decimal(17,2)"))
        .withColumn("veract_pv_lv", col("veract_pv_lv").cast("decimal(17,2)"))
        .withColumn("veract_pv_hint", col("veract_pv_hint").cast("decimal(17,2)"))
        .withColumn("veract_pv_int", col("veract_pv_int").cast("decimal(17,2)"))
        .withColumn("verw_act_pv", col("verw_act_pv").cast("decimal(17,2)"))
        .withColumn("lift_factor", col("lift_factor").cast("decimal(12,1)"))
        .withColumn("actie_pv", col("actie_pv").cast("decimal(17,2)"))
        .withColumn("tot_fcstunitsnl", col("tot_fcstunitsnl").cast("int"))
        .withColumn("tot_fcstunitsbe", col("tot_fcstunitsbe").cast("int"))
        .withColumn("tot_fcstunitslu", col("tot_fcstunitslu").cast("int"))
        .withColumn("tot_fcstunitsin", col("tot_fcstunitsin").cast("int"))
        .withColumn("def_aant_ev", col("def_aant_ev").cast("int"))
        .withColumn("def_aant_ab", col("def_aant_ab").cast("int"))
        .withColumn("def_aant_av", col("def_aant_av").cast("int"))
        .withColumn("def_aant_be", col("def_aant_be").cast("int"))
        .withColumn("def_aant_lu", col("def_aant_lu").cast("int"))
        .withColumn("def_aant_fr", col("def_aant_fr").cast("int"))
        .withColumn("def_aant_ibe", col("def_aant_ibe").cast("int"))
        .withColumn("def_aant_ifr", col("def_aant_ifr").cast("int"))
        .withColumn("def_aant_int", col("def_aant_int").cast("int"))
        .withColumn("def_aant_tot", col("def_aant_tot").cast("int"))
        .withColumn("v_ink_d2d_nl", col("v_ink_d2d_nl").cast("int"))
        .withColumn("v_ink_d2d_be", col("v_ink_d2d_be").cast("int"))
        .withColumn("v_ink_d2d_lu", col("v_ink_d2d_lu").cast("int"))
        .withColumn("v_ink_d2d_int", col("v_ink_d2d_int").cast("int"))
        .withColumn("ing_vs_v_ev", col("ing_vs_v_ev").cast("int"))
        .withColumn("ing_vs_v_ab", col("ing_vs_v_ab").cast("int"))
        .withColumn("ing_vs_v_av", col("ing_vs_v_av").cast("int"))
        .withColumn("ing_vs_v_be", col("ing_vs_v_be").cast("int"))
        .withColumn("ing_vs_v_lu", col("ing_vs_v_lu").cast("int"))
        .withColumn("ing_vs_v_fr", col("ing_vs_v_fr").cast("int"))
        .withColumn("ing_vs_v_int", col("ing_vs_v_int").cast("int"))
        .withColumn("ing_vs_v_int_b", col("ing_vs_v_int_b").cast("int"))
        .withColumn("ing_vs_v_int_f", col("ing_vs_v_int_f").cast("int"))
        .withColumn("ing_vs_v_tot", col("ing_vs_v_tot").cast("int"))
        .withColumn("bby_korting_nl", col("bby_korting_nl").cast("decimal(17,2)"))
        .withColumn("bby_korting_be", col("bby_korting_be").cast("decimal(17,2)"))
        .withColumn("bby_korting_lu", col("bby_korting_lu").cast("decimal(17,2)"))
        .withColumn("bby_prijsset_nl", col("bby_prijsset_nl").cast("decimal(17,2)"))
        .withColumn("bby_prijsset_be", col("bby_prijsset_be").cast("decimal(17,2)"))
        .withColumn("bby_prijsset_lu", col("bby_prijsset_lu").cast("decimal(17,2)"))
        .withColumn("aant_halen", col("aant_halen").cast("int"))
        .withColumn("aant_betalen", col("aant_betalen").cast("int"))
        .withColumn("pr_eur_nl", col("pr_eur_nl").cast("decimal(17,2)"))
        .withColumn("pr_eur_be", col("pr_eur_be").cast("decimal(17,2)"))
        .withColumn("pr_eur_lu", col("pr_eur_lu").cast("decimal(17,2)"))
        .withColumn("dtppr_nl", col("dtppr_nl").cast("decimal(17,2)"))
        .withColumn("dtppr_belu", col("dtppr_belu").cast("decimal(17,2)"))
        .withColumn("dtp_datum", col("dtp_datum").cast("date"))
        .withColumn("real_prom_aant", col("real_prom_aant").cast("int"))
        .withColumn("real_lift_fact", col("real_lift_fact").cast("decimal(17,2)"))
        .withColumn("real_add_aanta", col("real_add_aanta").cast("int"))
        .withColumn("rea_omzet", col("rea_omzet").cast("decimal(17,2)"))
        .withColumn("rea_add_omzet", col("rea_add_omzet").cast("decimal(17,2)"))
        .withColumn("eff_perc", col("eff_perc").cast("int"))
        .withColumn("real_eff_perc", col("real_eff_perc").cast("int"))
        .withColumn("real_promo_mar", col("real_promo_mar").cast("decimal(17,2)"))
        .withColumn("real_add_marge", col("real_add_marge").cast("decimal(17,2)"))
        .withColumn("real_act_pv", col("real_act_pv").cast("decimal(17,2)"))
        .withColumn("btw_nl", col("btw_nl").cast("decimal(17,2)"))
        .withColumn("btw_be", col("btw_be").cast("decimal(17,2)"))
        .withColumn("btw_lu", col("btw_lu").cast("decimal(17,2)"))
        .withColumn("verkpr_old_nl", col("verkpr_old_nl").cast("decimal(17,2)"))
        .withColumn("wijzdat_vp_nl", date_format(to_date(col("wijzdat_vp_nl"),"MM-dd-yyyy"),"yyyy-MM-dd").cast("date"))
        .withColumn("verkpr_old_belu", col("verkpr_old_belu").cast("decimal(17,2)"))
        .withColumn("wijzdat_vp_belu", date_format(to_date(col("wijzdat_vp_belu"),"MM-dd-yyyy"),"yyyy-MM-dd").cast("date"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse"))


    dfsappromotions = dfsappromotions.select("promo","promo_pos","promo_text","article_number","article_description","promo_number_nl","promo_number_be","promo_number_lu",
                                             "promo_description_nl","promo_description_be","promo_description_lu","start_promotion_nl","end_promotion_nl","start_promotion_be","end_promotion_be","start_promotion_lu","end_promotion_lu",
                                             "division","category","main_group","cluster_code","reference_on","reference_rule","promotion_group_name","promotion_group_number","characteristic","generic","open_to_buy",
                                             "active_mechanism","art_type","slim_art","bonus_buy","in_out","prepack","number_in_prepack","prepack_pr","sales_pr_nl","sales_pr_belu","afw_tkpr_nl","afw_tkpr_belu","afw_ppdd_nl","afw_ppdd_belu",
                                             "kortingsperc","actpr_nl","actpr_belu","start_toonblist","eind_toonblist","zave","andere_ave","assrt_grade_nl","assrt_grade_bel","maat","kleur","status","rp_profiel","goed_stroom","art_via_d2d",
                                             "upload_in_sap","intekenen","andere_sleutel","depot","genereer_po","internet_jn","norm_aant_ev","norm_aant_ab","norm_aant_bv","norm_aant_lv","norm_aant_hint","norm_aant_int","norm_aantallen",
                                             "actie_aant_ev","actie_aant_ab","actie_aant_bv","actie_aant_lv","actie_aant_hint","actie_aant_int","actie_aantallen","add_aant_ev","add_aant_ab","add_aant_bv","add_aant_lv","add_aant_hint","add_aant_int",
                                             "add_aantal","real_corr_act","verw_aant_ev","verw_aant_av","verw_aant_ab","verw_aant_be","verw_aant_lu","verw_aant_fr","verw_aant_inl","verw_aant_ifr","verw_aant_ibe","verw_aant_tot","norm_omz_ev","norm_omz_ab",
                                             "norm_omz_bv","norm_omz_lv","norm_omz_hint","norm_omz_int","norm_omzet","actie_omz_ev","actie_omz_ab","actie_omz_bv","actie_omz_lv","actie_omz_hint","actie_omz_int","actie_omzet","add_omzet_ev",
                                             "add_omzet_ab","add_omzet_bv","add_omzet_lv","add_omzet_hint","add_omzet_int","add_omzet","zmap","norm_marg_ev","norm_marg_ab","norm_marg_bv","norm_marg_lv","norm_marg_hint","norm_marg_int","norm_marge",
                                             "prom_marg_ev","prom_marg_ab","prom_marg_bv","prom_marg_lv","prom_marg_hint","prom_marg_int","promo_marge","add_marge_ev","add_marge_ab","add_marge_bv","add_marge_lv","add_marge_hint","add_marge_int","add_marge",
                                             "veract_pv_ev","veract_pv_ab","veract_pv_bv","veract_pv_lv","veract_pv_hint","veract_pv_int","verw_act_pv","lift_factor","actie_pv","tot_fcstunitsnl","tot_fcstunitsbe","tot_fcstunitslu","tot_fcstunitsin","def_aant_ev",
                                             "def_aant_ab","def_aant_av","def_aant_be","def_aant_lu","def_aant_fr","def_aant_ibe","def_aant_ifr","def_aant_int","def_aant_tot","v_ink_d2d_nl","v_ink_d2d_be","v_ink_d2d_lu","v_ink_d2d_int","ing_vs_v_ev",
                                             "ing_vs_v_ab","ing_vs_v_av","ing_vs_v_be","ing_vs_v_lu","ing_vs_v_fr","ing_vs_v_int","ing_vs_v_int_b","ing_vs_v_int_f","ing_vs_v_tot","vdo","filter_status","bby_nl","bby_be","bby_lu","setprijs_nl","setprijs_be",
                                             "setprijs_lu","kperc_nl","kperc_be","kperc_lu","bby_special_nl","bby_special_be","bby_special_lu","freegoods_nl","freegoods_be","freegoods_lu","bby_korting_nl","bby_korting_be","bby_korting_lu","bby_prijsset_nl",
                                             "bby_prijsset_be","bby_prijsset_lu","loyalty_nl","loyalty_be","loyalty_lu","kasbontxt_nl","kasbontxt_be","kasbontxt_benl","kasbontxt_lu","artgrp","aant_halen","aant_betalen","pr_eur_nl","pr_eur_be","pr_eur_lu",
                                             "is_identiek","assorti","art_label","promotiemiddel","promotiemidd_be","brochure_week","pagtp_blauwdr","broch_num_nl","broch_num_belu","pagina_nl","pagina_belu","pag_positie_nl","pag_positie_bl","art_desc_comm",
                                             "art_info","overig_opm","kleur_comm","fotowens","sample_av","foto_exist","foto_broch","add_foto","assrt_grade_pro","dtppr_nl","dtppr_belu","dtp_datum","aanb_type_nl","aanb_type_be","aanb_type_lu","real_prom_aant",
                                             "real_lift_fact","real_add_aanta","rea_omzet","rea_add_omzet","eff_perc","real_eff_perc","real_promo_mar","real_add_marge","real_act_pv","kasbontxt_de","kasbontxt_fr","lbb_local","lbb_city","lbb_land","lbb_prio",
                                             "stock_clearance","btw_nl","btw_be","btw_lu","lock_key","bbynr_nl","bbynr_be","bbynr_lu","verkpr_old_nl","wijzdat_vp_nl","verkpr_old_belu","wijzdat_vp_belu","na","load_time","ingestion_date","ingestion_file")
    logger.info("End of TSapPromo def")
    
    return dfsappromotions
