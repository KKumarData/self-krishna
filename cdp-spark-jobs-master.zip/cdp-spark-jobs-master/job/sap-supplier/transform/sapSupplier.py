import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from utils.modules import flatten_df,logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TdfsapSupplier(**kwargs):

    logger.info("Invoked TdfsapSupplier def")

    dfsapSupplier = kwargs.get("df")
    period = kwargs.get("period")

    dfsapSupplier = flatten_df(dfsapSupplier)
    dfsapSupplier = dfsapSupplier
    dfsapSupplier = dfsapSupplier.withColumn("ingestion_filename", input_file_name())

    
    list_columns=dfsapSupplier.columns

    #For handling dynamic schema of XML File:  
    if "E1LFA1M_KUNNR" in list_columns:
        dfsapSupplier = dfsapSupplier.withColumnRenamed("E1LFA1M_KUNNR","customer_number")
    else:
        dfsapSupplier = dfsapSupplier.withColumn("customer_number",lit(""))
    if "E1LFA1M_BRSCH" in list_columns:
        dfsapSupplier = dfsapSupplier.withColumnRenamed("E1LFA1M_BRSCH","industry_key")
    else:
        dfsapSupplier = dfsapSupplier.withColumn("industry_key",lit(""))
    if "E1LFA1M_BEGRU" in list_columns:
        dfsapSupplier = dfsapSupplier.withColumnRenamed("E1LFA1M_BEGRU","authorization_group")
    else:
        dfsapSupplier = dfsapSupplier.withColumn("authorization_group",lit(""))
    if "E1LFA1M_TELF1" in list_columns:
        dfsapSupplier = dfsapSupplier.withColumnRenamed("E1LFA1M_TELF1","first_telephone_number")
    else:
        dfsapSupplier = dfsapSupplier.withColumn("first_telephone_number",lit(""))
    if "E1LFA1M_TELFX" in list_columns:
        dfsapSupplier = dfsapSupplier.withColumnRenamed("E1LFA1M_TELFX","fax_number")
    else:
        dfsapSupplier = dfsapSupplier.withColumn("fax_number",lit(""))
    if "E1LFA1M_STCEG" in list_columns:
        dfsapSupplier = dfsapSupplier.withColumnRenamed("E1LFA1M_STCEG","vat_registration_number")
    else:
        dfsapSupplier = dfsapSupplier.withColumn("vat_registration_number",lit(""))
    if "E1LFA1M_SPERR" in list_columns:
        dfsapSupplier = dfsapSupplier.withColumnRenamed("E1LFA1M_SPERR","iscompanyblocked")
    else:
        dfsapSupplier = dfsapSupplier.withColumn("iscompanyblocked",lit(""))
    if "E1LFA1M_SPERM" in list_columns:
        dfsapSupplier = dfsapSupplier.withColumnRenamed("E1LFA1M_SPERM","ispurchaseblocked")
    else:
        dfsapSupplier = dfsapSupplier.withColumn("ispurchaseblocked",lit(""))
    if "E1LFA1M_PSTLZ" in list_columns:
        dfsapSupplier = dfsapSupplier.withColumnRenamed("E1LFA1M_PSTLZ","postal_code")
    else:
        dfsapSupplier = dfsapSupplier.withColumn("postal_code",lit(""))
    if "E1LFA1M_STRAS" in list_columns:
        dfsapSupplier = dfsapSupplier.withColumnRenamed("E1LFA1M_STRAS","house_number_and_street")
    else:
        dfsapSupplier = dfsapSupplier.withColumn("house_number_and_street",lit(""))
    
    dfsapSupplier = (dfsapSupplier.select("E1LFA1M_MSGFN","E1LFA1M_LIFNR",\
                                                                "E1LFA1M_NAME1","E1LFA1M_MCOD1","E1LFA1M_MCOD3","E1LFA1M_SORTL","E1LFA1M_BBBNR",\
                                                                "E1LFA1M_BBSNR","E1LFA1M_BUBKZ","E1LFA1M_KTOKK",\
                                                                "house_number_and_street","E1LFA1M_ORT01","postal_code","E1LFA1M_LAND1","E1LFA1M_SPRAS","E1LFA1M_ADRNR",\
                                                                "E1LFA1M_GBDAT","E1LFA1M_TAXBS","E1LFA1M_REVDB","E1LFA1M_DUEFL","E1LFA1M_ERDAT","E1LFA1M_ERNAM",\
                                                                "EDI_DC40_CREDAT","EDI_DC40_CRETIM","EDI_DC40_DOCNUM","customer_number","industry_key","authorization_group",\
                                                                "first_telephone_number","fax_number","vat_registration_number","iscompanyblocked","ispurchaseblocked","ingestion_filename"))

                                                          
    #Renaming the columns:
    dfsapSupplier = (dfsapSupplier.withColumnRenamed("E1LFA1M_MSGFN", "message_function")
                                                      .withColumnRenamed("E1LFA1M_LIFNR", "supplier_id")
                                                      .withColumnRenamed("E1LFA1M_NAME1", "supplier_name")
                                                      .withColumnRenamed("E1LFA1M_MCOD1", "search_term_1")
                                                      .withColumnRenamed("E1LFA1M_MCOD3", "search_term_3")
                                                      .withColumnRenamed("E1LFA1M_SORTL", "field_for_sorting")
                                                      .withColumnRenamed("E1LFA1M_BBBNR", "global_location_numbers_1")
                                                      .withColumnRenamed("E1LFA1M_BBSNR", "global_location_numbers_2")
                                                      .withColumnRenamed("E1LFA1M_BUBKZ", "global_location_numbers_3")
                                                      .withColumnRenamed("E1LFA1M_KTOKK", "vendor_account_group")
                                                      .withColumnRenamed("E1LFA1M_ORT01", "city")
                                                      .withColumnRenamed("E1LFA1M_LAND1", "country")
                                                      .withColumnRenamed("E1LFA1M_SPRAS", "language_key")
                                                      .withColumnRenamed("E1LFA1M_ADRNR", "contact_person_address")
                                                      .withColumnRenamed("E1LFA1M_GBDAT", "contact_persion_date_of_birth")
                                                      .withColumnRenamed("E1LFA1M_TAXBS", "tax_base_in_percentage")
                                                      .withColumnRenamed("E1LFA1M_REVDB", "last_review")
                                                      .withColumnRenamed("E1LFA1M_DUEFL", "status_of_data_transfer")
                                                      .withColumnRenamed("E1LFA1M_ERDAT", "sap_creation_date")
                                                      .withColumnRenamed("E1LFA1M_ERNAM", "sap_creation_by")
                                                      .withColumnRenamed("EDI_DC40_CREDAT", "sap_export_date")
                                                      .withColumnRenamed("EDI_DC40_CRETIM", "sap_export_time")
                                                      .withColumnRenamed("EDI_DC40_DOCNUM", "idoc_number"))

                                                                                             
    dfsapSupplier = (dfsapSupplier.withColumn("global_location_numbers_1",col("global_location_numbers_1").cast('int'))
            .withColumn("global_location_numbers_2",col("global_location_numbers_2").cast('int'))
            .withColumn("global_location_numbers_3",col("global_location_numbers_3").cast("int"))
            .withColumn('contact_persion_date_of_birth', date_format(to_date(col("contact_persion_date_of_birth"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
            .withColumn("tax_base_in_percentage",col("tax_base_in_percentage").cast("decimal(20,3)"))
            .withColumn('last_review', date_format(to_date(col("last_review"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
            .withColumn('sap_creation_date', date_format(to_date(col("sap_creation_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
            .withColumn('sap_export_date', date_format(to_date(col("sap_export_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
            .withColumn("sap_export_time",col("sap_export_time").cast("bigint"))
            .withColumn("idoc_number",col("idoc_number").cast("bigint"))
            .withColumn("load_time", current_timestamp())
            .withColumn("year", year("sap_export_date"))
            .withColumn("month", month("sap_export_date"))
            .withColumn("day", dayofmonth("sap_export_date"))
            .select("supplier_id","supplier_name","search_term_1","search_term_3","field_for_sorting","global_location_numbers_1","global_location_numbers_2",
                "global_location_numbers_3","customer_number","industry_key","authorization_group","vendor_account_group","house_number_and_street","city",
                "postal_code","country","first_telephone_number","fax_number","language_key","contact_person_address",
                "contact_persion_date_of_birth","tax_base_in_percentage","vat_registration_number","last_review","status_of_data_transfer","iscompanyblocked","ispurchaseblocked","sap_creation_date","sap_creation_by",
                "sap_export_date","sap_export_time","idoc_number","load_time","year","month","day","ingestion_filename"))

    #dfsapSupplier = dfsapSupplier.dropDuplicates(['promotion_id','bby_id','article','country'])
    
    logger.info("End of sap supplier def")
     
    return dfsapSupplier
