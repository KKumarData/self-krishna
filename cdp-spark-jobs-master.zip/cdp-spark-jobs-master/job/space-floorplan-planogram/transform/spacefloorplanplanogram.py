import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TSpaceFloorPlanPlanogram(**kwargs):

    logger.info("Invoked TSpaceFloorPlanPlanogram def")

    dfspacefloorplano = kwargs.get("df")

    columns = "flr_dbkey;pog_dbkey;str_number;flr_name;flr_livedate;flr_dateend;flr_status;pog_assortment;pog_livedate;sec_x;sec_y;sec_z;sec_linear;sec_square;sec_cubic;seg_start;seg_end;flrfix_dbkey".split(";")
    
    oldColumns = dfspacefloorplano.schema.names
    dfspacefloorplano = reduce(lambda dfspacefloorplano, idx: dfspacefloorplano.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfspacefloorplano)
    
    dfspacefloorplano = dfspacefloorplano.withColumn("filename_reverse", input_file_name())
    dfspacefloorplano = dfspacefloorplano.withColumn("filename_reverse", reverse(split(reverse(dfspacefloorplano.filename_reverse), '/')[0]))

    dfspacefloorplano = (
        dfspacefloorplano.withColumn("flr_dbkey", col("flr_dbkey").cast("int"))
        .withColumn("pog_dbkey", col("pog_dbkey").cast("int"))
        .withColumn("flr_livedate", date_format(to_date(col("flr_livedate"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
        .withColumn("flr_status", col("flr_status").cast("short"))
        .withColumn("pog_livedate",  date_format(to_date(col("pog_livedate"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
        .withColumn("flr_dateend",  date_format(to_date(col("flr_dateend"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
        .withColumn("sec_x", col("sec_x").cast("decimal(8,3)"))
        .withColumn("sec_y", col("sec_y").cast("decimal(8,3)"))
        .withColumn("sec_z", col("sec_z").cast("decimal(8,3)"))
        .withColumn("sec_linear", col("sec_linear").cast("decimal(8,3)"))
        .withColumn("sec_square", col("sec_square").cast("decimal(8,3)"))
        .withColumn("sec_cubic", col("sec_cubic").cast("decimal(8,3)"))
        .withColumn("seg_start", col("seg_start").cast("short"))
        .withColumn("seg_end", col("seg_end").cast("short"))
        .withColumn("creation_date", concat(lit('20'),substring('filename_reverse',24,6)))
        .withColumn(
                            "creation_date",
                            expr(
                                "concat(substring(creation_date,1,4),'-',substring(creation_date,5,2),'-',substring(creation_date,7,2))").cast("date")
                                )
        .withColumn("load_time", current_timestamp())
        .withColumnRenamed("creation_date","ingestion_date") \
        .withColumn("year", year("ingestion_date"))
        .withColumn("month", month("ingestion_date"))
        .withColumn("day", dayofmonth("ingestion_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse"))

    wdw = Window.partitionBy('flr_dbkey','pog_dbkey','str_number','pog_assortment','flrfix_dbkey').orderBy(desc('ingestion_date'))
    dfspacefloorplano = dfspacefloorplano.withColumn('Rank',rank().over(wdw))
    dfspacefloorplano = dfspacefloorplano.filter(dfspacefloorplano.Rank == 1).drop(dfspacefloorplano.Rank)
    dfspacefloorplano = dfspacefloorplano.dropDuplicates(['flr_dbkey','pog_dbkey','str_number','flr_name','flr_livedate','flr_dateend','flr_status','pog_assortment','pog_livedate','sec_x','sec_y','sec_z','sec_linear','sec_square','sec_cubic','seg_start','seg_end','flrfix_dbkey'])
    
    dfspacefloorplano = dfspacefloorplano.select("flr_dbkey","pog_dbkey","str_number","flr_name","flr_livedate","flr_dateend","flr_status","pog_assortment","pog_livedate","sec_x","sec_y","sec_z","sec_linear","sec_square","sec_cubic","seg_start","seg_end","flrfix_dbkey","load_time","ingestion_date","ingestion_file","year","month","day").dropDuplicates()
    logger.info("End of TSpaceFloorPlanPlanogram")
    
    return dfspacefloorplano
