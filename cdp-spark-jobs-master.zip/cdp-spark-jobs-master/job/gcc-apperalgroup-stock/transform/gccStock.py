import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TgccStock(**kwargs):

    logger.info("Invoked TgccStock def")

    spark = SparkSession.builder.getOrCreate()

    dfgccStock = kwargs.get("df")

    columns = "calendar_week;store_id;product_id;stock_quantity;stock_value_including_tax;stock_value_excluding_tax;currency_code".split(";")
    
    oldColumns = dfgccStock.schema.names
    dfgccStock = reduce(lambda dfgccStock, idx: dfgccStock.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfgccStock)

    dfgccStock = dfgccStock.withColumn("filename_reverse", input_file_name())
    dfgccStock = dfgccStock.withColumn("filename_reverse", reverse(split(reverse(dfgccStock.filename_reverse), '/')[0]))

    dfgccStock = (
        dfgccStock.withColumn("calendar_week",col("calendar_week").cast("int"))
        .withColumn("store_id",col("store_id").cast("bigint"))
        .withColumn("stock_quantity", regexp_replace("stock_quantity", ',', '.').cast('decimal(18,2)'))
        .withColumn("stock_value_including_tax", regexp_replace("stock_value_including_tax", ',', '.').cast('decimal(18,2)'))
        .withColumn("stock_value_excluding_tax", regexp_replace("stock_value_excluding_tax", ',', '.').cast('decimal(18,2)'))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", substring('filename_reverse',7,8))
        .withColumn(
                            "ingestion_date",
                            expr(
                                "concat(substring(ingestion_date,1,4),'-', substring(ingestion_date,5,2),'-',substring(ingestion_date,7,2))").cast("date")
                                )
        .withColumn("year", year("ingestion_date"))
        .withColumn("month", month("ingestion_date"))
        .withColumn("day", dayofmonth("ingestion_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse")
        )
    
    dfgccStock = dfgccStock.distinct()

    logger.info("End of gcc stocks def")
    
    return dfgccStock
