import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, logger, camelToUnderscores

# Instanciate Logger
logger = logger()


def ToilOrdersDetail(**kwargs):

    logger.info("Invoked ToilSalesDetail def")

    df = kwargs.get("df")
    dfDetail = flatten_df(df)
    dfDetail = flatten_df(df)
    dfDetail = dfDetail.drop("order_custom-attributes", "order_customer", "order_shipments", "order_shipping-lineitems", "order_status", "_xmlns", "order_totals")
    dfDetail = flatten_df(dfDetail)

    for colName in dfDetail.columns:
        dfDetail = dfDetail.withColumnRenamed(colName, colName.replace('-', '_'))

    dfDetail = dfDetail.selectExpr("*",f"posexplode_outer(order_product_lineitems_product_lineitem) as (product_line_item_line_number, product_line_item)")
    
    dfDetail = flatten_df(dfDetail)

    dfDetail = flatten_df(dfDetail)

    cols_filtered = [
        c
        for c in dfDetail.schema.names
        if isinstance(dfDetail.schema[c].dataType, (ArrayType, StructType))
    ]

    dfDetail = dfDetail.drop(*cols_filtered)

    for colName in dfDetail.columns:
        dfDetail = dfDetail.withColumnRenamed(colName, colName.replace('-', '_'))
    
    
    # dfDetail = flatten_df(dfDetail)

    # for colName in dfDetail.columns:
    #     dfDetail = dfDetail.withColumnRenamed(colName, camelToUnderscores(colName))

    # cols_filtered = [
    #     c
    #     for c in dfDetail.schema.names
    #     if isinstance(dfDetail.schema[c].dataType, (ArrayType, StructType))
    # ]

    # dfDetail = dfDetail.drop(*cols_filtered)

    # salt = "@)@!-@)#!"

    # dfDetail = (
    #     dfDetail.withColumn(
    #         "customer_email",
    #         sha2(concat_ws(salt, dfDetail.customer_email), 256),
    #     )
    #     .withColumn(
    #         "invoice_id",
    #         concat_ws(
    #             "-",
    #             "order_number",
    #             "invoice_number",
    #             "document_type",
    #         ),
    #     )
    #     .withColumn(
    #         "transaction_timestamp",
    #         to_timestamp(
    #             regexp_replace("invoice_date", "T", " "),
    #             "yyyy-MM-dd HH:mm:ss",
    #         ),
    #     )
    #     .withColumn(
    #         "order_timestamp",
    #         to_timestamp(
    #             regexp_replace("order_date", "T", " "),
    #             "yyyy-MM-dd HH:mm:ss",
    #         ),
    #     )
    #     .withColumn(
    #         "order_detail_unit_price_inc_vat",
    #         col("order_detail_unit_price_inc_vat").cast("double"),
    #     )
    #     .withColumn(
    #         "order_detail_unit_price_ex_vat",
    #         col("order_detail_unit_price_ex_vat").cast("double"),
    #     )
    #     .withColumn(
    #         "order_detail_unit_price_vat",
    #         col("order_detail_unit_price_vat").cast("double"),
    #     )
    #     .withColumn(
    #         "order_detail_unit_cost_price",
    #         col("order_detail_unit_cost_price").cast("double"),
    #     )
    #     .withColumn(
    #         "order_detail_unit_shipping_costs",
    #         col("order_detail_unit_shipping_costs").cast("double"),
    #     )
    #     .withColumn(
    #         "order_detail_total_discount_ex_vat",
    #         col("order_detail_total_discount_ex_vat").cast("double"),
    #     )
    #     .withColumn(
    #         "order_detail_total_discount_inc_vat",
    #         col("order_detail_total_discount_inc_vat").cast("double"),
    #     )
    #     .withColumn(
    #         "order_detail_total_discount_vat",
    #         col("order_detail_total_discount_vat").cast("double"),
    #     )
    #     .withColumn(
    #         "order_detail_quantity",
    #         col("order_detail_quantity").cast("long"),
    #     )
    #     .withColumn(
    #         "order_detail_line_number",
    #         col("order_detail_line_number").cast("long"),
    #     )
    #     .withColumn(
    #         "order_detail_order_line_number",
    #         col("order_detail_order_line_number").cast("long"),
    #     )
    #     .withColumn(
    #         "order_detail_sku_number",
    #         col("order_detail_sku_number").cast("long"),
    #     )
    #     .withColumn("year", year("transaction_timestamp"))
    #     .withColumn("month", month("transaction_timestamp"))
    #     .withColumn("day", dayofmonth("transaction_timestamp"))
    #     .withColumn("load_time", current_timestamp())
    #     .withColumn("ingestion_date", current_date())
    #     .drop(
    #         "customer_address",
    #         "customer_first_name",
    #         "customer_house_number",
    #         "customer_house_number_alpha",
    #         "customer_last_name",
    #         "customer_phone",
    #     )
    # )

    # logger.info("End of ToilSalesDetail def")

    return dfDetail
