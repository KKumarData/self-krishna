import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, camelToUnderscores, logger

# Instanciate logger
logger = logger()


def ToilOrdersHeader(**kwargs):

    logger.info("Invoked ToilSalesHeader def")

    df = kwargs.get("df")

    dfHeader = flatten_df(df)
    dfHeader = dfHeader.drop("order_product-lineitems", "order_shipments", "order_shipping-lineitems", "order_custom-attributes", "_xmlns")
    dfHeader = flatten_df(dfHeader)
    dfHeader = flatten_df(dfHeader)
    dfHeader = flatten_df(dfHeader)
    dfHeader = flatten_df(dfHeader)
    
    rename_columns = ['order_customer_', 'order_status_', 'order_totals_total_adjusted_merchandize_', 'order_totals_total_adjusted_shipping_', 'order_totals_total_merchandize_', 'order_totals_total_order_total_', 'order_totals_total_shipping_total_']

    for colName in dfHeader.columns:
        dfHeader = dfHeader.withColumnRenamed(colName, colName.replace('-', '_'))
    
    for colName in dfHeader.columns:
        dfHeader = dfHeader.withColumnRenamed(colName, colName.replace('customer_customer_', 'customer_'))
    
    for colName in dfHeader.columns:
        dfHeader = dfHeader.withColumnRenamed(colName, colName.replace('billing_address_billing_', 'billing_'))
    
    for colName in dfHeader.columns:
        dfHeader = dfHeader.withColumnRenamed(colName, colName.replace('order_order_', 'order_'))

    for rename_column in rename_columns:
        for colName in dfHeader.columns:
            dfHeader = dfHeader.withColumnRenamed(colName, colName.replace(rename_column, ''))

    for colName in dfHeader.columns:
        dfHeader = dfHeader.withColumnRenamed(colName, camelToUnderscores(colName))

    
    cols_filtered = [
        c
        for c in dfHeader.schema.names
        if isinstance(dfHeader.schema[c].dataType, (ArrayType, StructType))
    ]

    dfHeader = dfHeader.drop(*cols_filtered)

    salt = "@)@!-@)#!"

    dfHeader = (
        dfHeader.withColumn(
            "customer_email",
            sha2(concat_ws(salt, dfHeader.customer_email), 256),
        )
        .withColumn(
            "order_id",
            concat_ws(
                "-",
                "order_no",
                "order_invoice_no",
            ),
        )
        .withColumn(
            "order_timestamp",
            to_timestamp(
                regexp_replace("order_date", "T", " "),
                "yyyy-MM-dd HH:mm:ss",
            ),
        )
        .withColumn("year", year("order_timestamp"))
        .withColumn("month", month("order_timestamp"))
        .withColumn("day", dayofmonth("order_timestamp"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .drop(
            "customer_firstname",
            "customer_lastname",
            "billing_address_address1",
            "billing_address_first_name",
            "billing_address_last_name",
            "billing_address_phone",
        )
    )

    # logger.info("End of ToilSalesHeader def")

    return dfHeader