import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, logger

# Instanciate the logger
logger = logger()


def TposSalesDiscount(**kwargs):

    logger.info("Invoked TposSalesDiscount def")

    df = kwargs.get("df")

    dfDetail = flatten_df(df)

    salesDf = dfDetail.selectExpr(
        "*",
        f"posexplode_outer(extraInfo_sales) as (sales_article_line_number, extra_Info_sales)",
    )

    salesDf1 = flatten_df(salesDf)
    
    a = array(lit(""), lit(""))

    if not "extra_Info_sales_discounts" in salesDf1.columns:
        salesDf1 = salesDf1.withColumn("extra_Info_sales_discounts", lit(a))
    

    salesDf2 = salesDf1.selectExpr(
            "*",
            f"posexplode_outer(extra_Info_sales_discounts) as (sales_article_discount_line_number, extraInfo_sales_discounts)",
        )

    salesDf3 = flatten_df(salesDf2)

    # FIX JSON SCHEMA WHEN NOT CONTAIN CUSTOMER

    if (
        not "extraInfo_sales_discounts_UsedTransactionCharacteristic1"
        in salesDf3.columns
    ):
        salesDf3 = salesDf3.withColumn(
            "extraInfo_sales_discounts_UsedTransactionCharacteristic1", lit("")
        )

    if not "customerId" in salesDf3.columns:
        salesDf3 = salesDf3.withColumn("customerId", lit("0"))

    if not "loyaltyNumber" in salesDf3.columns:
        salesDf3 = salesDf3.withColumn("loyaltyNumber", lit(""))

    # FIX NULL ISSUES
    if not "extraInfo_header_Currency" in salesDf3.columns:
        salesDf3 = salesDf3.withColumn("extraInfo_header_Currency", lit("ND"))

    # FIX NULL ISSUES
    if not "extraInfo_sales_discounts_DiscountPercentage" in salesDf3.columns:
        salesDf3 = salesDf3.withColumn(
            "extraInfo_sales_discounts_DiscountPercentage", lit("ND")
        )

    # FIX NULL ISSUES
    if not 'extraInfo_sales_discounts_DiscountType' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_DiscountType', lit(''))

    # FIX NULL ISSUES
    if not 'extraInfo_sales_discounts_DiscountStatus' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_DiscountStatus', lit(''))

    # FIX NULL ISSUES
    if not 'extraInfo_sales_discounts_DiscountOriginalReceiptPromotion' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_DiscountOriginalReceiptPromotion', lit(''))

    # FIX NULL ISSUES
    if not 'extraInfo_sales_discounts_DiscountId' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_DiscountId', lit(''))

    # FIX NULL ISSUES
    if not 'extraInfo_sales_discounts_PromotionName' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_PromotionName', lit(''))

    # FIX NULL ISSUES
    if not 'extraInfo_sales_discounts_DiscountAmount' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_DiscountAmount', lit(0.00))

    # FIX NULL ISSUES
    if not 'extraInfo_sales_discounts_DiscountConnectionType' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_DiscountConnectionType', lit(''))

    if not 'extraInfo_header_PosTypeId' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_header_PosTypeId', lit(''))

    if not 'extraInfo_sales_discounts_DiscountCreated' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_DiscountCreated', lit(''))
    
    if not 'extraInfo_sales_discounts_DiscountMutated' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_DiscountMutated', lit(''))
    
    if not 'extraInfo_sales_discounts_DiscountBookingTypeSnippet' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_DiscountBookingTypeSnippet', lit(''))
    
    if not 'extraInfo_sales_discounts_DiscountDescription' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_DiscountDescription', lit(''))
    
    if not 'extraInfo_sales_discounts_DiscountConnectionType' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_DiscountConnectionType', lit(''))
    
    if not 'extraInfo_sales_discounts_DiscountOrder' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_DiscountOrder', lit(''))
    
    if not 'extraInfo_sales_discounts_DiscountPercentage' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_DiscountPercentage', lit(''))
    
    if not 'extraInfo_sales_discounts_UsedTransactionCharacteristic1' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extraInfo_sales_discounts_UsedTransactionCharacteristic1', lit(''))
    
    if not 'extra_Info_sales_Type' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extra_Info_sales_Type', lit(''))
    
    if not 'extra_Info_sales_SubType' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extra_Info_sales_SubType', lit(''))
    
    if not 'extra_Info_sales_ArticleId' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extra_Info_sales_ArticleId', lit(0))
    
    if not 'extra_Info_sales_LineNumber' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extra_Info_sales_LineNumber', lit(''))
    
    if not 'extra_Info_sales_GroupId' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('extra_Info_sales_GroupId', lit(''))
    
    if not 'sales_article_discount_line_number' in salesDf3.columns:
        salesDf3 = salesDf3.withColumn('sales_article_discount_line_number', lit(0))
    
    if not "storeId" in salesDf3.columns:
        salesDf3 = salesDf3.withColumn("storeId", lit("0"))

    if not "invoiceNumber" in salesDf3.columns:
        salesDf3 = salesDf3.withColumn("invoiceNumber", lit(0))
    
    if not "invoiceDate" in salesDf3.columns:
        salesDf3 = salesDf3.withColumn("invoiceDate", lit(''))
    
    if not "extra_Info_sales_ArticleId" in salesDf3.columns:
        salesDf3 = salesDf3.withColumn("extra_Info_sales_ArticleId", lit(0))
        

    salesDf4 = (
        salesDf3.withColumnRenamed("storeId", "store_id")
        .withColumnRenamed("invoiceNumber", "invoice_number")
        .withColumn(
            "transaction_time",
            to_timestamp(
                regexp_replace("invoiceDate", "T", " "), "yyyy-MM-dd HH:mm:ss"
            ),
        )
        .withColumn(
            "transaction_date", to_date(substring("invoiceDate", 1, 10), "yyyy-MM-dd")
        )
        .withColumn("extra_Info_sales_ArticleId", col("extra_Info_sales_ArticleId").cast("long"))
        .withColumnRenamed("extra_Info_sales_ArticleId", "product_id")
        .withColumnRenamed("extra_Info_sales_CustomerOrderOrderNumber", "order_id")
        .withColumnRenamed("extraInfo_header_EmployeeId", "employee_id")
        .withColumnRenamed("extraInfo_header_DrawerNr", "drawer_number")
        .withColumnRenamed("extraInfo_header_Type", "header_type")
        .withColumnRenamed("extraInfo_header_SubType", "header_subtype")
        .withColumnRenamed("extraInfo_header_StartDateTime", "start_date_time")
        .withColumnRenamed("extraInfo_header_EndDateTime", "end_date_time")
        .withColumnRenamed("extraInfo_header_TransactionStatus", "transaction_status")
        .withColumnRenamed("extraInfo_header_ReceiptNr", "receipt_number")
        .withColumnRenamed("extraInfo_header_ShopId", "shop_id")
        .withColumnRenamed("extraInfo_header_PosId", "pos_id")
        .withColumnRenamed("extraInfo_header_Country", "country")
        .withColumnRenamed("extraInfo_header_PosTypeId", "pos_type_id")
        .withColumnRenamed("extraInfo_header_Currency", "currency")
        .withColumnRenamed("extra_Info_sales_LineNumber", "sales_line_number")
        .withColumnRenamed("extra_Info_sales_Status", "sales_status")
        .withColumnRenamed(
            "extra_Info_sales_RegistrationType", "sales_registrationtype"
        )
        .withColumnRenamed("extra_Info_sales_GroupId", "sales_group_id")
        .withColumnRenamed("extra_Info_sales_Amount", "price")
        .withColumnRenamed("extra_Info_sales_OriginalPrice", "original_price")
        .withColumnRenamed("extra_Info_sales_VatAmount", "vat_amount")
        .withColumnRenamed("extra_Info_sales_VatPercentage", "vat_percentage")
        .withColumnRenamed("extra_Info_sales_Count", "count")
        .withColumnRenamed("extra_Info_sales_Quantity", "quantity")
        .withColumnRenamed("extra_Info_sales_VatCodeId", "vat_code_id")
        .withColumnRenamed("extra_Info_sales_AutoRefund", "auto_refund")
        .withColumnRenamed(
            "extra_Info_sales_RefundInternetDownPayment", "refund_internet_downpayment"
        )
        .withColumnRenamed("extra_Info_sales_DiscountAllowed", "discount_allowed")
        .withColumnRenamed("extra_Info_sales_Order", "sales_order")
        .withColumnRenamed("extra_Info_sales_Type", "sales_type")
        .withColumnRenamed("extra_Info_sales_SubType", "sales_subtype")
        .withColumnRenamed("customerId", "customer_id")
        .withColumnRenamed("loyaltyNumber", "loyalty_number")
        .withColumnRenamed("extraInfo_sales_discounts_DiscountType", "discount_type")
        .withColumnRenamed(
            "extraInfo_sales_discounts_DiscountStatus", "discount_status"
        )
        .withColumnRenamed(
            "extraInfo_sales_discounts_DiscountOriginalReceiptPromotion",
            "discount_org_receipt_promo",
        )
        .withColumnRenamed("extraInfo_sales_discounts_DiscountId", "discount_id")
        .withColumnRenamed("extraInfo_sales_discounts_PromotionName", "promotion_name")
        .withColumnRenamed(
            "extraInfo_sales_discounts_DiscountAmount", "discount_amount"
        )
        .withColumnRenamed(
            "extraInfo_sales_discounts_DiscountCreated", "discount_created"
        )
        .withColumnRenamed(
            "extraInfo_sales_discounts_DiscountMutated", "discount_mutated"
        )
        .withColumnRenamed(
            "extraInfo_sales_discounts_DiscountBookingTypeSnippet",
            "discount_bookingtype_snippet",
        )
        .withColumnRenamed(
            "extraInfo_sales_discounts_DiscountDescription", "discount_description"
        )
        .withColumnRenamed(
            "extraInfo_sales_discounts_DiscountConnectionType",
            "discount_connection_type",
        )
        .withColumnRenamed("extraInfo_sales_discounts_DiscountOrder", "discount_order")
        .withColumnRenamed(
            "extraInfo_sales_discounts_DiscountPercentage", "discount_percentage"
        )
        .withColumnRenamed(
            "extraInfo_sales_discounts_UsedTransactionCharacteristic1",
            "used_transaction_char",
        )
        .withColumn(
            "load_time", from_utc_timestamp(current_timestamp(), "Europe/Amsterdam")
        )
        .withColumn("ingestion_file", input_file_name())
        .withColumn("year", year("transaction_date"))
        .withColumn("month", month("transaction_date"))
        .withColumn("day", dayofmonth("transaction_date"))
        .select(
            concat_ws(
                "-",
                "store_id",
                "invoice_number",
                unix_timestamp(
                    to_timestamp(
                        regexp_replace("transaction_time", "T", " "),
                        "yyyy-MM-dd HH:mm:ss",
                    )
                ),
            ).alias("transaction_id"),
            "invoice_number",
            "drawer_number",
            "header_type",
            "header_subtype",
            "start_date_time",
            "end_date_time",
            "transaction_status",
            "receipt_number",
            "shop_id",
            "sales_type",
            "sales_subtype",
            "pos_id",
            "pos_type_id",
            "employee_id",
            "currency",
            "product_id",
            "country",
            "store_id",
            "sales_article_line_number",
            "sales_line_number",
            "sales_group_id",
            "discount_type",
            "discount_status",
            "discount_org_receipt_promo",
            "sales_article_discount_line_number",
            "discount_id",
            "promotion_name",
            col("discount_amount").cast("double").alias("discount_amount"),
            "discount_created",
            "discount_mutated",
            "discount_bookingtype_snippet",
            "discount_description",
            "discount_connection_type",
            "discount_order",
            "discount_percentage",
            "used_transaction_char",
            "customer_id",
            "load_time",
            "ingestion_file",
            "transaction_time",
            "transaction_date",
            "year",
            "month",
            "day",
        )
        .dropDuplicates(['transaction_id', 'transaction_date', 'invoice_number', 'store_id', 'sales_article_line_number', 'product_id', 'sales_article_discount_line_number'])
    )

    logger.info("End of TposSalesDiscount def")

    return salesDf4
