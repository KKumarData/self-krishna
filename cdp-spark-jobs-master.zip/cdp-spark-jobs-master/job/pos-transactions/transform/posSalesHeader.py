import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, camelToUnderscores, logger

# Instanciate logger
logger = logger()


def TposSalesHeader(**kwargs):

    logger.info("Invoked TposSalesHeader def")

    df = kwargs.get("df")
    dfDetail = flatten_df(df)

    # FIX JSON SCHEMA WHEN NOT CONTAIN CUSTOMER
    if not "customerId" in dfDetail.columns:
        dfDetail = dfDetail.withColumn("customerId", lit("0"))

    if not "loyaltyNumber" in dfDetail.columns:
        dfDetail = dfDetail.withColumn("loyaltyNumber", lit(""))

    # #########################################################################################################
    # Header Select

    headerDf = flatten_df(df)

    headerDf = flatten_df(headerDf)

    headerDf = headerDf.withColumn("consigment", explode_outer("consignments"))

    logger.info("Change the name of columns in Data Frame")

    if not "storeId" in headerDf.columns:
        headerDf = headerDf.withColumn("storeId", lit("0"))

    if not "invoiceNumber" in headerDf.columns:
        headerDf = headerDf.withColumn("invoiceNumber", lit(0))

    if not "invoiceDate" in headerDf.columns:
        headerDf = headerDf.withColumn("invoiceDate", lit(''))

    for colName in headerDf.columns:
        headerDf = headerDf.withColumnRenamed(colName, camelToUnderscores(colName))

    logger.info("Select columns of Dataframe to Remove (Array and Structure)")

    cols_filtered = [
        c
        for c in headerDf.schema.names
        if isinstance(headerDf.schema[c].dataType, (ArrayType, StructType))
    ]

    headerDf = (
        headerDf
        .withColumn(
            "transaction_time",
            to_timestamp(
                regexp_replace("invoice_date", "T", " "), "yyyy-MM-dd HH:mm:ss"
            ),
        )
        .withColumn(
            "transaction_date", to_date(substring("invoice_date", 1, 10), "yyyy-MM-dd")
        )
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .withColumn(
            "transaction_id",
            concat_ws(
                "-",
                "store_id",
                "invoice_number",
                unix_timestamp(
                    to_timestamp(
                        regexp_replace("transaction_time", "T", " "),
                        "yyyy-MM-dd HH:mm:ss",
                    )
                ),
            ),
        )
        .withColumn("fulfillment_method", col("consigment.fulfillmentMethod"))
        .withColumn(
            "consignments_total_price_inc_vat",
            col("consigment.totalpriceincvat")
            .cast("double")
            .alias("consignments_total_price_inc_vat"),
        )
        .withColumn(
            "total_number_of_products_store",
            col("consigment.totalnumberproductsstore").cast("long"),
        )
        .withColumn(
            "total_number_of_products_webshop",
            col("consigment.totalnumberproductswebshop").cast("long"),
        )
        .withColumn(
            "total_price_incl_vat_webshop",
            col("consigment.totalpriceincvatwebshop").cast("double"),
        )
        .withColumn(
            "total_price_incl_vat_store",
            col("consigment.totalpriceincvatstore").cast("double"),
        )
        .withColumn(
            "totals_total_discount_ex_vat",
            col("totals_total_discount_ex_vat").cast("double"),
        )
        .withColumn(
            "totals_total_discount_inc_vat",
            col("totals_total_discount_inc_vat").cast("double"),
        )
        .withColumn(
            "totals_total_price_ex_vat", col("totals_total_price_ex_vat").cast("double")
        )
        .withColumn(
            "totals_total_price_inc_vat",
            col("totals_total_price_inc_vat").cast("double"),
        )
        .withColumn(
            "totals_final_price_ex_vat", col("totals_final_price_ex_vat").cast("double")
        )
        .withColumn(
            "totals_final_price_inc_vat",
            col("totals_final_price_inc_vat").cast("double"),
        )
        .withColumn("year", year("transaction_date"))
        .withColumn("month", month("transaction_date"))
        .withColumn("day", dayofmonth("transaction_date"))
        .drop(*cols_filtered)
        .dropDuplicates(['transaction_id', 'invoice_number', 'store_id', 'transaction_date'])
    )

    logger.info("End of TposSalesHeader def")

    return headerDf
