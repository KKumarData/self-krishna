import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, logger

# Instanciate the logger
logger = logger()


def TposFinancials(**kwargs):

    logger.info("Invoked TposFinancials def")

    df = kwargs.get("df")

    dfDetail = flatten_df(df.drop("totals"))

    ## BLOCK NECESSARY TO REMOVE DUPLICATE TRANSACTION IN DIFFERENT FILES
    dfFileTemp = dfDetail.select("storeId", "invoiceNumber", "invoiceDate", input_file_name().alias("ingestion_file"))

    dfFile = dfFileTemp.groupBy("storeId", "invoiceNumber", "invoiceDate") \
                        .agg(max("ingestion_file").alias("ingestionFile")) \
                        .select("storeId", "invoiceNumber", "invoiceDate", "ingestionFile")

    dfDetail = dfDetail.selectExpr(
        "*",
        f"posexplode_outer(extraInfo_financials) as (financials_line_number, extra_Info_financials)",
    )

    dfDetail = flatten_df(dfDetail.drop("extraInfo_header"))
    
    cols_filtered = [
        c
        for c in flatten_df(dfDetail).schema.names
        if isinstance(flatten_df(dfDetail).schema[c].dataType, (ArrayType, StructType))
    ]

    
    dfFinancial = (
        dfDetail
        .withColumnRenamed("storeId", "store_id")
        .withColumnRenamed("invoiceNumber", "invoice_number")
        .withColumn(
            "transaction_time",
            to_timestamp(
                regexp_replace("invoiceDate", "T", " "), "yyyy-MM-dd HH:mm:ss"
            ),
        )
        .withColumn(
            "transaction_date", to_date(substring("invoiceDate", 1, 10), "yyyy-MM-dd")
        )
        .withColumnRenamed("customerId", "customer_id")
        .withColumnRenamed("loyaltyNumber", "loyalty_number")
        .withColumnRenamed("extra_Info_financials_type","type")
        .withColumnRenamed("extra_Info_financials_SubType","sub_type")
        .withColumnRenamed("extra_Info_financials_Status","status")
        .withColumnRenamed("extra_Info_financials_TenderId","tender_id")
        .withColumnRenamed("extra_Info_financials_Code","code")
        .withColumnRenamed("extra_Info_financials_Count","count")
        .withColumnRenamed("extra_Info_financials_Currency","currency")
        .withColumnRenamed("extra_Info_financials_CurrencyAmount","currency_amount")
        .withColumn("extra_Info_financials_Amount", col("extra_Info_financials_Amount").cast("double"))
        .withColumnRenamed("extra_Info_financials_Amount","amount")
        .withColumnRenamed("extra_Info_financials_Created","created")
        .withColumnRenamed("extra_Info_financials_Mutated","mutated")
        .withColumnRenamed("extra_Info_financials_TrackAndTraceNumber","track_trace_number")
        .withColumnRenamed("extra_Info_financials_VoucherNumber","voucher_number")
        .withColumnRenamed("extra_Info_financials_ArticleSetCode","article_set_code")
        .withColumnRenamed("extra_Info_financials_ArticleSetCodeNotFound","article_set_code_not_found")
        .withColumnRenamed("extra_Info_financials_NeedsSignature","needs_signature")
        .withColumnRenamed("extra_Info_financials_RequiresMerchantSignatureOnCustomerReceipt","requires_merchant_signature_on_customer_receipt")
        .withColumnRenamed("extra_Info_financials_TenderType","tender_type")
        .withColumnRenamed("extra_Info_financials_EftManualResultQuestion","eft_manual_result_question")
        .withColumnRenamed("extra_Info_financials_ArticleSetCodeUsed","article_set_code_used")
        .withColumnRenamed("extra_Info_financials_Order","order")
        .withColumnRenamed("extra_Info_financials_TenderCurrencyCode","tender_currency_code")
        .withColumnRenamed("employeeDisount","employee_discount")
        .withColumnRenamed("employeeId","employee_id")
        .withColumnRenamed("totalNumberProducts","total_number_products")
        .withColumnRenamed("transactionBarcode","transaction_barcode")
        .withColumnRenamed("billingAddress_country","billing_address_country")
        .withColumn(
            "load_time", from_utc_timestamp(current_timestamp(), "Europe/Amsterdam")
        )
        .withColumn("ingestion_file", input_file_name())
        .withColumn("year", year("transaction_date"))
        .withColumn("month", month("transaction_date"))
        .withColumn("day", dayofmonth("transaction_date"))
        .select(
            "*",
            concat_ws(
                "-",
                "store_id",
                "invoice_number",
                unix_timestamp(
                    to_timestamp(
                        regexp_replace("transaction_time", "T", " "),
                        "yyyy-MM-dd HH:mm:ss",
                    )
                ),
            ).alias("transaction_id")
            
        )
        .drop(*cols_filtered, "invoiceDate")
        .dropDuplicates()
    )

    ##FILTER BY INGESTION_FILE
    dfFinancial = dfFinancial.join(
                        dfFile, (
                        (dfFinancial.transaction_date == dfFile.invoiceDate)
                        & (dfFinancial.store_id == dfFile.storeId)
                        & (dfFinancial.invoice_number == dfFile.invoiceNumber)
                        & (dfFinancial.ingestion_file == dfFile.ingestionFile)
                        ),
                        "inner"
                    ).drop("invoiceDate", "storeId", "invoiceNumber", "ingestionFile")

    logger.info("End of TposFinancial def")

    return dfFinancial
