import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, logger

# Instanciate Logger
logger = logger()


def TposSalesDetail(**kwargs):

    logger.info("Invoked TposSalesDetail def")

    df = kwargs.get("df")
    dfDetail = flatten_df(df)

    # FIX JSON SCHEMA WHEN NOT CONTAIN CUSTOMER
    if not "customerId" in dfDetail.columns:
        dfDetail = dfDetail.withColumn("customerId", lit("0"))

    if not "loyaltyNumber" in dfDetail.columns:
        dfDetail = dfDetail.withColumn("loyaltyNumber", lit(""))
        

    #########################################################################################################
    # CONSIGMENTS.PRODUCTS EXTRACT

    finalDf2 = dfDetail.withColumn("consigment", explode_outer("consignments"))
    finalDf2 = finalDf2.selectExpr(
        "*",
        f"posexplode_outer(consigment.products) as (products_line_number, products)",
    )

    finalDf3 = flatten_df(finalDf2)

    finalDf4 = flatten_df(finalDf3)

    cols_filtered = [
        c
        for c in flatten_df(finalDf4).schema.names
        if isinstance(flatten_df(finalDf4).schema[c].dataType, (ArrayType, StructType))
    ]

    finalDf5 = flatten_df(finalDf4).drop(*cols_filtered)


    # FIX NULL ISSUES
    if not "extraInfo_header_Currency" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("extraInfo_header_Currency", lit("ND"))

    if not "extraInfo_header_PosTypeId" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("extraInfo_header_PosTypeId", lit(""))

    if not "extra_Info_sales_Order" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("extra_Info_sales_Order", lit(""))
    
    if not "products_entryNumber" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("products_entryNumber", lit(0))
    
    if not "products_productId" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("products_productId", lit(""))
    
    if not "products_origin" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("products_origin", lit(""))
    
    if not "products_headGroupId" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("products_headGroupId", lit(""))
    
    if not "products_quantity" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("products_quantity", lit(0.00))
    
    if not "products_pricing_unitPriceIncVat" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("products_pricing_unitPriceIncVat", lit(0.00))
    
    if not "products_pricing_unitPriceExVat" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("products_pricing_unitPriceExVat", lit(0.00))
    
    if not "products_pricing_totalDiscountIncVat" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("products_pricing_totalDiscountIncVat", lit(0.00))
    
    if not "products_pricing_totalDiscountExVat" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("products_pricing_totalDiscountExVat", lit(0.00))
    
    if not "products_pricing_totalPriceIncVat" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("products_pricing_totalPriceIncVat", lit(0.00))
    
    if not "products_pricing_totalPriceExVat" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("products_pricing_totalPriceExVat", lit(0.00))
    
    if not "products_pricing_finalPriceIncVat" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("products_pricing_finalPriceIncVat", lit(0.00))
    
    if not "products_pricing_finalPriceExVat" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("products_pricing_finalPriceExVat", lit(0.00))
    
    if not "invoiceNumber" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("invoiceNumber", lit(0))
    
    if not "invoiceNumber" in finalDf5.columns:
        finalDf5 = finalDf5.withColumn("invoiceNumber", lit(0))

    
    finalDf6 = (
        finalDf5.withColumnRenamed("invoiceNumber", "invoice_number")
        .withColumnRenamed("products_entryNumber", "entry_number")
        .withColumnRenamed("extraInfo_header_DrawerNr", "drawer_number")
        .withColumnRenamed("extraInfo_header_Type", "header_type")
        .withColumnRenamed("extraInfo_header_SubType", "header_subtype")
        .withColumnRenamed("extraInfo_header_StartDateTime", "start_date_time")
        .withColumnRenamed("extraInfo_header_EndDateTime", "end_date_time")
        .withColumnRenamed("extraInfo_header_TransactionStatus", "transaction_status")
        .withColumnRenamed("extraInfo_header_ReceiptNr", "receipt_number")
        .withColumnRenamed("extraInfo_header_ShopId", "shop_id")
        .withColumnRenamed("extraInfo_header_PosId", "pos_id")
        .withColumnRenamed("extraInfo_header_PosTypeId", "pos_type_id")
        .withColumnRenamed("extraInfo_header_EmployeeId", "employee_id")
        .withColumnRenamed("extraInfo_header_Currency", "currency")
        .withColumnRenamed("products_productId", "product_id")
        .withColumnRenamed("products_origin", "origin")
        .withColumnRenamed("extraInfo_header_Country", "country")
        .withColumnRenamed("storeId", "store_id")
        .withColumnRenamed("products_headGroupId", "head_group_id")
        .withColumnRenamed("products_quantity", "pd_quantity")
        .withColumnRenamed("products_pricing_unitPriceIncVat", "pd_unit_price_incl_vat")
        .withColumnRenamed("products_pricing_unitPriceExVat", "pd_unit_price_excl_vat")
        .withColumnRenamed(
            "products_pricing_totalDiscountIncVat", "pd_total_disc_incl_vat"
        )
        .withColumnRenamed(
            "products_pricing_totalDiscountExVat", "pd_total_disc_excl_vat"
        )
        .withColumnRenamed(
            "products_pricing_totalPriceIncVat", "pd_total_price_incl_vat"
        )
        .withColumnRenamed(
            "products_pricing_totalPriceExVat", "pd_total_price_excl_vat"
        )
        .withColumnRenamed(
            "products_pricing_finalPriceIncVat", "pd_final_price_incl_vat"
        )
        .withColumnRenamed(
            "products_pricing_finalPriceExVat", "pd_final_price_excl_vat"
        )
        .withColumnRenamed("customerId", "customer_id")
        .withColumnRenamed("loyaltyNumber", "loyalty_number")
        .withColumn("transaction_time", col("invoiceDate"))
        .withColumnRenamed("invoiceDate", "transaction_date")
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .drop(
            "extraInfo_header_VATSeal",
            "_corrupt_record",
            "channel",
            "employeeDisount",
            "extraInfo_header_EmployeeId",
            "totalNumberProducts",
            "transactionBarcode",
            "totalNumberProducts",
            "consigment_consignmentId",
            "consigment_deliveryDate",
            "consigment_fulfillmentMethod",
            "consigment_totalNumberProductsStore",
            "consigment_totalNumberProductsWebshop",
            "consigment_totalPriceIncVat",
            "consigment_totalPriceIncVatStore",
            "consigment_totalPriceIncVatWebshop",
            "billingAddress_country",
            "number",
        )
        .select(
            concat_ws(
                "-",
                "store_id",
                "invoice_number",
                unix_timestamp(
                    to_timestamp(
                        regexp_replace("transaction_time", "T", " "),
                        "yyyy-MM-dd HH:mm:ss",
                    )
                ),
            ).alias("transaction_id"),
            "invoice_number",
            "entry_number",
            "drawer_number",
            "header_type",
            "header_subtype",
            "start_date_time",
            "end_date_time",
            "transaction_status",
            "receipt_number",
            "shop_id",
            "pos_id",
            "pos_type_id",
            "employee_id",
            "currency",
            "product_id",
            "origin",
            "country",
            "store_id",
            "products_line_number",
            "head_group_id",
            "pd_quantity",
            "pd_unit_price_incl_vat",
            "pd_unit_price_excl_vat",
            "pd_total_disc_incl_vat",
            "pd_total_disc_excl_vat",
            "pd_total_price_incl_vat",
            "pd_total_price_excl_vat",
            "pd_final_price_incl_vat",
            "pd_final_price_excl_vat",
            "customer_id",
            "loyalty_number",
            to_timestamp(
                regexp_replace("transaction_time", "T", " "), "yyyy-MM-dd HH:mm:ss"
            ).alias("transaction_time"),
            to_date(substring("transaction_date", 1, 10), "yyyy-MM-dd").alias(
                "transaction_date"
            ),
            "load_time",
            "ingestion_date",
            "ingestion_file",
        )
        .dropDuplicates()
    )

    #########################################################################################################
    # EXTRA_INFO.SALES EXTRACT

    # finalDf0 = dfDetail.withColumn("extraInfo_sales", explode_outer("extraInfo_sales"))
    finalDf0 = dfDetail.selectExpr(
        "*",
        f"posexplode_outer(extraInfo_sales) as (sales_article_line_number, extra_Info_sales)",
    )

    salesDf = flatten_df(finalDf0)

    cols_filtered = [
        c
        for c in flatten_df(salesDf).schema.names
        if isinstance(flatten_df(salesDf).schema[c].dataType, (ArrayType, StructType))
    ]

    # FIX NULL ISSUES
    if not "extraInfo_header_Currency" in salesDf.columns:
        salesDf = salesDf.withColumn("extraInfo_header_Currency", lit("ND"))
    
    if not "extra_Info_sales_Order" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_Order", lit(""))
    
    if not "extraInfo_header_PosTypeId" in salesDf.columns:
        salesDf = salesDf.withColumn("extraInfo_header_PosTypeId", lit(""))
    
    if not "extra_Info_sales_ArticleId" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_ArticleId", lit(0))
    
    if not "extra_Info_sales_Status" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_Status", lit(""))
    
    if not "extra_Info_sales_RegistrationType" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_RegistrationType", lit(""))
    
    if not "extra_Info_sales_GroupId" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_GroupId", lit(""))
    
    if not "extra_Info_sales_Amount" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_Amount", lit(0.00))
    
    if not "extra_Info_sales_OriginalPrice" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_OriginalPrice", lit(0.00))
    
    if not "extra_Info_sales_VatAmount" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_VatAmount", lit(0.00))
    
    if not "extra_Info_sales_VatPercentage" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_VatPercentage", lit(0.00))
    
    if not "extra_Info_sales_Count" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_Count", lit(0))

    if not "extra_Info_sales_Quantity" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_Quantity", lit(0.00))
    
    if not "extra_Info_sales_VatCodeId" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_VatCodeId", lit(""))
    
    if not "extra_Info_sales_AutoRefund" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_AutoRefund", lit(""))
    
    if not "extra_Info_sales_RefundInternetDownPayment" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_RefundInternetDownPayment", lit(""))
    
    if not "extra_Info_sales_DiscountAllowed" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_DiscountAllowed", lit(""))
    
    if not "extra_Info_sales_Order" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_Order", lit(""))
    
    if not "extra_Info_sales_SubType" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_SubType", lit(""))
    
    if not "extra_Info_sales_Type" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_Type", lit(""))

    if not "extra_Info_sales_IMEI" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_IMEI", lit(0))
    
    if not "extra_Info_sales_AuthorizeByEmployeeId" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_AuthorizeByEmployeeId", lit(0))
    
    if not "extra_Info_sales_BonusPoints" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_BonusPoints", lit(0))
    
    if not "extra_Info_sales_RefundReceiptNr" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_RefundReceiptNr", lit(0))
    
    if not "extra_Info_sales_RefundShopId" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_RefundShopId", lit("0"))
    
    if not "extra_Info_sales_RefundPosId" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_RefundPosId", lit("0"))
    
    if not "extra_Info_sales_SpecialSalesGroup" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_SpecialSalesGroup", lit("0"))
    
    if not "extra_Info_sales_MaxCount" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_MaxCount", lit("0"))
    
    if not "extra_Info_sales_CustomerOrderOrderNumber" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_CustomerOrderOrderNumber", lit(0))
    
    if not "extra_Info_sales_CopyContribution" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_CopyContribution", lit(0))
    
    if not "extra_Info_sales_Code" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_Code", lit("0"))
    
    if not "extra_Info_sales_Barcode" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_Barcode", lit("0"))
    
    if not "extra_Info_sales_Created" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_Created", lit("0"))
    
    if not "extra_Info_sales_Mutated" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_Mutated", lit("0"))
    
    if not "storeId" in salesDf.columns:
        salesDf = salesDf.withColumn("storeId", lit("0"))

    if not "invoiceNumber" in salesDf.columns:
        salesDf = salesDf.withColumn("invoiceNumber", lit(0))
    
    if not "invoiceDate" in salesDf.columns:
        salesDf = salesDf.withColumn("invoiceDate", lit(''))
    
    if not "extra_Info_sales_ArticleId" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_ArticleId", lit(0))

    if not "extra_Info_sales_SizeId" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_SizeId", lit(''))
    
    if not "extra_Info_sales_ColorId" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_ColorId", lit(''))
    
    if not "extra_Info_sales_UnitType" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_UnitType", lit(''))
    
    if not "extra_Info_sales_IsShopSpecificPrice" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_IsShopSpecificPrice", lit(''))
    
    if not "extra_Info_sales_VoucherRetourPoints" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_VoucherRetourPoints", lit(''))
    
    if not "extra_Info_sales_LoyaltyPointDefinitionDescription" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_LoyaltyPointDefinitionDescription", lit(''))
    
    if not "extra_Info_sales_SocialSecurityNumber" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_SocialSecurityNumber", lit(''))
    
    if not "extra_Info_sales_AirMilesSavingAllowed" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_AirMilesSavingAllowed", lit(''))
    
    if not "extra_Info_sales_DisposalContribution" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_DisposalContribution", lit(''))
    
    if not "extra_Info_sales_CopyContributionSupplier" in salesDf.columns:
        salesDf = salesDf.withColumn("extra_Info_sales_CopyContributionSupplier", lit(''))


    salesDf = (
        salesDf.withColumnRenamed("invoiceNumber", "invoice_number")
        .withColumnRenamed("customerId", "customer_id")
        .withColumn(
            "transaction_time",
            to_timestamp(
                regexp_replace("invoiceDate", "T", " "), "yyyy-MM-dd HH:mm:ss"
            ),
        )
        .withColumn(
            "transaction_date", to_date(substring("invoiceDate", 1, 10), "yyyy-MM-dd")
        )
        .withColumnRenamed("storeId", "store_id")
        .withColumnRenamed("extraInfo_header_DrawerNr", "drawer_number")
        .withColumnRenamed("extraInfo_header_Type", "header_type")
        .withColumnRenamed("extraInfo_header_SubType", "header_subtype")
        .withColumnRenamed("extraInfo_header_StartDateTime", "start_date_time")
        .withColumnRenamed("extraInfo_header_EndDateTime", "end_date_time")
        .withColumnRenamed("extraInfo_header_TransactionStatus", "transaction_status")
        .withColumnRenamed("extraInfo_header_ReceiptNr", "receipt_number")
        .withColumnRenamed("extraInfo_header_ShopId", "shop_id")
        .withColumnRenamed("extraInfo_header_PosId", "pos_id")
        .withColumnRenamed("extraInfo_header_PosTypeId", "pos_type_id")
        .withColumnRenamed("extraInfo_header_EmployeeId", "employee_id")
        .withColumnRenamed("extraInfo_header_Currency", "currency")
        .withColumnRenamed("extraInfo_header_Country", "country")
        .withColumn("extra_Info_sales_ArticleId", col("extra_Info_sales_ArticleId").cast("long"))
        .withColumnRenamed("extra_Info_sales_ArticleId", "product_id")
        .withColumnRenamed("extra_Info_sales_Status", "sales_status")
        .withColumnRenamed(
            "extra_Info_sales_RegistrationType", "sales_registrationtype"
        )
        .withColumnRenamed("extra_Info_sales_GroupId", "sales_group_id")
        .withColumnRenamed("extra_Info_sales_Amount", "price")
        .withColumnRenamed("extra_Info_sales_OriginalPrice", "original_price")
        .withColumnRenamed("extra_Info_sales_VatAmount", "vat_amount")
        .withColumnRenamed("extra_Info_sales_VatPercentage", "vat_percentage")
        .withColumnRenamed("extra_Info_sales_IMEI", "sales_imei")
        .withColumnRenamed("extra_Info_sales_AuthorizeByEmployeeId", "sales_authorized_by_employee_id")
        .withColumnRenamed("extra_Info_sales_Count", "sales_count")
        .withColumnRenamed("extra_Info_sales_Quantity", "quantity")
        .withColumnRenamed("extra_Info_sales_VatCodeId", "vat_code_id")
        .withColumnRenamed("extra_Info_sales_AutoRefund", "auto_refund")
        .withColumnRenamed("extra_Info_sales_RefundInternetDownPayment", "refund_internet_downpayment")
        .withColumnRenamed("extra_Info_sales_BonusPoints", "sales_bonus_points")
        .withColumnRenamed("extra_Info_sales_RefundReceiptNr", "refund_receipt_number")
        .withColumnRenamed("extra_Info_sales_RefundShopId", "refund_shop_id")
        .withColumnRenamed("extra_Info_sales_RefundPosId", "refund_pos_id")
        .withColumnRenamed("extra_Info_sales_SpecialSalesGroup", "special_sales_group")
        .withColumnRenamed("extra_Info_sales_MaxCount", "sales_max_count")
        .withColumnRenamed("extra_Info_sales_CustomerOrderOrderNumber", "customer_order_order_number")
        .withColumnRenamed("extra_Info_sales_DiscountAllowed", "discount_allowed")
        .withColumnRenamed("extra_Info_sales_CopyContribution", "sales_copy_contribution")
        .withColumnRenamed("extra_Info_sales_Order", "sales_order")
        .withColumnRenamed("extra_Info_sales_SubType", "sales_subtype")
        .withColumnRenamed("extra_Info_sales_Type", "sales_type")
        .withColumnRenamed("extra_Info_sales_Code", "sales_code")
        .withColumnRenamed("extra_Info_sales_Barcode", "sales_barcode")
        .withColumnRenamed("extra_Info_sales_Created", "sales_created")
        .withColumnRenamed("extra_Info_sales_Mutated", "sales_mutated")
        .withColumnRenamed("extra_Info_sales_SizeId", "sales_size_id")
        .withColumnRenamed("extra_Info_sales_ColorId", "sales_color_id")
        .withColumnRenamed("extra_Info_sales_UnitType", "sales_unit_type")
        .withColumnRenamed("extra_Info_sales_IsShopSpecificPrice", "sales_is_shop_specific_price")
        .withColumnRenamed("extra_Info_sales_VoucherRetourPoints", "sales_voucher_retour_points")
        .withColumnRenamed("extra_Info_sales_LoyaltyPointDefinitionDescription", "sales_loyalty_point_definition_description")
        .withColumnRenamed("extra_Info_sales_SocialSecurityNumber", "sales_social_security_number")
        .withColumnRenamed("extra_Info_sales_AirMilesSavingAllowed", "sales_air_miles_saving_allowed")
        .withColumnRenamed("extra_Info_sales_DisposalContribution", "sales_disposal_contribution")
        .withColumnRenamed("extra_Info_sales_CopyContributionSupplier", "sales_copy_contribution_supplier")
        
        .withColumnRenamed("loyaltyNumber", "loyalty_number")
        .withColumn("year", year("transaction_date"))
        .withColumn("month", month("transaction_date"))
        .withColumn("day", dayofmonth("transaction_date"))
        .withColumn(
            "load_time", from_utc_timestamp(current_timestamp(), "Europe/Amsterdam")
        )
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .drop(*cols_filtered)
        .select(
            concat_ws(
                "-",
                "store_id",
                "invoice_number",
                unix_timestamp(
                    to_timestamp(
                        regexp_replace("transaction_time", "T", " "),
                        "yyyy-MM-dd HH:mm:ss",
                    )
                ),
            ).alias("transaction_id"),
            "store_id",
            "invoice_number",
            "transaction_date",
            "product_id",
            "employee_id",
            "sales_article_line_number",
            "sales_status",
            "sales_registrationtype",
            "sales_group_id",
            "price",
            "original_price",
            "vat_amount",
            "vat_percentage",
            "sales_count",
            "quantity",
            "vat_code_id",
            "auto_refund",
            "refund_internet_downpayment",
            "discount_allowed",
            "sales_order",
            "sales_subtype",
            "sales_type",
            "customer_id",
            "drawer_number",
            "header_type",
            "header_subtype",
            "start_date_time",
            "end_date_time",
            "transaction_status",
            "receipt_number",
            "shop_id",
            "pos_id",
            "pos_type_id",
            "currency",
            "country",
            "transaction_time",
            "load_time",
            "ingestion_file",
            "loyalty_number",
            "sales_imei",
            "sales_authorized_by_employee_id",
            "sales_bonus_points",
            "refund_receipt_number",
            "refund_shop_id",
            "refund_pos_id",
            "special_sales_group",
            "sales_max_count",
            "customer_order_order_number",
            "sales_copy_contribution",
            "sales_code",
            "sales_barcode",
            "sales_created",
            "sales_mutated",
            "sales_size_id",
            "sales_color_id",
            "sales_unit_type",
            "sales_is_shop_specific_price",
            "sales_voucher_retour_points",
            "sales_loyalty_point_definition_description",
            "sales_social_security_number",
            "sales_air_miles_saving_allowed",
            "sales_disposal_contribution",
            "sales_copy_contribution_supplier",
            "year",
            "month",
            "day",
        )
        .dropDuplicates()
    )
    
    #########################################################################################################
    # JOIN BETWEEN CONSIGMENTS.PRODUCTS AND EXTRA_INFO.SALES

    consigSalesDf = (
        salesDf.join(
            finalDf6,
            (
                (salesDf.transaction_id == finalDf6.transaction_id)
                & (salesDf.sales_article_line_number == finalDf6.products_line_number)
                & (salesDf.product_id == finalDf6.product_id)  # Array position
            ),
            "left",
        )
        .select(
            salesDf.transaction_id,
            salesDf.invoice_number,
            finalDf6.entry_number,
            salesDf.drawer_number,
            salesDf.header_type,
            salesDf.header_subtype,
            salesDf.start_date_time,
            salesDf.end_date_time,
            salesDf.transaction_status,
            salesDf.receipt_number,
            salesDf.shop_id,
            salesDf.pos_id,
            salesDf.pos_type_id,
            salesDf.employee_id,
            salesDf.currency,
            salesDf.product_id,
            # finalDf6.line_number,
            finalDf6.origin,
            salesDf.country,
            salesDf.store_id,
            finalDf6.products_line_number,
            finalDf6.head_group_id,
            col("pd_quantity").cast("double").alias("pd_quantity"),
            col("pd_unit_price_incl_vat")
            .cast("double")
            .alias("pd_unit_price_incl_vat"),
            col("pd_unit_price_excl_vat")
            .cast("double")
            .alias("pd_unit_price_excl_vat"),
            col("pd_total_disc_incl_vat")
            .cast("double")
            .alias("pd_total_disc_incl_vat"),
            col("pd_total_disc_excl_vat")
            .cast("double")
            .alias("pd_total_disc_excl_vat"),
            col("pd_total_price_incl_vat")
            .cast("double")
            .alias("pd_total_price_incl_vat"),
            col("pd_total_price_excl_vat")
            .cast("double")
            .alias("pd_total_price_excl_vat"),
            col("pd_final_price_incl_vat")
            .cast("double")
            .alias("pd_final_price_incl_vat"),
            col("pd_final_price_excl_vat")
            .cast("double")
            .alias("pd_final_price_excl_vat"),
            salesDf.sales_article_line_number,
            salesDf.sales_status,
            salesDf.sales_registrationtype,
            salesDf.sales_group_id,
            salesDf.sales_subtype,
            salesDf.sales_type,
            salesDf.price.cast("double").alias("price"),
            salesDf.original_price.cast("double").alias("original_price"),
            salesDf.vat_amount.cast("double").alias("vat_amount"),
            salesDf.vat_percentage.cast("double").alias("vat_percentage"),
            salesDf.sales_count,
            salesDf.quantity.cast("double").alias("quantity"),
            salesDf.vat_code_id,
            salesDf.auto_refund,
            salesDf.refund_internet_downpayment,
            salesDf.discount_allowed,
            salesDf.sales_order,
            salesDf.customer_id,
            salesDf.loyalty_number,
            salesDf.sales_imei,
            salesDf.sales_authorized_by_employee_id,
            salesDf.sales_bonus_points,
            salesDf.refund_receipt_number,
            salesDf.refund_shop_id,
            salesDf.refund_pos_id,
            salesDf.special_sales_group,
            salesDf.sales_max_count,
            salesDf.customer_order_order_number,
            salesDf.sales_copy_contribution,
            salesDf.sales_code,
            salesDf.sales_barcode,
            salesDf.sales_created,
            salesDf.sales_mutated,
            salesDf.sales_size_id,
            salesDf.sales_color_id,
            salesDf.sales_unit_type,
            salesDf.sales_is_shop_specific_price,
            salesDf.sales_voucher_retour_points,
            salesDf.sales_loyalty_point_definition_description,
            salesDf.sales_social_security_number,
            salesDf.sales_air_miles_saving_allowed,
            salesDf.sales_disposal_contribution,
            salesDf.sales_copy_contribution_supplier,
            salesDf.load_time,
            salesDf.ingestion_file,
            salesDf.transaction_time,
            salesDf.transaction_date,
            salesDf.year,
            salesDf.month,
            salesDf.day,
        )
        .drop("invoiceNumber", "storeId", "invoiceDate", "ingestionFile")
        .dropDuplicates(['transaction_id', 'transaction_date', 'invoice_number', 'store_id', 'sales_article_line_number', 'product_id'])
    )

    logger.info("End of TposSalesDetail def")
    
    return consigSalesDf
