import os
import sys
import inspect
import sys
import datetime
import ast

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

from threading import Thread
from multiprocessing.pool import ThreadPool


from utils.modules import flatten_df, logger
from utils.sparkSession import SparkSessionFunc
from utils.extractS3 import ReadS3
from transform.posSalesHeader import TposSalesHeader
from transform.posSalesDetail import TposSalesDetail
from transform.posSalesDiscount import TposSalesDiscount
from transform.posFinancials import TposFinancials
from pyspark.sql.functions import *

# Instanciate the Log
logger = logger()

# Start App
logger.info("Init of Main ")


def main(**kwargs):

    env = kwargs.get("env")
    app_name = kwargs.get("app_name")
    raw_bucket = kwargs.get("raw_path")
    curated_bucket = kwargs.get("curated_path")
    period = kwargs.get("execution_period")
    file_format = kwargs.get("file_format")
    job_mode = kwargs.get("job_mode")
    primary_key = kwargs.get("primary_key")

    # Create Spark Session
    logger.info("Create Spark Session")

    ss = SparkSessionFunc(app_name=app_name, env=env)

    from utils.writeS3_delta import WriteDelta

    ss.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

    # Load data from S3
    logger.info("Load data from S3 %s" % (raw_bucket + period))
    
    logger.info("==============LOOP============" + raw_bucket + period)

    df = ReadS3(
        ss=ss,
        env=env,
        s3_bucket=raw_bucket + period,
        file_format=file_format,
        load_type=job_mode,
        period=period,
    )
    
    logger.info("End load process from S3")

    # Set Transformation Process using ThreadPool

    logger.info("Start Transformation process")

    pool = ThreadPool(processes=50)

    q1 = pool.apply_async(TposSalesHeader, kwds={"df": df, "job_mode": job_mode})
    salesHeaderDf = q1.get()

    q2 = pool.apply_async(TposSalesDetail, kwds={"df": df, "job_mode": job_mode})
    salesDetailDf = q2.get()
    
    q3 = pool.apply_async(TposSalesDiscount, kwds={"df": df, "job_mode": job_mode})
    salesDiscountDf = q3.get()

    position = period.find('/')
    year = period[0:4]
    month = period[period.find('/', position) : period.find('/', position+1)].replace("/","")
    day = ""
    
    if 'delta' not in job_mode:
        day = period[period.find('/', position+1) : period.find('/', position+4)].replace("/","")

    # q4 = pool.apply_async(TposFinancials, kwds={"df": df, "job_mode": job_mode})
    # financialDf = q4.get()
    
    logger.info("End Transformation process")

    #########################################################################################################

    logger.info("Start Write process")
    
    t1 = Thread(
        target=WriteDelta,
        kwargs={
            "df": salesHeaderDf,
            "bucket": curated_bucket + 'pos-transactions-header-v2',
            "ss": ss,
            "pk_column" : primary_key[0],
            "flag_transactional_data" : True,
            "year": year,
            "month": month,
            "day": day

        },
    )

    t2 = Thread(
        target=WriteDelta,
        kwargs={
            "df": salesDetailDf,
            "bucket": curated_bucket + 'pos-transactions-details-v2',
            "ss": ss,
            "pk_column" : primary_key[1],
            "flag_transactional_data" : True,
            "year": year,
            "month": month,
            "day": day
        },
    )

    t3 = Thread(
        target=WriteDelta,
        kwargs={
            "df": salesDiscountDf,
            "bucket": curated_bucket + 'pos-transactions-discount-v2',
            "ss": ss,
            "pk_column" : primary_key[2],
            "flag_transactional_data" : True,
            "year": year,
            "month": month,
            "day": day
        },
    )

    # t4 = Thread(
    #     target=WriteDelta,
    #     kwargs={
    #         "df": financialDf,
    #         "bucket": curated_bucket + 'pos-transactions-financials',
    #         "ss": ss,
    #         "pk_column" : primary_key[3]
    #     },
    # )

    t1.start()
    t2.start()
    t3.start()
    
    logger.info("End Write process")

if __name__ == "__main__":

    env = sys.argv[1]
    app_name = sys.argv[2]
    raw_path = sys.argv[3]
    curated_path = sys.argv[4]
    execution_period = sys.argv[5]
    file_format = sys.argv[6]
    job_mode = sys.argv[7]
    primary_key = ast.literal_eval(sys.argv[8])

    if "delta" not in job_mode:
        for period in ast.literal_eval(execution_period):
            main(
                    env=env,
                    app_name=app_name,
                    raw_path=raw_path,
                    curated_path=curated_path,
                    execution_period=period,
                    file_format=file_format,
                    job_mode=job_mode,
                    primary_key=primary_key,
                )
    else:
        main(
            env=env,
            app_name=app_name,
            raw_path=raw_path,
            curated_path=curated_path,
            execution_period=execution_period,
            file_format=file_format,
            job_mode=job_mode,
            primary_key=primary_key,
        )
