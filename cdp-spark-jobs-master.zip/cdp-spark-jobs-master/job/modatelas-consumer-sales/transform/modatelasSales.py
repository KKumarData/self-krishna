import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TmodatelasSales(**kwargs):

    logger.info("Invoked TmodatelasSales def")

    dfModatelas = kwargs.get("df")

    columns = "calendar_day;store_id;product_id;number_of_unit_sold;unit_of_measure;sales_value_including_tax;sales_value_excluding_tax;discount;currency_code;number_of_unit_returned;returns_value_including_tax;returns_value_excluding_tax".split(";")
    
    oldColumns = dfModatelas.schema.names
    dfModatelas = reduce(lambda dfModatelas, idx: dfModatelas.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfModatelas)

    dfModatelas = dfModatelas.withColumn("calendar_day",
                            expr(
                                "concat(substring(calendar_day,1,4),'-', substring(calendar_day,5,2),'-',substring(calendar_day,7,2))").cast("date")
                                )

    dfModatelas = (
        dfModatelas.withColumn("store_id",col("store_id").cast("bigint"))
        .withColumn("product_id",col("product_id").cast("bigint"))
        .withColumn("number_of_unit_sold", regexp_replace("number_of_unit_sold", ',', '.').cast('decimal(18,3)'))
        .withColumn("sales_value_including_tax", regexp_replace("sales_value_including_tax", ',', '.').cast('decimal(18,2)'))
        .withColumn("sales_value_excluding_tax", regexp_replace("sales_value_excluding_tax", ',', '.').cast('decimal(18,2)'))
        .withColumn("discount", regexp_replace("discount", ',', '.').cast('decimal(18,2)'))
        .withColumn("number_of_unit_returned", regexp_replace("number_of_unit_returned", ',', '.').cast('decimal(18,3)'))
        .withColumn("returns_value_including_tax", regexp_replace("returns_value_including_tax", ',', '.').cast('decimal(18,2)'))
        .withColumn("returns_value_excluding_tax", regexp_replace("returns_value_excluding_tax", ',', '.').cast('decimal(18,2)'))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("year", year("calendar_day"))
        .withColumn("month", month("calendar_day"))
        .withColumn("day", dayofmonth("calendar_day"))
        .withColumn("ingestion_file", input_file_name())
        )
    
    dfModatelas = dfModatelas.dropDuplicates(['calendar_day','store_id','product_id','unit_of_measure','sales_value_including_tax'])
    
    logger.info("End of Modatelas sales def")
    
    return dfModatelas
