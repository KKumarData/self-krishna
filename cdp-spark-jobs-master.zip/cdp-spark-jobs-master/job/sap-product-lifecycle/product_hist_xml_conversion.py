import xmltodict, json

data = open('./ARTXAL_3296!1610873117088!', 'r', encoding='iso-8859-1').read()
o = xmltodict.parse(data)

f = open('data.json', 'w')
f.write(json.dumps(o).replace('@', ''))
f.close()