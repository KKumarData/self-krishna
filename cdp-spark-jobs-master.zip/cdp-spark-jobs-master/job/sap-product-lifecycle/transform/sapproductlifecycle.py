import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType, DateType
from utils.modules import flatten_df, logger

# Instanciate Logger
logger = logger()


def TsapProductLifecycle(**kwargs):

    logger.info("Invoked ProductLifeCycle def")

    dfProductLifecycle = kwargs.get("df")
    dfProductLifecycle = flatten_df(dfProductLifecycle)
    dfProductLifecycle = dfProductLifecycle.withColumn("artikel_1", explode("ARTIKEL")).drop("ARTIKEL", "_xmlns")
    dfProductLifecycle = flatten_df(dfProductLifecycle)
    dfProductLifecycle = flatten_df(dfProductLifecycle)
    dfProductLifecycle = dfProductLifecycle.withColumn("artikel_details", explode("artikel_1_ARTIKEL_TOONBANK_ARTIKEL_TBPAR"))
    dfProductLifecycle = flatten_df(dfProductLifecycle)
    
    
    dfProductLifecycle = (
        dfProductLifecycle.withColumnRenamed("HEADER__BESTANDSNAAM", "header_filename")
        .withColumnRenamed("HEADER__EAN_ONTVANGER", "header_ean_receiver")
        .withColumnRenamed("HEADER__EAN_ZENDER", "header_ean_sender")
        .withColumnRenamed("HEADER__SYSTEEM", "header_system")
        .withColumnRenamed("HEADER__VERZENDTIJD", "header_send_time")
        .withColumnRenamed("artikel_1__ARTIKEL", "product_id")
        .withColumnRenamed("artikel_details__VKO", "sales_organisation")
        .withColumnRenamed("artikel_details__VTWEG", "distribution_channel")
        .withColumnRenamed("artikel_details__TOONBANK_BEGIN", "counter_start_date")
        .withColumnRenamed("artikel_details__TOONBANK_EIND", "counter_end_date")
        .withColumnRenamed("artikel_details__TOONBANK_BEGINWEEK", "counter_start_week")
        .withColumnRenamed("artikel_details__TOONBANK_EINDWEEK", "counter_end_week")
        .withColumn("product_id", col("product_id").cast("bigint"))
        .withColumn("header_ean_sender", col("header_ean_sender").cast("string"))
        .withColumn(
            "header_send_date",
            expr(
                "case when length(HEADER__VERZENDDATUM)=8 then concat(substring(HEADER__VERZENDDATUM,5,4),'-', substring(HEADER__VERZENDDATUM,3,2),'-',substring(HEADER__VERZENDDATUM,1,2)) ELSE concat(substring(HEADER__VERZENDDATUM,4,4),'-', substring(HEADER__VERZENDDATUM,2,2),'-','0',substring(HEADER__VERZENDDATUM,1,1)) END"
            ).cast("date"),
        )
        .withColumn("header_send_time", col("header_send_time").cast("string"))
        .withColumn("sales_organisation", col("sales_organisation").cast("string"))
        .withColumn("distribution_channel", col("distribution_channel").cast("string"))
        .withColumn(
            "counter_start_date",
            expr(
                "concat(substring(counter_start_date,1,4),'-', substring(counter_start_date,5,2),'-',substring(counter_start_date,7,2))"
            ).cast("date"),
        )
        .withColumn(
            "counter_end_date",
            expr(
                "concat(substring(counter_end_date,1,4),'-', substring(counter_end_date,5,2),'-',substring(counter_end_date,7,2))"
            ).cast("date"),
        )
        .withColumn("counter_start_week", col("counter_start_week").cast("string"))
        .withColumn("counter_end_week", col("counter_end_week").cast("string"))
        .withColumn("year", year("header_send_date"))
        .withColumn("month", month("header_send_date"))
        .withColumn("day", dayofmonth("header_send_date"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .select("header_filename","header_ean_receiver","header_ean_sender","header_system","header_send_time","product_id","sales_organisation","distribution_channel","counter_start_date","counter_end_date","counter_start_week","counter_end_week","header_send_date","load_time","ingestion_date","ingestion_file","year","month","day")
    )    
    logger.info("End of TsapProductLifecycle def")

    return dfProductLifecycle
