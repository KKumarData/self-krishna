import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TjdaShipmentsRecommended(**kwargs):

    logger.info("Invoked TjdaShipmentsRecommended def")

    dfjdaShipmentsRecommended = kwargs.get("df")
    period = kwargs.get("period")

    columns = "item|source_locations|shipment_types|destination_locations|shipment_quantity|primary_item|primary_item_quantity|order_placed_date|scheduled_arrived_date|scheduled_shipment_date|delivery_date|support_order_quantity|supply_id|allocation_set_id|exported_to_sap|need_arrived_date|need_shipment_date".split("|")
    oldColumns=dfjdaShipmentsRecommended.schema.names
    dfjdaShipmentsRecommended = reduce(lambda dfjdaShipmentsRecommended, idx: dfjdaShipmentsRecommended.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfjdaShipmentsRecommended)

    #New coloumn for Filename:
    dfjdaShipmentsRecommended= dfjdaShipmentsRecommended.withColumn("ingestion_file", input_file_name())
    #Converting the datatypes of columns:
    dfjdaShipmentsRecommended = dfjdaShipmentsRecommended.withColumn("item",col("item").cast("int"))\
                                                         .withColumn("primary_item", col("primary_item").cast("int"))\
                                                         .withColumn("scheduled_arrived_date", date_format(to_date(col("scheduled_arrived_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                         .withColumn("scheduled_shipment_date", date_format(to_date(col("scheduled_shipment_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                         .withColumn("delivery_date", date_format(to_date(col("delivery_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                         .withColumn("order_placed_date", date_format(to_date(col("order_placed_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                         .withColumn("need_arrived_date", date_format(to_date(col("need_arrived_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))\
                                                         .withColumn("need_shipment_date", date_format(to_date(col("need_shipment_date"),"MM/dd/yyyy"),"yyyy-MM-dd").cast("date"))
    #Adding the date:
    dfjdaShipmentsRecommended = dfjdaShipmentsRecommended.withColumn("period", date_format(to_date(lit(period),"yyyy/MM/dd"),"yyyy-MM-dd").cast('date'))
    #Adding year,month,date:
    dfjdaShipmentsRecommended = dfjdaShipmentsRecommended.withColumn("year", year(dfjdaShipmentsRecommended.period))\
                                                         .withColumn("month", month(dfjdaShipmentsRecommended.period))\
                                                         .withColumn("day",dayofmonth(dfjdaShipmentsRecommended.period))\
                                                         .withColumn("etl_date", col("period"))
    #Final Select:
    dfjdaShipmentsRecommended= dfjdaShipmentsRecommended.select("item","source_locations","shipment_types","destination_locations",
                                                        "shipment_quantity","primary_item","primary_item_quantity","order_placed_date",
                                                        "scheduled_arrived_date","scheduled_shipment_date","delivery_date","support_order_quantity",
                                                        "supply_id","allocation_set_id","exported_to_sap","need_arrived_date","need_shipment_date",
                                                        "etl_date","ingestion_file","year","month","day").dropDuplicates()
    
    logger.info("End of jda shipments recommended def")
    return dfjdaShipmentsRecommended
