import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TgccSales(**kwargs):

    logger.info("Invoked TgccSales def")

    dfgcc = kwargs.get("df")

    columns = "calendar_day;store_id;product_id;number_of_unit_sold;unit_of_measure;sales_value_including_tax;sales_value_excluding_tax;discount;currency_code;number_of_unit_returned;returns_value_including_tax;returns_value_excluding_tax".split(";")
    
    oldColumns = dfgcc.schema.names
    dfgcc = reduce(lambda dfgcc, idx: dfgcc.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfgcc)
    
    dfgcc = dfgcc.withColumn("calendar_day",
                            expr(
                                "concat(substring(calendar_day,1,4),'-', substring(calendar_day,5,2),'-',substring(calendar_day,7,2))").cast("date")
                                )

    dfgcc = (
        dfgcc.withColumn("store_id",col("store_id").cast("bigint"))
        .withColumn("number_of_unit_sold", regexp_replace("number_of_unit_sold", ',', '.').cast('decimal(18,3)'))
        .withColumn("sales_value_including_tax", regexp_replace("sales_value_including_tax", ',', '.').cast('decimal(18,2)'))
        .withColumn("sales_value_excluding_tax", regexp_replace("sales_value_excluding_tax", ',', '.').cast('decimal(18,2)'))
        .withColumn("discount", regexp_replace("discount", ',', '.').cast('decimal(18,2)'))
        .withColumn("number_of_unit_returned", regexp_replace("number_of_unit_returned", ',', '.').cast('decimal(18,3)'))
        .withColumn("returns_value_including_tax", regexp_replace("returns_value_including_tax", ',', '.').cast('decimal(18,2)'))
        .withColumn("returns_value_excluding_tax", regexp_replace("returns_value_excluding_tax", ',', '.').cast('decimal(18,2)'))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("year", year("calendar_day"))
        .withColumn("month", month("calendar_day"))
        .withColumn("day", dayofmonth("calendar_day"))
        .withColumn("ingestion_file", input_file_name())
        )

    logger.info("End of gcc consumer sales def")
    
    return dfgcc
