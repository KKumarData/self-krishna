import os
import logging 
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from utils.modules import logger
from functools import reduce

# Instanciate Logger
logger = logger()

def TConsumerEmailOptin(**kwargs):

    logger.info('Invoked TConsumerEmailOptin def')

    dfConsOpt = kwargs.get("df")
    columns = "hema_customer_id;sim_id;optin_type;opt_int;culture;creation_date;modification_date;creation_source;modification_source".split(";")

    oldColumns=dfConsOpt.schema.names
    dfConsOpt = reduce(lambda dfConsOpt, idx: dfConsOpt.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfConsOpt)

    dfConsOpt = dfConsOpt.withColumn("filename_reverse", input_file_name())
    dfConsOpt = dfConsOpt.withColumn("filename_reverse", reverse(split(reverse(dfConsOpt.filename_reverse), '/')[0]))

    dfConsOpt = dfConsOpt.withColumn("column_date", substring('filename_reverse',13,8)) \
                           .withColumnRenamed("column_date", "file_date") \
                           .withColumn(
                            "file_date",
                            expr(
                                "concat(substring(file_date,1,4),'-', substring(file_date,5,2),'-',substring(file_date,7,2))").cast("date")
                                ) \
                           .withColumn("load_time",current_timestamp()) \
                           .withColumnRenamed("file_date","ingestion_date") \
                           .withColumn("year", year("ingestion_date")) \
                           .withColumn("month", month("ingestion_date")) \
                           .withColumn("day", dayofmonth("ingestion_date")) \
                           .withColumn("ingestion_file", input_file_name()) \
                           .drop('filename_reverse') \
                           
    wdw = Window.partitionBy('hema_customer_id','sim_id','opt_int','optin_type','culture').orderBy(desc('ingestion_date'))
    dfConsOpt = dfConsOpt.withColumn('Rank',rank().over(wdw))
    dfConsOpt = dfConsOpt.filter(dfConsOpt.Rank == 1).drop(dfConsOpt.Rank)
    dfConsOpt = dfConsOpt.dropDuplicates(['hema_customer_id','sim_id','optin_type','opt_int','culture','creation_date','modification_date','creation_source','modification_source'])

    dfConsOpt = dfConsOpt.select("hema_customer_id","sim_id","optin_type","opt_int","culture","creation_date","modification_date","creation_source","modification_source","load_time","ingestion_date","ingestion_file","year","month","day")
                           

    logger.info('End of TConsumerEmailOptin def')

    return dfConsOpt
