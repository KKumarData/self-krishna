import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

# def inputSchema(**kwargs):

#     logger.info("creating schema")

#     dummySchema = StructType([StructField('record_code',StringType(),True),
#         StructField('article_number',StringType(),True),
#             StructField('unrestricted',StringType(),True),
#                 StructField('quality',StringType(),True),
#                     StructField('blocked',StringType(),True),
#                         StructField('sales_order',StringType(),True),
#                             StructField('reservations',StringType(),True),
#                                 StructField('col1',StringType(),True),
#                                     StructField('col2',StringType(),True)])

#     return dummySchema


def TstoreStock(**kwargs):

    logger.info("Invoked TstoreStock def")

    raw_dfstoreStock = kwargs.get("df")
    raw_Column = raw_dfstoreStock.schema.names
    raw_dfstoreStock=raw_dfstoreStock.withColumnRenamed(raw_Column[0],'raw_data')
    raw_dfstoreStock = raw_dfstoreStock.where(substring(col("raw_data"),0,2)!="00")
    raw_dfstoreStock = raw_dfstoreStock.where(substring(col("raw_data"),0,2)!="99")
    
    logger.info("Started column split process")
    split_col = fun.split(raw_dfstoreStock['raw_data'], ';')

    #columns = ['record_code','article_number','unrestricted','quality','blocked','sales_order','reservations']

    dfstoreStock =( raw_dfstoreStock.withColumn('record_code', split_col.getItem(0))
                                .withColumn('article_number', split_col.getItem(1))
                                .withColumn('unrestricted', split_col.getItem(2))
                                .withColumn('quality', split_col.getItem(3))
                                .withColumn('blocked', split_col.getItem(4))
                                .withColumn('sales_order', split_col.getItem(5))
                                .withColumn('reservations', split_col.getItem(6))
                                .drop('raw_data')

                 )
  
    dfstoreStock = dfstoreStock.withColumn("filename_reverse", input_file_name())
    dfstoreStock = dfstoreStock.withColumn("filename_reverse", reverse(split(reverse(dfstoreStock.filename_reverse), '/')[0]))

    #creation of site_id and creation_date
    dfstoreStock = (
        dfstoreStock.withColumn("col1", substring('filename_reverse',13,4))
        .withColumn("col2", substring('filename_reverse',18,14))
        .withColumnRenamed("col1", "site_id")
        .withColumnRenamed("col2", "creation_date")
        .drop('filename_reverse')
        )
        
    logger.info("Started  type casting  process")
    #type casting                      
    dfstoreStock = (
        dfstoreStock.withColumn("creation_date",to_timestamp(col("creation_date"),"yyyyMMddHHmmss").cast("timestamp"))
        .withColumn("record_code", col("record_code").cast("int"))
        .withColumn("site_id", col("site_id").cast("string"))
        .withColumn("article_number", col("article_number").cast("bigint"))
        .withColumn("unrestricted", col("unrestricted").cast("decimal(20,3)"))
        .withColumn("quality", col("quality").cast("decimal(20,3)"))
        .withColumn("blocked", col("blocked").cast("decimal(20,3)"))
        .withColumn("sales_order", col("sales_order").cast("decimal(20,3)"))
        .withColumn("reservations", col("reservations").cast("decimal(20,3)"))
        )
    
    logger.info("end of  type casting  process")
    #adding log columns
    dfstoreStock = (
        dfstoreStock.withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date",to_date(col("creation_date")))
        .withColumn("year", year("ingestion_date"))
        .withColumn("month", month("ingestion_date"))
        .withColumn("day", dayofmonth("ingestion_date"))
        .withColumn("ingestion_file", input_file_name())
  
        )
        

    
    dfstoreStock=dfstoreStock.select("record_code","article_number","unrestricted","quality","blocked","sales_order","reservations","site_id","creation_date","load_time","ingestion_date","ingestion_file","year","month","day")
    
    logger.info("End of store stock def")
    
    return dfstoreStock
