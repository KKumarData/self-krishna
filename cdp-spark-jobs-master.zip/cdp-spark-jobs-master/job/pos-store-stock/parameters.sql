DO
$do$
declare var_job_name varchar = 			'pos-store-stock';
var_landing_path varchar = 				's3://hema-cdp-prod-landing/store-stock/'; 
var_raw_path varchar = 					's3a://hema-cdp-prod-datalake-raw/store-stock/';
var_curated_path varchar = 				's3a://hema-cdp-prod-datalake-curated/pos-store-stock';
var_file_format varchar = 				'csv';
var_dcl_channel varchar = 				'store-stock'; 
var_flag_enable boolean = 				'1';
var_job_mode varchar = 					'delta'; 
var_job_env varchar = 					'cloud';
var_partition_columns varchar = 		$$"['year', 'month', 'day']"$$; 
var_start_date varchar = 				'2021-09-13';
var_execution_date_formatted varchar = 	'%Y-%m-%d'; 
var_delta_period varchar = 				$$['2021-09-13']$$;
var_job_location varchar =  			'/home/hadoop/main.py'; 
var_redshift_tables varchar = 			$$['pos_store_stock']$$; 
var_redshift_views varchar = 			$$['pos_store_stock_cm_mv']$$; 
var_job_type varchar = 					'pyspark';
var_row_tag varchar =					'';
var_rowkey varchar =					$$[['year', 'month','day','article_number','site_id']]$$;
BEGIN
   IF EXISTS (SELECT 1 FROM data_pipeline.job where job_name = var_job_name) 
   THEN
      UPDATE data_pipeline.job 
     	SET landing_path = var_landing_path,
     		raw_path = var_raw_path,
     		curated_path = var_curated_path,
     		file_format = var_file_format,
     		dcl_channel = var_dcl_channel,
     		flag_enable = var_flag_enable,
     		job_mode = var_job_mode,
     		job_env = var_job_env,
     		partition_columns = var_partition_columns,
     		start_date = var_start_date,
     		execution_date_formatted = var_execution_date_formatted,
     		delta_period = var_delta_period,
     		job_location = var_job_location,
     		redshift_tables = var_redshift_tables,
     		redshift_views = var_redshift_views,
     		job_type = var_job_type,
			row_tag = var_row_tag,
			rowkey = var_rowkey
		WHERE job_name = var_job_name
     	;
   ELSE
     insert into data_pipeline.job (job_name, landing_path, raw_path, curated_path, file_format, dcl_channel, flag_enable, job_mode, job_env, partition_columns, start_date, 
     								execution_date_formatted, job_location, delta_period, redshift_tables, redshift_views, job_type, var_row_tag, rowkey)
     select var_job_name, var_landing_path, var_raw_path, var_curated_path, var_file_format, var_dcl_channel, var_flag_enable, var_job_mode, var_job_env, var_partition_columns,
     		var_start_date, var_execution_date_formatted, var_delta_period, var_job_location, var_redshift_tables, var_redshift_views, var_job_type, var_row_tag, var_rowkey 
    ;
   END IF;
END
$do$