import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name

logger = logger()

def TInsharedCustomers(**kwargs):

    logger.info('Invoked TInsharedCustomers def')

    dfInsCust = kwargs.get("df")

    columns = "relation_id;opt_out_moment;email_address;last_name;initials;inserts;gender_code;dateofbirth;postal_code;house_number;house_number_addition;family_situation;customer_since;status_customer;cancellation_date;stack_discount_application_indication;product;number_of_products;total_month_premium_amount;damage_last_24_months;last_visit_moment_current_year;last_visiting_moment_previous_year;number_times_policy_map_current_year;number_times_policy_map_previous_year;registration_cookie_activation;cookie_activation_moment;registration_recent_cookie;cookie_recent".split(";")
    oldColumns=dfInsCust.schema.names
    dfInsCust = reduce(lambda dfInsCust, idx: dfInsCust.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfInsCust)

    dfInsCust = dfInsCust.withColumn("filename_reverse", input_file_name())
    dfInsCust = dfInsCust.withColumn("filename_reverse", reverse(split(reverse(dfInsCust.filename_reverse), '/')[0]))
    
    salt = "@)@!-@)#!"

    dfInsCust = dfInsCust.withColumn("relation_id",col("relation_id").cast("int")) \
                           .withColumn("dateofbirth",col("dateofbirth").cast("date")) \
                           .withColumn("customer_since",col("customer_since").cast("date")) \
                           .withColumn("total_month_premium_amount",col("total_month_premium_amount").cast("decimal(10,2)")) \
                           .withColumn("opt_out_moment", when(col("opt_out_moment") == "[NULL]" ,"")
                           .otherwise(col("opt_out_moment")).cast("date")) \
                           .withColumn("registration_cookie_activation", when(col("registration_cookie_activation") == "[NULL]" ,"")
                           .otherwise(col("registration_cookie_activation")).cast("date")) \
                           .withColumn("registration_recent_cookie", when(col("registration_recent_cookie") == "[NULL]" ,"")
                           .otherwise(col("registration_recent_cookie")).cast("date")) \
                           .withColumn("email_address", when(dfInsCust.email_address == "" ,"")
                                                       .when(dfInsCust.email_address.isNull() ,"" )
                                                       .otherwise(sha2(concat_ws(salt, trim(dfInsCust.email_address)), 256),)) \
                           .withColumn('last_name',sha2(concat_ws(salt, trim(dfInsCust.last_name)), 256),) \
                           .withColumn('initials',sha2(concat_ws(salt, trim(dfInsCust.initials)), 256),) \
                           .withColumn('house_number',sha2(concat_ws(salt, trim(dfInsCust.house_number)), 256),) \
                           .withColumn('house_number_addition',sha2(concat_ws(salt, trim(dfInsCust.house_number_addition)), 256),) \
                           .withColumn("column_date", substring('filename_reverse',15,8)) \
                           .withColumnRenamed("column_date", "file_date") \
                           .withColumn(
                            "file_date",
                            expr(
                                "concat(substring(file_date,1,4),'-', substring(file_date,5,2),'-',substring(file_date,7,2))").cast("date")
                                ) \
                           .withColumn("load_time",current_timestamp()) \
                           .withColumn("file_date",date_format(to_date(col("file_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date")) \
                           .withColumnRenamed("file_date","ingestion_date") \
                           .withColumn("year", year("ingestion_date")) \
                           .withColumn("month", month("ingestion_date")) \
                           .withColumn("day", dayofmonth("ingestion_date")) \
                           .withColumnRenamed("filename_reverse","ingestion_file")


    wdw = Window.partitionBy('relation_id','status_customer').orderBy(desc('ingestion_date'))
    dfInsCust = dfInsCust.withColumn('Rank',rank().over(wdw))
    dfInsCust = dfInsCust.filter(dfInsCust.Rank == 1).drop(dfInsCust.Rank)
            
    dfInsCust = dfInsCust.select("relation_id","opt_out_moment","email_address","last_name","initials","inserts","gender_code","dateofbirth","postal_code","house_number","house_number_addition","family_situation","customer_since","status_customer","cancellation_date","stack_discount_application_indication","product","number_of_products","total_month_premium_amount","damage_last_24_months","last_visit_moment_current_year","last_visiting_moment_previous_year","number_times_policy_map_current_year","number_times_policy_map_previous_year","registration_cookie_activation","cookie_activation_moment","registration_recent_cookie","cookie_recent","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info('End of TInsharedCustomers def')

    return dfInsCust
