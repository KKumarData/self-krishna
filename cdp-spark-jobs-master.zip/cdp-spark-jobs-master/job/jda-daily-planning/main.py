import os
import sys
import ast
import sys
import inspect

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

from threading import Thread
from utils.modules import logger
from utils.writeS3 import WriteS3
from utils.extractS3 import ReadS3
from multiprocessing.pool import ThreadPool
from utils.sparkSession import SparkSessionFunc
from botocore.exceptions import ClientError
from transform.transform_ingested_file import TjdaPlanningDaily

logger = logger()

logger.info("Init of Main ")

def main(**kwargs):

    env = kwargs.get("env")
    app_name = kwargs.get("app_name")
    raw_bucket = kwargs.get("raw_path")
    curated_bucket = kwargs.get("curated_path")
    period = kwargs.get("execution_period")
    ingested_file_format = kwargs.get("ingested_file_format")
    job_mode = kwargs.get("job_mode")

    if env == 'local':
        curated_bucket = currentdir+'/'+curated_bucket[:-1]


    logger.info("Create Spark Session")

    ss = SparkSessionFunc(app_name=app_name, env=env)

    logger.info("Load newly ingested data from S3")

    ingested_df = ReadS3(
        ss=ss,
        env=env,
        s3_bucket=raw_bucket + "/" + period,
        file_format=ingested_file_format,
        load_type=job_mode,
        period=period,
        header=True,
        sep=';',
        compressed=True
    )

    logger.info("End load process for newly ingested data from S3")

    logger.info("End load process for existing curated data from S3")

    logger.info("Start newly ingested DF transformation process")

    pool = ThreadPool(processes=50)

    q1 = pool.apply_async(TjdaPlanningDaily, kwds={"df": ingested_df, "exc_period": period})
    jda_planning_daily_df = q1.get()

    logger.info("End newly ingested DF transformation process")

    logger.info("Start JDA planning daily DF write process")

    t1 = Thread(
        target=WriteS3,
        kwargs={
            "df": jda_planning_daily_df,
            "bucket": curated_bucket,
            "env": env,
            "job_mode": job_mode,
            "ss": ss,
            "flag_partition": False
        },
    )

    t1.start()
    t1.join()

    logger.info("End JDA planning daily DF write write process")


if __name__ == "__main__":
    env = sys.argv[1]
    app_name = sys.argv[2]
    raw_path = sys.argv[3]
    curated_path = sys.argv[4]
    execution_period = sys.argv[5]
    ingested_file_format = sys.argv[6]
    job_mode = sys.argv[7]
   
    main(
        env=env,
        app_name=app_name,
        raw_path=raw_path,
        curated_path=curated_path,
        execution_period=execution_period,
        ingested_file_format=ingested_file_format,
        job_mode=job_mode
    )
