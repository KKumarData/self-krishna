from utils.modules import flatten_df, logger
from pyspark.sql.functions import lit, year, month, dayofmonth, when, col, least, substring, lpad

logger = logger()

def TjdaPlanningDaily(**kwargs):

    logger.info("Invoked TjdaPlanningDaily def")

    df = kwargs.get("df")
    ingestion_date = kwargs.get("exc_period")
    
    df = (
        df
         .withColumn('ETL_DATE', lit(ingestion_date).cast('date'))
         .withColumn('locationtype', when(col('LOC').isin(['000500', '000506']), 'D').otherwise('S'))
         .withColumn("STARTDATE", df['STARTDATE'].cast('date'))
         .withColumn("TotDmd", df['TotDmd'].cast('double'))
         .withColumn("TotFcst", df['TotFcst'].cast('double'))
         .withColumn("SKUExternalFcst", df['SKUExternalFcst'].cast('double'))
         .withColumn("IgnoredDmd", df['IgnoredDmd'].cast('double'))
         .withColumn("AdjAllocTotFcst", df['AdjAllocTotFcst'].cast('double'))
         .withColumn("Inventory", df['Inventory'].cast('int'))
         .withColumn("ProjOH", df['ProjOH'].cast('double')) 
         .withColumn("AltConstrPOH", df['AltConstrPOH'].cast('double'))
         .withColumn("ConstrProjOH", df['ConstrProjOH'].cast('double'))
         .withColumn("MaxOH", least(col('MaxOH').cast('double'), lit(99999)))
         .withColumn("SS", df['SS'].cast('double').alias('SafetyStock'))
         .withColumn("StatSS", df['StatSS'].cast('double'))
         .withColumn("DisplayQty", df['DisplayQty'].cast('double'))
         .withColumn("PresentationQty", df['PresentationQty'].cast('double'))
         .withColumn("PlanShip", df['PlanShip'].cast('int'))
         .withColumn("RecShip", df['RecShip'].cast('int'))
         .withColumn("RecAllocShip", df['RecAllocShip'].cast('double'))
         .withColumn("PlanArriv", df['PlanArriv'].cast('double'))
         .withColumn("RecArriv", df['RecArriv'].cast('double'))
         .withColumn("TotArriv", df['TotArriv'].cast('double'))
         .withColumn("TotIntransIn", df['TotIntransIn'].cast('double'))
         .withColumn("TotIntransOut", df['TotIntransOut'].cast('double'))
         .withColumn("ActualIntransIN", df['ActualIntransIN'].cast('double'))
         .withColumn("CommitIntransIn", df['CommitIntransIn'].cast('double'))
         .withColumn("ProjOrderOptSoq", df['ProjOrderOptSoq'].cast('double'))
         .withColumn("ProxyDemand", df['ProxyDemand'].cast('double'))
         .withColumn("ProxySupply", df['ProxySupply'].cast('double'))
         .withColumn("SupsdPlanArriv", df['SupsdPlanArriv'].cast('double'))
         .withColumn("SupsdRecArriv", df['SupsdRecArriv'].cast('double'))
         .withColumn("SupsdProjOH", df['SupsdProjOH'].cast('double'))
         .withColumn("SupsdConstrProjOH", df['SupsdConstrProjOH'].cast('double'))
    ).where((col('LOC').cast('int') < 9999) & (substring(col('ITEM'), 1, 1).cast('int').between(0, 9)))


    df = (
      df.withColumn("LOC", lpad(substring('LOC', 2, 5), 5, '0'))
      .withColumn("ITEM", df['ITEM'].cast("int"))
    )

    return df