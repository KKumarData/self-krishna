import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TjdaSspresentation(**kwargs):

    logger.info("Invoked TjdaSspresentation def")

    dfjdaSspresentation = kwargs.get("df")

    columns = "item|loc|startdate|enddate|presentation_quantity|maxoh_quantity".split("|")
    oldColumns=dfjdaSspresentation.schema.names
    dfjdaSspresentation = reduce(lambda dfjdaSspresentation, idx: dfjdaSspresentation.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfjdaSspresentation)

    #New coloumn for Filename:
    dfjdaSspresentation= dfjdaSspresentation.withColumn("ingestion_file", input_file_name())
    #Converting the datatypes of columns:
    dfjdaSspresentation = dfjdaSspresentation.withColumn("item",col("item").cast("int"))\
                                             .withColumn("startdate", date_format(to_date(col("startdate"),"yyyy-MM-dd"),"yyyy-MM-dd").cast("date"))\
                                             .withColumn("enddate", date_format(to_date(col("enddate"),"yyyy-MM-dd"),"yyyy-MM-dd").cast("date"))\
                                             .withColumn("presentation_quantity",col("presentation_quantity").cast("int"))\
                                             .withColumn("maxoh_quantity",col("maxoh_quantity").cast("int"))\
                                             .withColumn("filename_reverse", reverse(split(reverse(dfjdaSspresentation.ingestion_file), '/')[0]))
    #Creation of Etl date:
    dfjdaSspresentation = dfjdaSspresentation.withColumn("etl_date", substring('filename_reverse',20,8))\
                                             .withColumn("etl_date",date_format(to_date(col("etl_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))\
                                             .withColumn("year", year("etl_date"))\
                                             .withColumn("month", month("etl_date"))\
                                             .withColumn("day",dayofmonth("etl_date"))\
                                             .drop("filename_reverse")
    #Final Select:
    dfjdaSspresentation = dfjdaSspresentation.select("item","loc","startdate","enddate","presentation_quantity",
                                               "maxoh_quantity","etl_date","ingestion_file","year","month","day")
                                                                                              
    logger.info("End of jda sspresentation def")
    return dfjdaSspresentation
