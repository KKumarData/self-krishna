
from utils.modules import logger
from pyspark.sql.functions import col
logger = logger()

def transform_calendar_wk(**kwargs):

    logger.info("Invoked transform_calendar_wk def")

    df = kwargs.get("df")
    
    df = (
            df.withColumn('_c0', col('_c0').cast('int'))
            .withColumn('_c1', col('_c1').cast('date'))
            .withColumn('_c2', col('_c2').cast('date'))
            .withColumn('_c17', col('_c17').cast('int'))
            .withColumnRenamed('_c0', 'calweek')
            .withColumnRenamed('_c1', 'calweek_firstday')
            .withColumnRenamed('_c2', 'calweek_lastday')
            .withColumnRenamed('_c3', 'calmonth')
            .withColumnRenamed('_c4', 'calmonth2')
            .withColumnRenamed('_c5', 'calquart1')
            .withColumnRenamed('_c6', 'calquarter')
            .withColumnRenamed('_c7', 'calyear')
            .withColumnRenamed('_c8', 'fiscper')
            .withColumnRenamed('_c9', 'fiscper_stock')
            .withColumnRenamed('_c10', 'fiscper3')
            .withColumnRenamed('_c11', 'fiscper3_stock')
            .withColumnRenamed('_c12', 'fiscvarnt')
            .withColumnRenamed('_c13', 'fiscyear')
            .withColumnRenamed('_c14', 'he_fiswk')
            .withColumnRenamed('_c15', 'he_fiswk2')
            .withColumnRenamed('_c16', 'halfyear1')
            .withColumnRenamed('_c17', 'calweek_previous')

    )
    return df