import os
import sys
import ast
import sys
import boto3
import shutil
import inspect
from os import path
from pathlib import Path

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

from threading import Thread
from utils.modules import logger
from utils.writeS3 import WriteS3
from utils.extractS3 import ReadS3
from multiprocessing.pool import ThreadPool
from utils.sparkSession import SparkSessionFunc
from transform.transform import transform_calendar_wk

logger = logger()

logger.info("Init of Main ")

def main(**kwargs):

    env = kwargs.get("env")
    app_name = kwargs.get("app_name")
    raw_bucket = kwargs.get("raw_path")
    curated_bucket = kwargs.get("curated_path")
    ingested_file_format = kwargs.get("ingested_file_format")
    job_mode = kwargs.get("job_mode")

    logger.info("Create Spark Session")

    ss = SparkSessionFunc(app_name=app_name, env=env)

    from utils.writeS3_delta import WriteDelta

    if env == 'local':
        curated_bucket = currentdir+'/'+curated_bucket[:-1]


    logger.info(f"Load newly ingested data from S3 {raw_bucket}")

    ingested_df = ReadS3(
        ss=ss,
        env=env,
        s3_bucket=raw_bucket,
        file_format=ingested_file_format,
        load_type=job_mode,
        header=False,
        compressed=False,
        sep=";"
    )

    logger.info("End load process for newly ingested data from S3")

    logger.info("Start newly ingested DF transformation process")

    calendar_wk = transform_calendar_wk(df=ingested_df)

    logger.info("End newly ingested DF transformation process")

    logger.info("Start Calendar Week DF write process")

    WriteDelta(
        ss=ss,
        bucket=curated_bucket,
        df=calendar_wk,
        flag_partition=False
    )

    logger.info("End Calendar Week DF write write process")


if __name__ == "__main__":
    env = sys.argv[1]
    app_name = sys.argv[2]
    raw_path = sys.argv[3]
    curated_path = sys.argv[4]
    ingested_file_format = sys.argv[5]
    job_mode = sys.argv[6]

    main(
        env=env,
        app_name=app_name,
        raw_path=raw_path,
        curated_path=curated_path,
        ingested_file_format=ingested_file_format,
        job_mode=job_mode
    )
