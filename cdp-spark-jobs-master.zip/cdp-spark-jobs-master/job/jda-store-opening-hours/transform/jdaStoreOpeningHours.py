import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TjdaStoreOpeningHours(**kwargs):

    logger.info("Invoked TjdaStoreOpeningHours def")

    jdaStoreOpeningHours = kwargs.get("df")
    columns = "loc|date_stamp|is_open|period_counter|opening_time|closing_time|descr".split("|")
    oldColumns=jdaStoreOpeningHours.schema.names
    jdaStoreOpeningHours = reduce(lambda jdaStoreOpeningHours, idx: jdaStoreOpeningHours.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), jdaStoreOpeningHours)
    
    #Getting the file path:
    jdaStoreOpeningHours = jdaStoreOpeningHours.withColumn("input_file_name", input_file_name())
    #Getting current dates:
    jdaStoreOpeningHours = jdaStoreOpeningHours.withColumn("current_date_derived", reverse(split(reverse(jdaStoreOpeningHours.input_file_name), '/')[0]))                                      
    #Casting Columns:
    jdaStoreOpeningHours = jdaStoreOpeningHours.withColumn("date_stamp", col("date_stamp").cast("date"))\
                                               .withColumn("current_date", reverse(split(reverse(jdaStoreOpeningHours.current_date_derived), '-')[1]))\
                                               .withColumn("ingestion_date", date_format(to_date(col("current_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))\
                                               .withColumn("load_time", current_timestamp())\
                                               .withColumn("year", year("ingestion_date"))\
                                               .withColumn("month", month("ingestion_date"))\
                                               .withColumn("day", dayofmonth("ingestion_date"))

    #Select :
    jdaStoreOpeningHours = jdaStoreOpeningHours.select("loc","date_stamp","is_open","period_counter","opening_time","closing_time","descr", 
                                                        "ingestion_date","load_time","input_file_name")

    logger.info("End of jda store opening hours def")
    return jdaStoreOpeningHours