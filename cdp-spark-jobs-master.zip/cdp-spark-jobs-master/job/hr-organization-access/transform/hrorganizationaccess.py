import os
import logging 
import sys
from pyspark.sql.functions import *
from utils.modules import logger
from functools import reduce
from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql.functions import input_file_name

logger = logger()

def THROrganizationAccess(**kwargs):

    logger.info('Invoked THROrganizationAccess def')

    dfOrgAcc = kwargs.get("df")

    columns = "mstr_login;name;cost_center;custom_1;custom_2".split(";")
    oldColumns=dfOrgAcc.schema.names
    dfOrgAcc = reduce(lambda dfOrgAcc, idx: dfOrgAcc.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfOrgAcc)
    
    dfOrgAcc.show()
    dfOrgAcc = dfOrgAcc.withColumn("filename_reverse", input_file_name())
    dfOrgAcc = dfOrgAcc.withColumn("filename_reverse", reverse(split(reverse(dfOrgAcc.filename_reverse), '/')[0]))
    
    dfOrgAcc = dfOrgAcc.withColumn("load_time",current_timestamp()) \
                           .withColumnRenamed("filename_reverse","ingestion_file") \
                           .withColumn("ingestion_date",current_date())
    dfOrgAcc = dfOrgAcc.select("mstr_login","name","cost_center","custom_1","custom_2","load_time","ingestion_date","ingestion_file")
    logger.info('End of THROrganizationAccess def')

    return dfOrgAcc
