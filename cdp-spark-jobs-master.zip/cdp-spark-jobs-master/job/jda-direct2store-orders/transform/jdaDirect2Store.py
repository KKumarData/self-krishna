import os
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType
from utils.modules import logger
from functools import reduce
from pyspark.sql.functions import input_file_name

# Instanciate Logger
logger = logger()


def TjdaDirect2Store(**kwargs):

    logger.info("Invoked TcurtainStock def")

    dfjdaDirect2Store = kwargs.get("df")

    oldColumns = dfjdaDirect2Store.schema.names
    dfjdaDirect2Store = reduce(
        lambda dfjdaDirect2Store, idx: dfjdaDirect2Store.withColumnRenamed(
            oldColumns[idx], "jdadirect2storedata"),
        range(len(oldColumns)),
        dfjdaDirect2Store)

    header_df = dfjdaDirect2Store.filter(col("jdadirect2storedata").startswith("00"))
    header_df = (
        header_df.withColumn("generation_date", substring('jdadirect2storedata',3,8))
        .withColumn("generation_time", substring('jdadirect2storedata',11,6))
        .withColumn("generation_date", date_format(to_date(col("generation_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("jdadirect2storedata"))

    #Removing header and footer from file
    logger.info("Removing header and footer from file")

    dfjdaDirect2Store = dfjdaDirect2Store.withColumn('rec_id', substring('jdadirect2storedata',0,2))
    #Deletion of Header and trailor:
    dfjdaDirect2Store = dfjdaDirect2Store.filter(~dfjdaDirect2Store.rec_id.isin(["00","02"])) 
    
    logger.info("Detailed data creation starts here")

    dfjdaDirect2Store = dfjdaDirect2Store.withColumn('order_date', substring('jdadirect2storedata',3,8))\
                                 .withColumn('store_id', substring('jdadirect2storedata',11,4))\
                                 .withColumn('product_id', substring('jdadirect2storedata',15,18).cast("bigint"))\
                                 .withColumn('order_quantity', substring('jdadirect2storedata',33,13))\
                                 .withColumn('order_quantity', regexp_replace('order_quantity', r'^[0]*', ''))\
                                 .withColumn("order_quantity",expr("substring(order_quantity, 1, length(order_quantity)-3)").cast('int'))\
                                 .withColumn('delivery_date', substring('jdadirect2storedata',46,8))\
                                 .withColumn('constraint_indicator', substring('jdadirect2storedata',54,1))\
                                 .withColumn('vendornumber', substring('jdadirect2storedata',65,10))\
                                 .withColumn("ingestion_file", input_file_name())\
                                 .drop("jdadirect2storedata")

    dfjdaDirect2Store = dfjdaDirect2Store.withColumn('order_date', date_format(to_date(col("order_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))\
                                 .withColumn('delivery_date', date_format(to_date(col("delivery_date"),"yyyyMMdd"),"yyyy-MM-dd").cast("date"))

    logger.info("Joining header_df with detailed data")
    dfjdaDirect2Store = dfjdaDirect2Store.join(header_df, on='ingestion_file')

    dfjdaDirect2Store = (
        dfjdaDirect2Store.withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("year", year("generation_date"))
        .withColumn("month", month("generation_date"))
        .withColumn("day", dayofmonth("generation_date"))
        )
        
    dfjdaDirect2Store = dfjdaDirect2Store.select("rec_id","order_date","store_id","product_id", "order_quantity",\
         "delivery_date", "constraint_indicator", "generation_date", "generation_time", "vendornumber",\
         "load_time","ingestion_date",\
           "year", "month", "day", "ingestion_file"\
           )

    logger.info("Detailed data creation ends here")

    logger.info("End of dfjdadirect2store def")

    return dfjdaDirect2Store
