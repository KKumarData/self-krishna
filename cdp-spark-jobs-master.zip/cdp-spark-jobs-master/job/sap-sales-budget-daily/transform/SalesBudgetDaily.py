import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import logger
from functools import reduce

# Instanciate Logger
logger = logger()


def SalesBudDaily(**kwargs):

    logger.info("Invoked SalesBudDaily def")

    dfBudgetDaily = kwargs.get("df")
    columns = "HERVSTYPE;0COUNTRY;0CALDAY;HERCAT;0COMP_CODE;0SALESORG;ZCURTYPE;0VERSION;0VTYPE;0CURRENCY;0RTBAINSAST".split(";")

    oldColumns = dfBudgetDaily.schema.names
    dfBudgetDaily = reduce(
        lambda dfBudgetDaily, idx: dfBudgetDaily.withColumnRenamed(
            oldColumns[idx], columns[idx]
        ),
        range(len(oldColumns)),
        dfBudgetDaily,
    )

    dfBudgetDaily = (
        dfBudgetDaily.withColumnRenamed("HERVSTYPE","store_type") \
        .withColumnRenamed("0COUNTRY","country") \
        .withColumnRenamed("0CALDAY","calendar_day") \
        .withColumnRenamed("HERCAT","category_id") \
        .withColumnRenamed("0COMP_CODE","company_code") \
        .withColumnRenamed("0SALESORG","sales_organization") \
        .withColumnRenamed("ZCURTYPE","currency_type") \
        .withColumnRenamed("0VERSION","version") \
        .withColumnRenamed("0VTYPE","value_type") \
        .withColumnRenamed("0CURRENCY","currency") \
        .withColumnRenamed("0RTBAINSAST","gross_sales") \
        .withColumn("calendar_day", expr("concat(substring(calendar_day,1,4),'-', substring(calendar_day,5,2),'-',substring(calendar_day,7,2))").cast("date")) \
        .withColumn("gross_sales", expr("case when right(gross_sales,1) = '-' then -1 * cast(replace(gross_sales, '-', '') as double) else gross_sales end")) \
        .withColumn("gross_sales", col("gross_sales").cast("double")) \
        .withColumn("calendar_day", col("calendar_day").cast("date")) \
        .withColumn("load_time", current_timestamp()) \
        .withColumn("ingestion_file", input_file_name()) \
        .withColumn("ingestion_date", current_date()) \
        .withColumn("year", year("calendar_day")) \
        .withColumn("month", month("calendar_day")) \
        .withColumn("day", dayofmonth("calendar_day")) \
    ).dropDuplicates(['calendar_day', 'country', 'category_id', 'company_code', 'sales_organization', 'currency'])

    logger.info("End of SalesBudDaily def")

    return dfBudgetDaily
