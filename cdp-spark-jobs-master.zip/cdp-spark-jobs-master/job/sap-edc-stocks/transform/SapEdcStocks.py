import os
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType
from utils.modules import logger
from functools import reduce

# Instanciate Logger
logger = logger()


def TsapEdcStocks(**kwargs):

    logger.info("Invoked sapEdcStocks def")

    dfEdcStocks = kwargs.get("df")
    columns = ["edcdata","ingestion_file"]
    oldColumns = dfEdcStocks.schema.names
    dfEdcStocks = reduce(lambda dfEdcStocks, idx: dfEdcStocks.withColumnRenamed(oldColumns[idx], columns[idx])\
            ,range(len(oldColumns)), dfEdcStocks)

    replace_udf = Fun.udf(lambda x: x.replace('*', ''))

    dfEdcStocks = dfEdcStocks.withColumn('edcdata', replace_udf('edcdata'))

    header_df = dfEdcStocks.filter(col("edcdata").startswith("00WEBVRD"))

    header_df = header_df.withColumn("creation_date_str",substring('edcdata',9,14))

    header_df = header_df.withColumn(
                            "creation_date",to_timestamp(col("creation_date_str"),"yyyyMMddHHmmss").cast("timestamp")

                                    ) \
                                .drop("edcdata")

    header_df.show(10,False)

    #Removing header and footer from file
    logger.info("Removing header and footer from file")
    dfEdcStocks = dfEdcStocks[~dfEdcStocks.edcdata.contains("00WEBVRD")]
    dfEdcStocks = dfEdcStocks[~dfEdcStocks.edcdata.contains("99WEBVRD")] 
    
    logger.info("Detailed data creation starts here")
    dfEdcStocks = (
        dfEdcStocks.withColumn("recordtype", substring('edcdata',0,2).cast("int"))
        .withColumn("sku",substring('edcdata',3,8).cast("bigint"))
        .withColumn("edc_stock",substring('edcdata',11,8))
        .drop("edcdata"))

    logger.info("Joining header_df with detailed data")
    dfEdcStocks = dfEdcStocks.join(header_df,on='ingestion_file')

    dfEdcStocks = (dfEdcStocks.withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", to_date(col("creation_date")))
        .withColumn("year", year("ingestion_date"))
        .withColumn("month", month("ingestion_date"))
        .withColumn("day", dayofmonth("ingestion_date"))
     )
     
    wdw = Window.partitionBy('ingestion_date','sku').orderBy(desc('creation_date'))
    dfEdcStocks = dfEdcStocks.withColumn('Rank',rank().over(wdw))
    dfEdcStocks = dfEdcStocks.filter(dfEdcStocks.Rank == 1).drop(dfEdcStocks.Rank)
    dfEdcStocks=dfEdcStocks.select("recordtype","sku","edc_stock","creation_date","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info("End of EdcStocks def")

    return dfEdcStocks
