import os
import sys
import logging
import sys
import re
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse, instr, substring, udf
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name

logger = logger()

def TSAPWorkforceReports(**kwargs):

    logger.info('Invoked TSAPWorkforceReports def')

    dfSapWorkReports = kwargs.get("df")

    columns = "store_id;calendar_week;u_gross_hours;u_budget_gross_hours;u_net_hours;u_budget_net_hours;u_sick_hours;u_budget_sick_hours;u_special_leave_hours;u_budget_special_leave_hours;u_additional_hours;u_budget_additional_hours;u_salary_costs;u_budget_salary_costs;unit_of_quantity;currency;custom".split(";")
    oldColumns=dfSapWorkReports.schema.names
    dfSapWorkReports = reduce(lambda dfSapWorkReports, idx: dfSapWorkReports.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfSapWorkReports)
    
    dfSapWorkReports = dfSapWorkReports.withColumn("filename_reverse", input_file_name())
    
    dfSapWorkReports = (dfSapWorkReports.withColumn("fileday",reverse(split(reverse(dfSapWorkReports.filename_reverse), '/')[1]))
                                .withColumn("filemonth",reverse(split(reverse(dfSapWorkReports.filename_reverse), '/')[2]))
                                .withColumn("fileyear",reverse(split(reverse(dfSapWorkReports.filename_reverse), '/')[3]))
                                .withColumn('creation_date', concat(col('fileyear'),lit('-'), col('filemonth'),lit('-'), col('fileday')).cast("date")))

    dfSapWorkReports = dfSapWorkReports.withColumn("gross_hours_removed", regexp_replace('u_gross_hours', '-', '')) \
                           .withColumn("budget_gross_hours_removed", regexp_replace('u_budget_gross_hours', '-', '')) \
                           .withColumn("net_hours_removed", regexp_replace('u_net_hours', '-', '')) \
                           .withColumn("budget_net_hours_removed", regexp_replace('u_budget_net_hours', '-', '')) \
                           .withColumn("sick_hours_removed", regexp_replace('u_sick_hours', '-', '')) \
                           .withColumn("budget_sick_hours_removed", regexp_replace('u_budget_sick_hours', '-', '')) \
                           .withColumn("special_leave_hours_removed", regexp_replace('u_special_leave_hours', '-', '')) \
                           .withColumn("budget_special_leave_hours_removed", regexp_replace('u_budget_special_leave_hours', '-', '')) \
                           .withColumn("additional_hours_removed", regexp_replace('u_additional_hours', '-', '')) \
                           .withColumn("budget_additional_hours_removed", regexp_replace('u_budget_additional_hours', '-', '')) \
                           .withColumn("salary_costs_removed", regexp_replace('u_salary_costs', '-', '')) \
                           .withColumn("budget_salary_costs_removed", regexp_replace('u_budget_salary_costs', '-', '')) \

    dfSapWorkReports = dfSapWorkReports.withColumn("new_gross_hours",when(dfSapWorkReports.u_gross_hours.like ('%-'), concat(lit("-"),col("gross_hours_removed"))).otherwise(col("u_gross_hours"))) \
                           .withColumn("new_budget_gross_hours",when(dfSapWorkReports.u_budget_gross_hours.like ('%-'), concat(lit("-"),col("budget_gross_hours_removed"))).otherwise(col("u_budget_gross_hours"))) \
                           .withColumn("new_net_hours",when(dfSapWorkReports.u_net_hours.like ('%-'), concat(lit("-"),col("net_hours_removed"))).otherwise(col("u_net_hours"))) \
                           .withColumn("new_budget_net_hours",when(dfSapWorkReports.u_budget_net_hours.like ('%-'), concat(lit("-"),col("budget_net_hours_removed"))).otherwise(col("u_budget_net_hours"))) \
                           .withColumn("new_sick_hours",when(dfSapWorkReports.u_sick_hours.like ('%-'), concat(lit("-"),col("sick_hours_removed"))).otherwise(col("u_sick_hours"))) \
                           .withColumn("new_budget_sick_hours",when(dfSapWorkReports.u_budget_sick_hours.like ('%-'), concat(lit("-"),col("budget_sick_hours_removed"))).otherwise(col("u_budget_sick_hours"))) \
                           .withColumn("new_special_leave_hours",when(dfSapWorkReports.u_special_leave_hours.like ('%-'), concat(lit("-"),col("special_leave_hours_removed"))).otherwise(col("u_special_leave_hours"))) \
                           .withColumn("new_budget_special_leave_hours",when(dfSapWorkReports.u_budget_special_leave_hours.like ('%-'), concat(lit("-"),col("budget_special_leave_hours_removed"))).otherwise(col("u_budget_special_leave_hours"))) \
                           .withColumn("new_additional_hours",when(dfSapWorkReports.u_additional_hours.like ('%-'), concat(lit("-"),col("additional_hours_removed"))).otherwise(col("u_additional_hours"))) \
                           .withColumn("new_budget_additional_hours",when(dfSapWorkReports.u_budget_additional_hours.like ('%-'), concat(lit("-"),col("budget_additional_hours_removed"))).otherwise(col("u_budget_additional_hours"))) \
                           .withColumn("new_salary_costs",when(dfSapWorkReports.u_salary_costs.like ('%-'), concat(lit("-"),col("salary_costs_removed"))).otherwise(col("u_salary_costs"))) \
                           .withColumn("new_budget_salary_costs",when(dfSapWorkReports.u_budget_salary_costs.like ('%-'), concat(lit("-"),col("budget_salary_costs_removed"))).otherwise(col("u_budget_salary_costs")))
                           
    dfSapWorkReports = dfSapWorkReports.withColumn("new_gross_hours", col("new_gross_hours").cast("decimal(17,3)")) \
                           .withColumn("new_budget_gross_hours", col("new_budget_gross_hours").cast("decimal(17,3)")) \
                           .withColumn("new_net_hours", col("new_net_hours").cast("decimal(17,3)")) \
                           .withColumn("new_budget_net_hours", col("new_budget_net_hours").cast("decimal(17,3)")) \
                           .withColumn("new_sick_hours", col("new_sick_hours").cast("decimal(17,3)")) \
                           .withColumn("new_budget_sick_hours", col("new_budget_sick_hours").cast("decimal(17,3)")) \
                           .withColumn("new_special_leave_hours", col("new_special_leave_hours").cast("decimal(17,3)")) \
                           .withColumn("new_budget_special_leave_hours", col("new_budget_special_leave_hours").cast("decimal(17,3)")) \
                           .withColumn("new_additional_hours", col("new_additional_hours").cast("decimal(17,3)")) \
                           .withColumn("new_budget_additional_hours", col("new_budget_additional_hours").cast("decimal(17,3)")) \
                           .withColumn("new_salary_costs", col("new_salary_costs").cast("decimal(17,2)")) \
                           .withColumn("new_budget_salary_costs", col("new_budget_salary_costs").cast("decimal(17,2)")) \
                           
    dfSapWorkReports = dfSapWorkReports.withColumnRenamed("new_gross_hours","gross_hours") \
                           .withColumnRenamed("new_budget_gross_hours","budget_gross_hours") \
                           .withColumnRenamed("new_net_hours","net_hours") \
                           .withColumnRenamed("new_budget_net_hours","budget_net_hours") \
                           .withColumnRenamed("new_sick_hours","sick_hours") \
                           .withColumnRenamed("new_budget_sick_hours","budget_sick_hours") \
                           .withColumnRenamed("new_special_leave_hours","special_leave_hours") \
                           .withColumnRenamed("new_budget_special_leave_hours","budget_special_leave_hours") \
                           .withColumnRenamed("new_additional_hours","additional_hours") \
                           .withColumnRenamed("new_budget_additional_hours","budget_additional_hours") \
                           .withColumnRenamed("new_salary_costs","salary_costs") \
                           .withColumnRenamed("new_budget_salary_costs","budget_salary_costs") \
                           .withColumn("load_time",current_timestamp()) \
                           .withColumn("ingestion_date",col("creation_date")) \
                           .withColumn("ingestion_file", input_file_name()) \
                           .withColumn("year", year("creation_date")) \
                           .withColumn("month", month("creation_date")) \
                           .withColumn("day", dayofmonth("creation_date")) \
                           .drop("filename_reverse")
    
    wdw = Window.partitionBy('store_id','calendar_week','currency').orderBy(desc('ingestion_date'))
    dfSapWorkReports = dfSapWorkReports.withColumn('Rank',rank().over(wdw))
    dfSapWorkReports = dfSapWorkReports.filter(dfSapWorkReports.Rank == 1).drop(dfSapWorkReports.Rank)

    dfSapWorkReports = dfSapWorkReports.select("store_id","calendar_week","gross_hours","budget_gross_hours","net_hours","budget_net_hours","sick_hours","budget_sick_hours","special_leave_hours","budget_special_leave_hours","additional_hours","budget_additional_hours","salary_costs","budget_salary_costs","unit_of_quantity","currency","custom","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info('End of TSAPWorkforceReports def')

    return dfSapWorkReports
