import os
import logging 
import sys
from pyspark.sql.functions import current_timestamp, current_date, input_file_name, sha2, concat_ws, year, month, dayofmonth, trim, col, when, lit
from utils.modules import logger
from functools import reduce

# Instanciate Logger
logger = logger()

def TConsumerAddress(**kwargs):

    logger.info('Invoked TConsumerAddress def')

    dfConsAdd = kwargs.get("df")
    columns = "hema_customer_id;address_id;address_type;address_name;address_line1;address_line2;address_line3;zip_code;city;country_code".split(";")

    oldColumns=dfConsAdd.schema.names
    dfConsAdd = reduce(lambda dfConsAdd, idx: dfConsAdd.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfConsAdd)
    salt = "@)@!-@)#!"

    new_columns = dfConsAdd.columns

    for x in range(1, 4):
        if f'address_line{x}' in new_columns:
            dfConsAdd = dfConsAdd.withColumn(f"address_line{x}", when((col(f"address_line{x}").isNull())|(col(f"address_line{x}")==''), lit('')).otherwise(sha2(concat_ws(salt, trim(col(f"address_line{x}"))), 256),))
    
    dfConsAdd = (
        dfConsAdd.withColumn("load_time",current_timestamp()) 
                         .withColumn("ingestion_date",current_date()) 
                         .withColumn("year", year(current_date())) 
                         .withColumn("month", month(current_date())) 
                         .withColumn("day", dayofmonth(current_date())) 
                         .withColumn("ingestion_file", input_file_name())                          
    )
                           
    logger.info('End of TConsumerAddress def')

    return dfConsAdd
