import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import *
from utils.modules import flatten_df, logger

# Instanciate Logger
logger = logger()


def TsapProductCharacteristics(**kwargs):

    logger.info("Invoked Products def")

    dfProductCharacteristics = kwargs.get("df")
    dfProductCharacteristics = flatten_df(dfProductCharacteristics)

    ################################## Flattening of Data from XML ##################################
    
    #Getting the file path:
    dfProductCharacteristics=dfProductCharacteristics.withColumn("ingestion_file", input_file_name())

    #***************************Added try/except to catch the delta file with only one record ***************************#

    try:
        #Extracting from 1st array ARTIKEL & Dropping of "_xmlns" coloumn:
        dfProductCharacteristics=dfProductCharacteristics.withColumn("ARTIKEL_",explode("ARTIKEL")).drop("ARTIKEL", "_xmlns")
        #Converting ARTIKEL_ from struct:
        dfProductCharacteristics=dfProductCharacteristics.select("ARTIKEL_.*", "*").drop("ARTIKEL_")
        #Converting ARTIKEL_CHARACTERISTICS from struct:
        dfProductCharacteristics=dfProductCharacteristics.select("ARTIKEL_CHARACTERISTICS.*", "*").drop("ARTIKEL_CHARACTERISTICS")

    except:
        #Converting ARTIKEL_ARTIKEL_CHARACTERISTICS from struct:
        dfProductCharacteristics=dfProductCharacteristics.select("ARTIKEL_ARTIKEL_CHARACTERISTICS.*", "*").drop("ARTIKEL_ARTIKEL_CHARACTERISTICS")
        print("Only one record is in the delta file")
        pass

    #Extracting from 2nd array ARTIKEL_KENMERK:
    dfProductCharacteristics=dfProductCharacteristics.withColumn("ARTIKEL_KENMERK_",explode("ARTIKEL_KENMERK")).drop("ARTIKEL_KENMERK")
    #Converting ARTIKEL_KENMERK_ from struct:
    dfProductCharacteristics=dfProductCharacteristics.select("ARTIKEL_KENMERK_.*", "*").drop("ARTIKEL_KENMERK_")
    #Extracting from 3rd array ARTIKEL_WAARDE:
    dfProductCharacteristics=dfProductCharacteristics.withColumn("ARTIKEL_WAARDE_",explode("ARTIKEL_WAARDE")).drop("ARTIKEL_WAARDE")
    #Converting ARTIKEL_KENMERK_ from struct:
    dfProductCharacteristics = dfProductCharacteristics.select("ARTIKEL_WAARDE_.*", "*").drop("ARTIKEL_WAARDE_","_VALUE")

    ################################## Duplicate handling logic ################################## 

    #**************Added try/except to catch the delta file with only one record **************#
    try:
        #Creation of new data Frame:    
        dfsub_set=dfProductCharacteristics.drop("KARAKTERISTIEKEN")
        #Dropping KARAKTERISTIEKEN from main dataframe:
        dfProductCharacteristics=dfProductCharacteristics.select("KARAKTERISTIEKEN")
        #Extracting from 4th array KARAKTERISTIEKEN and dropping _ARTIKELNUMMER for duplicate coloumn names:
        dfProductCharacteristics=dfProductCharacteristics.withColumn("KARAKTERISTIEKEN_",explode("KARAKTERISTIEKEN")).drop("KARAKTERISTIEKEN")
        #Converting KARAKTERISTIEKEN_ from struct:
        dfProductCharacteristics = dfProductCharacteristics.select("KARAKTERISTIEKEN_.*", "*").drop("KARAKTERISTIEKEN_","_VALUE")
    
    except:
        dfsub_set=dfProductCharacteristics.drop("ARTIKEL_KARAKTERISTIEKEN")
        #Dropping ARTIKEL_KARAKTERISTIEKEN from main dataframe:
        dfProductCharacteristics=dfProductCharacteristics.select("ARTIKEL_KARAKTERISTIEKEN")
        #Extracting from 4th array ARTIKEL_KARAKTERISTIEKEN and dropping _ARTIKELNUMMER for duplicate coloumn names:
        dfProductCharacteristics=dfProductCharacteristics.withColumn("KARAKTERISTIEKEN_",explode("ARTIKEL_KARAKTERISTIEKEN")).drop("ARTIKEL_KARAKTERISTIEKEN")
        #Converting KARAKTERISTIEKEN_ from struct:
        dfProductCharacteristics = dfProductCharacteristics.select("KARAKTERISTIEKEN_.*", "*").drop("KARAKTERISTIEKEN_","_VALUE")
        print("Only one record is in the delta file")
        pass

    #Renaming of columns:
    dfProductCharacteristics = dfProductCharacteristics.withColumnRenamed('_ARTIKELNUMMER', 'article_number')

    #Joining of two dataframes:
    dfProductCharacteristics=dfProductCharacteristics.join(dfsub_set, ((dfProductCharacteristics.article_number == dfsub_set._ARTIKELNUMMER) 
                                                                        & (dfProductCharacteristics._TAALCODE == dfsub_set._TAAL)), how='inner')\
                                                       .drop("_ARTIKELNUMMER","_TAALCODE")

    
    #Renaming of columns:
    dfProductCharacteristics = dfProductCharacteristics.withColumnRenamed('_KARAKTERISTIEK_MAAT', 'size')\
                                                       .withColumnRenamed('_KARAKTERISTIEK_KLEUR', 'color')\
                                                       .withColumnRenamed('_KARAKTERISTIEK_THEMA', 'theme')\
                                                       .withColumnRenamed('_KENMERK', 'characteristic')\
                                                       .withColumnRenamed('_CHAR_WAARDE', 'char_value')\
                                                       .withColumnRenamed("_CHAR_CODE", "char_code")\
                                                       .withColumnRenamed("HEADER__BESTANDSNAAM", "header_filename")\
                                                       .withColumnRenamed("HEADER__EAN_ONTVANGER", "header_ean_receiver")\
                                                       .withColumnRenamed("HEADER__EAN_ZENDER", "header_ean_sender")\
                                                       .withColumnRenamed("HEADER__SYSTEEM", "header_system")\
                                                       .withColumnRenamed("HEADER__VERZENDTIJD", "header_send_time")\
                                                       .withColumnRenamed("_TAAL", "language_code")\
                                                       .withColumnRenamed("article_number", "product_id")



    #Creation of new columns:
    dfProductCharacteristics = dfProductCharacteristics.withColumn("header_send_date",
    expr("case when length(HEADER__VERZENDDATUM)=8 then concat(substring(HEADER__VERZENDDATUM,5,4),'-', substring(HEADER__VERZENDDATUM,3,2),'-',substring(HEADER__VERZENDDATUM,1,2)) ELSE concat(substring(HEADER__VERZENDDATUM,4,4),'-', substring(HEADER__VERZENDDATUM,2,2),'-','0',substring(HEADER__VERZENDDATUM,1,1)) END"
    ).cast("date"),)\
                                                     .withColumn("year", year("header_send_date"))\
                                                     .withColumn("month", month("header_send_date"))\
                                                     .withColumn("day", dayofmonth("header_send_date"))\
                                                     .withColumn("load_time", current_timestamp())\
                                                     .withColumn("ingestion_date", current_date())
                                                     

                                                     
    #Deletion of new columns:
    dfProductCharacteristics = dfProductCharacteristics.drop("HEADER__VERZENDDATUM","_ARTIKEL","HEADER__VALUE")

    #Datatype Conversion:
    dfProductCharacteristics = dfProductCharacteristics.withColumn("header_ean_sender", col("header_ean_sender").cast("string"))\
                                                       .withColumn("header_send_time", col("header_send_time").cast("string"))\
                                                       .withColumn("product_id",col("product_id").cast("bigint"))

    #Final Select:
    dfProductCharacteristics = dfProductCharacteristics.select("product_id","language_code","size","color","theme","char_value",
                                                               "characteristic","char_code","header_system","header_ean_sender","header_ean_receiver",
                                                               "header_send_date","header_send_time","ingestion_date","load_time","year","month","day",
                                                               "ingestion_file").distinct()
    logger.info("End of TsapProductMaster def")
    
    return dfProductCharacteristics
