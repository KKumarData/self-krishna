spark-submit --conf spark.driver.memory=4g main.py local jda-locations ./debug_file/ ./out/ 2021/02/02  csv delta "[['location','description_of_location']]" > ./logs/logs.txt
