import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TjdaLocations(**kwargs):

    logger.info("Invoked TjdaLocations def")

    dfjdalocations = kwargs.get("df")

    columns = "location;description_of_location;hierarchy_level;location_type;country_code;sales_organisation;sales_area;is_franchise;store_group;selling_floorspace;sales_district;management_region;postalcode;city;address;longitude;latitude;opening_date;opt_calendargroup_dc;opt_calendargroup_food_ambient;opt_calendargroup_food_fresh;store_type;abcluster;language;formule;top_55_store;currency".split(";")
    
    oldColumns = dfjdalocations.schema.names
    dfjdalocations = reduce(lambda dfjdalocations, idx: dfjdalocations.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfjdalocations)

    dfjdalocations = dfjdalocations.withColumn("filename_reverse", input_file_name())
    dfjdalocations = dfjdalocations.withColumn("filename_reverse", reverse(split(reverse(dfjdalocations.filename_reverse), '/')[0]))

    dfjdalocations = (
        dfjdalocations.withColumn("creation_date1", reverse(split(reverse(dfjdalocations.filename_reverse), '_')[0]))
        .withColumn("creation_date2", reverse(split(reverse(dfjdalocations.filename_reverse), '-')[1]))
        .withColumn(
                            "creation_date1",
                            expr(
                                "concat(substring(creation_date1,1,4),'-', substring(creation_date1,5,2),'-',substring(creation_date1,7,2))").cast("date")
                                )
        .withColumn(
                            "creation_date2",
                            expr(
                                "concat(substring(creation_date2,1,4),'-', substring(creation_date2,5,2),'-',substring(creation_date2,7,2))").cast("date")
                                )
        .withColumn("creation_date1",coalesce(col('creation_date1'),col('creation_date2')))
        .withColumnRenamed("creation_date1","creation_date")                  
        .withColumn("opening_date", col("opening_date").cast("date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse","creation_date2"))

    logger.info("End of jda locations def")
    
    return dfjdalocations
