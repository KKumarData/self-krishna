import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TloyaltyCards(**kwargs):

    logger.info("Invoked TloyaltyCards def")

    dfloyaltyCards = kwargs.get("df")

    columns = "record_number;card_id;hema_customer_id;status;group_id;retailer_id;last_update_time;balance;last_balance_update_time;register_code;balance2;last_balance_2update_time;expiry_date".split(";")
    
    oldColumns = dfloyaltyCards.schema.names
    dfloyaltyCards = reduce(lambda dfloyaltyCards, idx: dfloyaltyCards.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfloyaltyCards)
    
    dfloyaltyCards = dfloyaltyCards.withColumn("filename_reverse", input_file_name())
    dfloyaltyCards = dfloyaltyCards.withColumn("filename_reverse", reverse(split(reverse(dfloyaltyCards.filename_reverse), '/')[0]))

    dfloyaltyCards = (
        dfloyaltyCards.withColumn("last_update_time", col("last_update_time").cast("timestamp"))
        .withColumn("hema_customer_id",expr("concat('{',hema_customer_id,'}')"))
        .withColumn("balance", col("balance").cast("double"))
        .withColumn("last_balance_update_time", col("last_balance_update_time").cast("timestamp"))
        .withColumn("creation_date", substring('filename_reverse',11,8))
        .withColumn(
                            "creation_date",
                            expr(
                                "concat(substring(creation_date,1,4),'-', substring(creation_date,5,2),'-',substring(creation_date,7,2))").cast("date")
                                )
        .withColumn("load_time", current_timestamp())
        .withColumnRenamed("creation_date","ingestion_date") \
        .withColumn("year", year("ingestion_date"))
        .withColumn("month", month("ingestion_date"))
        .withColumn("day", dayofmonth("ingestion_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse"))
    dfloyaltyCards = dfloyaltyCards.select("record_number","card_id","hema_customer_id","status","group_id","retailer_id","last_update_time","balance","last_balance_update_time","register_code","balance2","last_balance_2update_time","expiry_date","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info("End of interslove loyalty cards def")
    
    return dfloyaltyCards
