import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TRcosPosPromo(**kwargs):

    logger.info("Invoked TRcosPosPromo def")

    dfpospromotion = kwargs.get("df")

    columns = "chain;promotion_id;promotion_start;promotion_end;description;minimal_receipt_value;maximal_receipt_value;max_occurs;receipt_tekst;webtext;treazure_title;treazure_tekst;promotion_group;minimal_amount_of_articles;maximal_amount_of_articles;minimal_combined_value_of_articles;max_combined_value_of_articles;identical;consuming;promotion_type_setprice;promotion_type_percentage;promotion_type_discount_amount;calculate_over_ratio;calculate_over_cheapest_article;calculate_over_most_expensive_article;calculate_over_promotiongroup;apply_to_ratio;apply_to_promotiongroup;bookingtype;for;layer;show_promotiondiscount;show_promotionindicator;show_promotion_on_article_information;loyaltycard;valid_for;promotiontype;coupon;characteristic".split(";")
    
    oldColumns = dfpospromotion.schema.names
    dfpospromotion = reduce(lambda dfpospromotion, idx: dfpospromotion.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfpospromotion)
    
    dfpospromotion = dfpospromotion.withColumn("filename_reverse", input_file_name())
    dfpospromotion = dfpospromotion.withColumn("filename_reverse", reverse(split(reverse(dfpospromotion.filename_reverse), '/')[0]))

    dfpospromotion = (
        dfpospromotion.withColumn("promotion_id", col("promotion_id").cast("bigint"))
        .withColumn("promotion_start", col("promotion_start").cast("timestamp"))
        .withColumn("promotion_end", col("promotion_end").cast("timestamp"))
        .withColumn("minimal_receipt_value", col("minimal_receipt_value").cast("decimal(10,2)"))
        .withColumn("maximal_receipt_value", col("maximal_receipt_value").cast("decimal(10,2)"))
        .withColumn("max_occurs", col("max_occurs").cast("int"))
        .withColumn("promotion_group", col("promotion_group").cast("bigint"))
        .withColumn("minimal_amount_of_articles", col("minimal_amount_of_articles").cast("int"))
        .withColumn("maximal_amount_of_articles", col("maximal_amount_of_articles").cast("int"))
        .withColumn("minimal_combined_value_of_articles", col("minimal_combined_value_of_articles").cast("decimal(10,4)"))
        .withColumn("max_combined_value_of_articles", col("max_combined_value_of_articles").cast("decimal(10,4)"))
        .withColumn("promotion_type_setprice", col("promotion_type_setprice").cast("decimal(10,4)"))
        .withColumn("promotion_type_percentage", col("promotion_type_percentage").cast("decimal(10,4)"))
        .withColumn("promotion_type_discount_amount", col("promotion_type_discount_amount").cast("decimal(10,4)"))
        .withColumn("calculate_over_cheapest_article", col("calculate_over_cheapest_article").cast("decimal(10,2)"))
        .withColumn("calculate_over_most_expensive_article", col("calculate_over_most_expensive_article").cast("decimal(10,2)"))
        .withColumn("coupon", col("coupon").cast("bigint"))
        .withColumn("creation_date", substring('filename_reverse',10,10))
        .withColumn(
                            "creation_date",
                            expr(
                                "concat(substring(creation_date,1,4),'-', substring(creation_date,6,2),'-',substring(creation_date,9,2))").cast("date")
                                )
        .withColumn("load_time", current_timestamp())
        .withColumnRenamed("creation_date","ingestion_date") \
        .withColumn("year", year("ingestion_date"))
        .withColumn("month", month("ingestion_date"))
        .withColumn("day", dayofmonth("ingestion_date"))
        .withColumn("ingestion_file", input_file_name())
        .drop("filename_reverse"))
    dfpospromotion = dfpospromotion.select("chain","promotion_id","promotion_start","promotion_end","description","minimal_receipt_value","maximal_receipt_value","max_occurs","receipt_tekst","webtext","treazure_title","treazure_tekst","promotion_group","minimal_amount_of_articles","maximal_amount_of_articles","minimal_combined_value_of_articles","max_combined_value_of_articles","identical","consuming","promotion_type_setprice","promotion_type_percentage","promotion_type_discount_amount","calculate_over_ratio","calculate_over_cheapest_article","calculate_over_most_expensive_article","calculate_over_promotiongroup","apply_to_ratio","apply_to_promotiongroup","bookingtype","for","layer","show_promotiondiscount","show_promotionindicator","show_promotion_on_article_information","loyaltycard","valid_for","promotiontype","coupon","characteristic","load_time","ingestion_date","ingestion_file","year","month","day")
    logger.info("End of TRcosPosPromo")
    
    return dfpospromotion
