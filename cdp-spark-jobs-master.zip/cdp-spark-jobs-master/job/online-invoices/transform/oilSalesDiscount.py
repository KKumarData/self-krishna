import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, logger, camelToUnderscores

# Instanciate Logger
logger = logger()


def ToilSalesDiscount(**kwargs):

    logger.info("Invoked ToilSalesDiscount def")

    df = kwargs.get("df")

    dfDiscount = flatten_df(df)
    dfDiscount = flatten_df(dfDiscount)

    dfDiscount = dfDiscount.withColumn("customer", explode_outer("Customer_CustomerItem")) \
                       .selectExpr("*",f"posexplode_outer(OrderLines_OrderLine) as (order_detail_line_number, order_detail)")

    logger.info("Flatten 3 levels until discount structure")
    dfDiscount = flatten_df(dfDiscount)
    dfDiscount = flatten_df(dfDiscount)
    dfDiscount = flatten_df(dfDiscount)
    
    logger.info("Removing Customer Structure")

    cols_removed = [
        c
        for c in dfDiscount.schema.names
        if 'customer' in c
    ]
    
    dfDiscount = dfDiscount.drop(*cols_removed)

    logger.info("Renaming Columns")

    for colName in dfDiscount.columns:
        dfDiscount = dfDiscount.withColumnRenamed(colName, colName.replace('order_detail_DiscountLines_DiscountLine', 'DiscountLines'))
    
    for colName in dfDiscount.columns:
        dfDiscount = dfDiscount.withColumnRenamed(colName, colName.replace('order_detail_SavedLoyalty_SavedLoyaltyItem', 'LoyaltyPoints'))

    for colName in dfDiscount.columns:
        dfDiscount = dfDiscount.withColumnRenamed(colName, camelToUnderscores(colName))

    
    
    logger.info("Droping Remaining Arrays/Structure Columns")
    
    cols_filtered = [
        c
        for c in dfDiscount.schema.names
        if isinstance(dfDiscount.schema[c].dataType, (ArrayType, StructType))
    ]
    
    a = array(lit(""), lit(""))

    if not "discount_lines" in dfDiscount.columns:
        dfDiscount = dfDiscount.withColumn("discount_lines", lit(a))
    
    dfDiscount = dfDiscount.withColumn("discount_lines", explode_outer("discount_lines"))
    
    dfDiscount = flatten_df(dfDiscount)

    dfDiscount = dfDiscount.drop(*cols_filtered, "discount_lines_RedeemedLoyalty")

    dfDiscount = dfDiscount.withColumnRenamed("discount_lines_CampaignID", "discount_lines_campaign_id") \
                           .withColumnRenamed("discount_lines_Description", "discount_lines_description") \
                           .withColumnRenamed("discount_lines_DiscountExVAT", "discount_lines_discount_exc_vat") \
                           .withColumnRenamed("discount_lines_DiscountIncVAT", "discount_lines_discount_inc_vat") \
                           .withColumnRenamed("discount_lines_DiscountVAT", "discount_lines_discount_vat") \
                           .withColumnRenamed("discount_lines_PromotionID", "discount_lines_promotion_id") \
                        #    .withColumnRenamed("discount_lines_RedeemedLoyalty", "discount_lines_redeemed_loyalty")


    if (not "discount_lines_discount_ex_vat" in dfDiscount.columns):
        dfDiscount = dfDiscount.withColumn("discount_lines_discount_ex_vat", lit("0"))

    if (not "discount_lines_discount_inc_vat" in dfDiscount.columns):
        dfDiscount = dfDiscount.withColumn("discount_lines_discount_inc_vat", lit("0"))
    
    if (not "discount_lines_discount_vat" in dfDiscount.columns):
        dfDiscount = dfDiscount.withColumn("discount_lines_discount_vat", lit("0"))
    
    if (not "loyalty_points_loyalty_points" in dfDiscount.columns):
        dfDiscount = dfDiscount.withColumn("loyalty_points_loyalty_points", lit(""))
    
    if (not "loyalty_points_voucher_id" in dfDiscount.columns):
        dfDiscount = dfDiscount.withColumn("loyalty_points_voucher_id", lit(""))
    
    if (not "order_detail_storage_location" in dfDiscount.columns):
        dfDiscount = dfDiscount.withColumn("order_detail_storage_location", lit(0))
    
    if (not "discount_lines_campaign_id" in dfDiscount.columns):
        dfDiscount = dfDiscount.withColumn("discount_lines_campaign_id", lit(""))
    
    if (not "discount_lines_description" in dfDiscount.columns):
        dfDiscount = dfDiscount.withColumn("discount_lines_description", lit(""))
    
    if (not "discount_lines_promotion_id" in dfDiscount.columns):
        dfDiscount = dfDiscount.withColumn("discount_lines_promotion_id", lit(""))
    
    if (not "discount_lines_redeemed_loyalty" in dfDiscount.columns):
        dfDiscount = dfDiscount.withColumn("discount_lines_redeemed_loyalty", lit(""))

    logger.info("Casting Columns | Generating invoice_id column")

    dfDiscount = (
        dfDiscount.withColumn(
            "invoice_id",
            concat_ws(
                "-",
                "order_number",
                "invoice_number",
                "document_type",
            ),
        )
        .withColumn(
            "transaction_timestamp",
            to_timestamp(
                regexp_replace("invoice_date", "T", " "),
                "yyyy-MM-dd HH:mm:ss",
            ),
        )
        .withColumn(
            "order_timestamp",
            to_timestamp(
                regexp_replace("order_date", "T", " "),
                "yyyy-MM-dd HH:mm:ss",
            ),
        )
        .withColumn(
            "order_detail_unit_price_inc_vat",
            col("order_detail_unit_price_inc_vat").cast("double"),
        )
        .withColumn(
            "order_detail_unit_price_ex_vat",
            col("order_detail_unit_price_ex_vat").cast("double"),
        )
        .withColumn(
            "order_detail_unit_price_vat",
            col("order_detail_unit_price_vat").cast("double"),
        )
        .withColumn(
            "order_detail_unit_cost_price",
            col("order_detail_unit_cost_price").cast("double"),
        )
        .withColumn(
            "order_detail_unit_shipping_costs",
            col("order_detail_unit_shipping_costs").cast("double"),
        )
        .withColumn(
            "order_detail_total_discount_ex_vat",
            col("order_detail_total_discount_ex_vat").cast("double"),
        )
        .withColumn(
            "order_detail_total_discount_inc_vat",
            col("order_detail_total_discount_inc_vat").cast("double"),
        )
        .withColumn(
            "order_detail_total_discount_vat",
            col("order_detail_total_discount_vat").cast("double"),
        )
        .withColumn(
            "order_detail_quantity",
            col("order_detail_quantity").cast("long"),
        )
        .withColumn(
            "order_detail_line_number",
            col("order_detail_line_number").cast("long"),
        )
        .withColumn(
            "order_detail_order_line_number",
            col("order_detail_order_line_number").cast("long"),
        )
        .withColumn(
            "order_detail_sku_number",
            col("order_detail_sku_number").cast("long"),
        )
        .withColumn(
            "discount_lines_discount_ex_vat",
            col("discount_lines_discount_ex_vat").cast("double"),
        )
        .withColumn(
            "discount_lines_discount_inc_vat",
            col("discount_lines_discount_inc_vat").cast("double"),
        )
        .withColumn(
            "discount_lines_discount_vat",
            col("discount_lines_discount_vat").cast("double"),
        )
        .withColumn(
            "loyalty_points_loyalty_points",
            col("loyalty_points_loyalty_points").cast("double"),
        )
        .withColumn(
            "loyalty_points_voucher_id",
            col("loyalty_points_voucher_id").cast("long"),
        )
        .withColumn(
            "invoice_date",
            col("invoice_date").cast("date"),
        )
        .withColumn(
            "order_date",
            col("order_date").cast("date"),
        )
        .withColumn(
            "order_number",
            col("order_number").cast("long"),
        )
        .withColumn(
            "invoice_number",
            col("invoice_number").cast("long"),
        )
        .withColumn(
            "order_detail_saved_loyalty_points",
            col("order_detail_saved_loyalty_points").cast("long"),
        )
        .withColumn(
            "order_detail_storage_location",
            col("order_detail_storage_location").cast("long"),
        )
        .withColumn(
            "order_detail_default_ean",
            col("order_detail_default_ean").cast("long"),
        )
        .withColumn(
            "order_detail_main_product_group",
            col("order_detail_main_product_group").cast("long"),
        )
        .withColumn(
            "order_detail_position",
            col("order_detail_position").cast("long"),
        )
        .withColumn(
            "order_detail_pre_payment",
            col("order_detail_pre_payment").cast("double"),
        )
        .withColumn(
            "order_detail_product_number",
            col("order_detail_product_number").cast("long"),
        )
        .withColumn(
            "discount_lines_redeemed_loyalty",
            col("discount_lines_redeemed_loyalty").cast("string"),
        )
        .withColumn("year", year("transaction_timestamp"))
        .withColumn("month", month("transaction_timestamp"))
        .withColumn("day", dayofmonth("transaction_timestamp"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .dropDuplicates(['invoice_id', 'invoice_date', 'order_detail_sku_number',  'order_detail_order_line_number', 'discount_lines_promotion_id'])
    )

    logger.info("End of ToilSalesDiscount def")

    return dfDiscount
