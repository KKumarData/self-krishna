import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, camelToUnderscores, logger

# Instanciate logger
logger = logger()


def ToilSalesHeader(**kwargs):

    logger.info("Invoked ToilSalesHeader def")

    df = kwargs.get("df")

    dfHeader = flatten_df(df)
    dfHeader = flatten_df(dfHeader)
    dfHeader = dfHeader.drop("OrderLines_OrderLine")

    if ("Customer_CustomerItem" in dfHeader.columns):
        dfHeader = dfHeader.withColumn("customer", explode_outer("Customer_CustomerItem"))
        
    # dfHeader = dfHeader.withColumn("customer", explode_outer("Customer_CustomerItem"))
    dfHeader = flatten_df(dfHeader)

    for colName in dfHeader.columns:
        dfHeader = dfHeader.withColumnRenamed(colName, camelToUnderscores(colName))

    cols_filtered = [
        c
        for c in dfHeader.schema.names
        if isinstance(dfHeader.schema[c].dataType, (ArrayType, StructType))
    ]

    dfHeader = dfHeader.drop(*cols_filtered)

    salt = "@)@!-@)#!"

    if (not "customer_address" in dfHeader.columns):
        dfHeader = dfHeader.withColumn("customer_address", lit(""))
    
    if (not "customer_first_name" in dfHeader.columns):
        dfHeader = dfHeader.withColumn("customer_first_name", lit(""))
    
    if (not "customer_house_number" in dfHeader.columns):
        dfHeader = dfHeader.withColumn("customer_house_number", lit(""))
    
    if (not "customer_house_number_alpha" in dfHeader.columns):
        dfHeader = dfHeader.withColumn("customer_house_number_alpha", lit(""))
    
    if (not "customer_last_name" in dfHeader.columns):
        dfHeader = dfHeader.withColumn("customer_last_name", lit(""))

    if (not "customer_phone" in dfHeader.columns):
        dfHeader = dfHeader.withColumn("customer_phone", lit(""))
    
    if (not "customer_phone" in dfHeader.columns):
        dfHeader = dfHeader.withColumn("customer_phone", lit(""))

    if (not "customer_middle_name" in dfHeader.columns):
        dfHeader = dfHeader.withColumn("customer_middle_name", lit(""))

    if (not "customer_service_point_id" in dfHeader.columns):
        dfHeader = dfHeader.withColumn("customer_service_point_id", lit("0"))
    
    if (not "customer_service_point_name" in dfHeader.columns):
        dfHeader = dfHeader.withColumn("customer_service_point_name", lit(""))
    


    dfHeader = (
        dfHeader.withColumn(
            "customer_email",
            sha2(concat_ws(salt, dfHeader.customer_email), 256),
        )
        .withColumn(
            "invoice_id",
            concat_ws(
                "-",
                "order_number",
                "invoice_number",
                "document_type",
            ),
        )
        .withColumn(
            "transaction_timestamp",
            to_timestamp(
                regexp_replace("invoice_date", "T", " "),
                "yyyy-MM-dd HH:mm:ss",
            ),
        )
        .withColumn(
            "order_timestamp",
            to_timestamp(
                regexp_replace("order_date", "T", " "),
                "yyyy-MM-dd HH:mm:ss",
            ),
        )
        .withColumn(
            "invoice_date",
            col("invoice_date").cast("date"),
        )
        .withColumn(
            "order_date",
            col("order_date").cast("date"),
        )
        .withColumn(
            "order_number",
            col("order_number").cast("long"),
        )
        .withColumn(
            "invoice_number",
            col("invoice_number").cast("long"),
        )
        .withColumn(
            "customer_service_point_id",
            col("customer_service_point_id").cast("long"),
        )
        .withColumn("year", year("transaction_timestamp"))
        .withColumn("month", month("transaction_timestamp"))
        .withColumn("day", dayofmonth("transaction_timestamp"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .drop(
            "customer_address",
            "customer_first_name",
            "customer_house_number",
            "customer_house_number_alpha",
            "customer_last_name",
            "customer_phone",
            "customer_middle_name",
        )
        .dropDuplicates(['invoice_id','invoice_date', 'customer_customer_type'])
    )

    logger.info("End of ToilSalesHeader def")

    return dfHeader
