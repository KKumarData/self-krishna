import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, logger, camelToUnderscores

# Instanciate Logger
logger = logger()


def ToilSalesDetail(**kwargs):

    logger.info("Invoked ToilSalesDetail def")

    df = kwargs.get("df")
    dfDetail = flatten_df(df)
    dfDetail = flatten_df(dfDetail)

    if (
        "Customer_CustomerItem"
        in dfDetail.columns
    ):
        dfDetail = dfDetail.withColumn("customer", explode_outer("Customer_CustomerItem"))
    
    # FIX EMPTY STRUCTURE
    a = array(lit(""), lit(""))
    
    if not "OrderLines_OrderLine" in dfDetail.columns:
        dfDetail = dfDetail.withColumn("OrderLines_OrderLine", lit(a))

    # EXPLODE ARRAY
    dfDetail = dfDetail.selectExpr("*",f"posexplode_outer(OrderLines_OrderLine) as (order_detail_line_number, order_detail)")

    dfDetail = flatten_df(dfDetail)

    for colName in dfDetail.columns:
        dfDetail = dfDetail.withColumnRenamed(colName, camelToUnderscores(colName))

    cols_filtered = [
        c
        for c in dfDetail.schema.names
        if isinstance(dfDetail.schema[c].dataType, (ArrayType, StructType))
    ]

    dfDetail = dfDetail.drop(*cols_filtered)

    salt = "@)@!-@)#!"

    if (not "customer_address" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("customer_address", lit(""))
    
    if (not "customer_first_name" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("customer_first_name", lit(""))
    
    if (not "customer_house_number" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("customer_house_number", lit(""))
    
    if (not "customer_house_number_alpha" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("customer_house_number_alpha", lit(""))
    
    if (not "customer_last_name" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("customer_last_name", lit(""))

    if (not "customer_phone" in dfDetail.columns):
        dfDetail = dfDetail.dfDetail("customer_phone", lit(""))
    
    if (not "customer_email" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("customer_email", lit(""))
    
    if (not "customer_middle_name" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("customer_middle_name", lit(""))
    
    if (not "customer_service_point_id" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("customer_service_point_id", lit("0"))
    
    if (not "customer_service_point_name" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("customer_service_point_name", lit(""))
    
    if (not "order_detail_storage_location" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_storage_location", lit(0))
    
    if (not "order_detail_unit_price_inc_vat" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_unit_price_inc_vat", lit(0.00))

    if (not "order_detail_unit_price_ex_vat" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_unit_price_ex_vat", lit(0.00))
    
    if (not "order_detail_unit_price_ex_vat" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_unit_price_ex_vat", lit(0.00))
    
    if (not "order_detail_unit_price_vat" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_unit_price_vat", lit(0.00))
    
    if (not "order_detail_unit_cost_price" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_unit_cost_price", lit(0.00))
    
    if (not "order_detail_unit_shipping_costs" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_unit_shipping_costs", lit(0.00))
    
    if (not "order_detail_total_discount_ex_vat" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_total_discount_ex_vat", lit(0.00))

    if (not "order_detail_total_discount_inc_vat" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_total_discount_inc_vat", lit(0.00))
    
    if (not "order_detail_total_discount_vat" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_total_discount_vat", lit(0.00))
    
    if (not "order_detail_saved_loyalty_points" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_saved_loyalty_points", lit(0))
    
    if (not "order_detail_quantity" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_quantity", lit(0))
    
    if (not "order_detail_order_line_number" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_order_line_number", lit(0))
    
    if (not "order_detail_sku_number" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_sku_number", lit(0))
    
    if (not "order_detail_default_ean" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_default_ean", lit(0))
    
    if (not "order_detail_main_product_group" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_main_product_group", lit(0))
    
    if (not "order_detail_position" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_position", lit(0))
    
    if (not "order_detail_pre_payment" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_pre_payment", lit(0))
    
    if (not "order_detail_product_number" in dfDetail.columns):
        dfDetail = dfDetail.withColumn("order_detail_product_number", lit(0))
    

    dfDetail = (
        dfDetail.withColumn('customer_email',when(dfDetail.customer_email.isNull(), "")
                                                      .when(dfDetail.customer_email == '', "") 
                                                      .otherwise(sha2(concat_ws(salt, dfDetail.customer_email), 256),)
        )
        .withColumn(
            "invoice_id",
            concat_ws(
                "-",
                "order_number",
                "invoice_number",
                "document_type",
            ),
        )
        .withColumn(
            "transaction_timestamp",
            to_timestamp(
                regexp_replace("invoice_date", "T", " "),
                "yyyy-MM-dd HH:mm:ss",
            ),
        )
        .withColumn(
            "order_timestamp",
            to_timestamp(
                regexp_replace("order_date", "T", " "),
                "yyyy-MM-dd HH:mm:ss",
            ),
        )
        .withColumn(
            "order_detail_unit_price_inc_vat",
            col("order_detail_unit_price_inc_vat").cast("double"),
        )
        .withColumn(
            "order_detail_unit_price_ex_vat",
            col("order_detail_unit_price_ex_vat").cast("double"),
        )
        .withColumn(
            "order_detail_unit_price_vat",
            col("order_detail_unit_price_vat").cast("double"),
        )
        .withColumn(
            "order_detail_unit_cost_price",
            col("order_detail_unit_cost_price").cast("double"),
        )
        .withColumn(
            "order_detail_unit_shipping_costs",
            col("order_detail_unit_shipping_costs").cast("double"),
        )
        .withColumn(
            "order_detail_total_discount_ex_vat",
            col("order_detail_total_discount_ex_vat").cast("double"),
        )
        .withColumn(
            "order_detail_total_discount_inc_vat",
            col("order_detail_total_discount_inc_vat").cast("double"),
        )
        .withColumn(
            "order_detail_total_discount_vat",
            col("order_detail_total_discount_vat").cast("double"),
        )
        .withColumn(
            "order_detail_saved_loyalty_points",
            col("order_detail_saved_loyalty_points").cast("long"),
        )
        .withColumn(
            "order_detail_storage_location",
            col("order_detail_storage_location").cast("long"),
        )
        .withColumn(
            "order_detail_quantity",
            col("order_detail_quantity").cast("long"),
        )
        .withColumn(
            "order_detail_line_number",
            col("order_detail_line_number").cast("long"),
        )
        .withColumn(
            "order_detail_order_line_number",
            col("order_detail_order_line_number").cast("long"),
        )
        .withColumn(
            "order_detail_sku_number",
            col("order_detail_sku_number").cast("long"),
        )
        .withColumn(
            "invoice_date",
            col("invoice_date").cast("date"),
        )
        .withColumn(
            "order_date",
            col("order_date").cast("date"),
        )
        .withColumn(
            "order_number",
            col("order_number").cast("long"),
        )
        .withColumn(
            "invoice_number",
            col("invoice_number").cast("long"),
        )
        .withColumn(
            "customer_service_point_id",
            col("customer_service_point_id").cast("long"),
        )
        .withColumn(
            "order_detail_default_ean",
            col("order_detail_default_ean").cast("long"),
        )
        .withColumn(
            "order_detail_main_product_group",
            col("order_detail_main_product_group").cast("long"),
        )
        .withColumn(
            "order_detail_position",
            col("order_detail_position").cast("long"),
        )
        .withColumn(
            "order_detail_pre_payment",
            col("order_detail_pre_payment").cast("double"),
        )
        .withColumn(
            "order_detail_product_number",
            col("order_detail_product_number").cast("long"),
        )
        .withColumn("year", year("transaction_timestamp"))
        .withColumn("month", month("transaction_timestamp"))
        .withColumn("day", dayofmonth("transaction_timestamp"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .drop(
            "customer_address",
            "customer_first_name",
            "customer_house_number",
            "customer_house_number_alpha",
            "customer_last_name",
            "customer_phone",
            "customer_middle_name",
        )
        .dropDuplicates(['invoice_id', 'invoice_date', 'order_detail_sku_number', 'order_detail_order_line_number'])
    )

    logger.info("End of ToilSalesDetail def")

    return dfDetail
