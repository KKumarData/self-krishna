import os
import sys
import logging
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.functions import reverse
from pyspark.sql.types import *
from pyspark.sql import functions as Fun
from pyspark.sql.types import StructType, ArrayType, StringType, StructField
from utils.modules import logger
from functools import reduce
from datetime import datetime
from pyspark.sql.functions import input_file_name


# Instanciate Logger
logger = logger()

def TfranprixSales(**kwargs):

    logger.info("Invoked TstoreStock def")

    dfFranprix = kwargs.get("df")

    columns = "calendar_day;store_id;product_id;number_of_unit_sold;unit_of_measure;unit_price_including_tax;unit_price_excluding_tax;discount;currency_code;number_of_unit_returned;message_type".split(";")
    
    oldColumns = dfFranprix.schema.names
    dfFranprix = reduce(lambda dfFranprix, idx: dfFranprix.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfFranprix)

    dfFranprix = dfFranprix.withColumn("calendar_day",
                            expr(
                                "concat(substring(calendar_day,1,4),'-', substring(calendar_day,5,2),'-',substring(calendar_day,7,2))").cast("date")
                                )

    dfFranprix = (
        dfFranprix.withColumn("store_id",col("store_id").cast("bigint"))
        .withColumn("product_id",col("product_id").cast("bigint"))
        .withColumn("number_of_unit_sold",col("number_of_unit_sold").cast("int"))
        .withColumn("unit_price_including_tax",col("unit_price_including_tax").cast("decimal(18,2)"))
        .withColumn("unit_price_excluding_tax",col("unit_price_excluding_tax").cast("decimal(18,2)"))
        .withColumn("discount",col("discount").cast("decimal(18,2)"))
        .withColumn("number_of_unit_returned",col("number_of_unit_returned").cast("int"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("year", year("calendar_day"))
        .withColumn("month", month("calendar_day"))
        .withColumn("day", dayofmonth("calendar_day"))
        .withColumn("ingestion_file", input_file_name())
        )
        
    dfFranprix = dfFranprix.dropDuplicates(['calendar_day','store_id','product_id'])
    
    logger.info("Detailed data creation ends here")

    logger.info("End of franprix sales def")
    
    return dfFranprix
