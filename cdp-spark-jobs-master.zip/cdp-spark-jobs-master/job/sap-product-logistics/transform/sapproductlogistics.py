import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType, DateType
from utils.modules import flatten_df, logger
from pyspark.sql.functions import input_file_name
from pyspark.sql.window import Window

# Instanciate Logger
logger = logger()


def TsapProductLogistics(**kwargs):

    logger.info("Invoked ProductLlogistics def")

    dfProductLlogistics = kwargs.get("df")
    dfProductLlogistics = flatten_df(dfProductLlogistics)

    dfProductLlogistics = dfProductLlogistics.withColumn("artikel_1", explode("ARTIKEL")).drop("ARTIKEL", "_xmlns")
    dfProductLlogistics = flatten_df(dfProductLlogistics)
    dfProductLlogistics = flatten_df(dfProductLlogistics)

    dfProductLlogistics = dfProductLlogistics.withColumn("artikel_details", explode("artikel_1_ARTIKEL_LOGISTIEK_ARTIKEL_LOGPAR")).drop("ARTIKEL_ARTIKEL_LOGISTIEK_ARTIKEL_LOGPAR","_xmlns")
    dfProductLlogistics = flatten_df(dfProductLlogistics)
    dfProductLlogistics = flatten_df(dfProductLlogistics)

    dfProductLlogistics = dfProductLlogistics.withColumn("artikel_gegevens", explode("artikel_1_ARTIKEL_LOGREF_ARTIKEL_LOGREF_GEGEVENS")).drop("ARTIKEL_ARTIKEL_LOGREF_ARTIKEL_LOGREF_GEGEVENS")
    dfProductLlogistics = flatten_df(dfProductLlogistics)
    dfProductLlogistics = flatten_df(dfProductLlogistics)

    if not 'artikel_details__MAP' in dfProductLlogistics.columns:
        dfProductLlogistics = dfProductLlogistics.withColumn('artikel_details__MAP', lit('Null'))
        dfProductLlogistics=dfProductLlogistics.withColumnRenamed("artikel_details__MAP", "MAP")
    else:
        dfProductLlogistics=dfProductLlogistics.withColumnRenamed("artikel_details__MAP", "MAP")

    if not 'artikel_details__STOCKPLANNER' in dfProductLlogistics.columns:
        dfProductLlogistics = dfProductLlogistics.withColumn('artikel_details__STOCKPLANNER', lit('Null'))
        dfProductLlogistics=dfProductLlogistics.withColumnRenamed("artikel_details__STOCKPLANNER", "stockplanner")
    else:
        dfProductLlogistics=dfProductLlogistics.withColumnRenamed("artikel_details__STOCKPLANNER", "stockplanner")

    if not 'artikel_gegevens__VOLUME' in dfProductLlogistics.columns:
        dfProductLlogistics = dfProductLlogistics.withColumn('artikel_gegevens__VOLUME', lit('Null'))
        dfProductLlogistics=dfProductLlogistics.withColumnRenamed("artikel_gegevens__VOLUME", "volume")
    else:
        dfProductLlogistics=dfProductLlogistics.withColumnRenamed("artikel_gegevens__VOLUME", "volume")

    if not 'artikel_gegevens__VOLUME_EENHEID' in dfProductLlogistics.columns:
        dfProductLlogistics = dfProductLlogistics.withColumn('artikel_gegevens__VOLUME_EENHEID', lit('Null'))
        dfProductLlogistics=dfProductLlogistics.withColumnRenamed("artikel_gegevens__VOLUME_EENHEID", "volume_unit")
    else:
        dfProductLlogistics=dfProductLlogistics.withColumnRenamed("artikel_gegevens__VOLUME_EENHEID", "volume_unit")


    dfProductLlogistics = (
        dfProductLlogistics.withColumnRenamed("HEADER__BESTANDSNAAM", "file_name")
        .withColumnRenamed("HEADER__EAN_ONTVANGER", "ean_receiver")
        .withColumnRenamed("HEADER__EAN_ZENDER", "ean_sender")
        .withColumnRenamed("HEADER__SYSTEEM", "system")
        .withColumnRenamed("HEADER__VERZENDDATUM","sap_last_updated_date")
        .withColumnRenamed("HEADER__VERZENDTIJD", "sap_last_updated_time")
        .withColumnRenamed("artikel_1__ARTIKEL", "product_id")
        .withColumnRenamed("artikel_1_ARTIKEL_LOGISTIEK__ARTIKELNUMMER", "Product_id_logistics")
        .withColumnRenamed("artikel_details__DC", "dc")
        .withColumnRenamed("artikel_details__RP_PROFIEL", "rp_profile")
        .withColumnRenamed("artikel_gegevens__ALTERN_UNIT", "altern_unit")
        .withColumnRenamed("artikel_gegevens__BREEDTE", "width" )
        .withColumnRenamed("artikel_gegevens__BRUTO_GEWICHT", "gross_weight")
        .withColumnRenamed("artikel_gegevens__HOOGTE", "height")
        .withColumnRenamed("artikel_gegevens__LENGTE", "length")
        .withColumnRenamed("artikel_gegevens__NETTO_GEWICHT", "net_weight")
        .withColumnRenamed("artikel_gegevens__NUMERATOR", "numerator")
        .withColumnRenamed("artikel_gegevens__UOM_AFM", "uom_afm")
        .withColumnRenamed("artikel_gegevens__UOM_GEW", "uom_gew")
    )

    dfProductLlogistics = (
        dfProductLlogistics.withColumn("product_id",col("product_id").cast("bigint"))
        .withColumn(
                            "sap_last_updated_date",
                            expr(
                                "concat(substring(sap_last_updated_date,5,4),'-', substring(sap_last_updated_date,3,2),'-',substring(sap_last_updated_date,1,2))").cast("date")
                                )
        .withColumn("sap_last_updated_time",col("sap_last_updated_time").cast("bigint"))
        .withColumn("Product_id_logistics",col("Product_id_logistics").cast("bigint"))
        .withColumn("MAP", col("MAP").cast('decimal(18,3)'))
        .withColumn("numerator", col("numerator").cast("bigint"))
        .withColumn("length", col("length").cast('decimal(18,3)'))
        .withColumn("width", col("width").cast('decimal(18,3)'))
        .withColumn("height", col("height").cast('decimal(18,3)'))
        .withColumn("net_weight", col("net_weight").cast('decimal(18,3)'))
        .withColumn("gross_weight", col("gross_weight").cast('decimal(18,3)'))
        .withColumn("volume", col("volume").cast('decimal(18,3)'))
        .withColumn("year", year("sap_last_updated_date"))
        .withColumn("month", month("sap_last_updated_date"))
        .withColumn("day", dayofmonth("sap_last_updated_date"))
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .select("file_name","system","ean_sender","ean_receiver","sap_last_updated_date","sap_last_updated_time","product_id","Product_id_logistics","dc","rp_profile","Stockplanner","MAP","altern_unit","numerator","length","width","height","uom_afm","net_weight","gross_weight","uom_gew","Volume","Volume_unit","load_time","ingestion_date","ingestion_file","year","month","day")
        .drop("HEADER__VALUE","artikel_details__VALUE","artikel_gegevens__VALUE","artikel_1_ARTIKEL_LOGREF__ARTIKELNUMMER")
    )

    w = Window.partitionBy('product_id','product_id_logistics','dc','altern_unit').orderBy(desc('sap_last_updated_date'))
    dfProductLlogistics = dfProductLlogistics.withColumn('Rank',rank().over(w))
    dfProductLlogistics = dfProductLlogistics.filter(dfProductLlogistics.Rank == 1).drop(dfProductLlogistics.Rank)
    dfProductLlogistics = dfProductLlogistics.dropDuplicates(['product_id','product_id_logistics','dc','altern_unit'])
    
    logger.info("End of TsapProductLogistics def")

    return dfProductLlogistics
