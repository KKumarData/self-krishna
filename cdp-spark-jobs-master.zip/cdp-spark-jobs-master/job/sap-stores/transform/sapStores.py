import os
import logging
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, ArrayType
from utils.modules import flatten_df, logger

# Instanciate Logger
logger = logger()


def TsapStore(**kwargs):

    logger.info("Invoked TsapPrice def")

    df = kwargs.get("df")
    dfSapStore = flatten_df(df)
    
    dfSapStore = flatten_df(dfSapStore)
    dfSapStore = dfSapStore.withColumn(
        "STORES_VESTIGING_ALGEMEEN", explode_outer("VESTIGING_ALGEMEEN")
    )
    
    dfSapStore = flatten_df(dfSapStore)
    
    cols_filtered = [
        c
        for c in flatten_df(dfSapStore).schema.names
        if isinstance(
            flatten_df(dfSapStore).schema[c].dataType, (ArrayType, StructType)
        )
    ]

    dfSapStore = dfSapStore.drop(*cols_filtered)
    

    dfSapStore = (
        dfSapStore.withColumnRenamed("HEADER__BESTANDSNAAM", "header_filename")
        .withColumnRenamed("HEADER__EAN_ONTVANGER", "header_system")
        .withColumnRenamed("HEADER__EAN_ZENDER", "header_ean_sender")
        .withColumnRenamed("HEADER__SYSTEEM", "header_ean_receiver")
        .withColumnRenamed("HEADER__VERZENDDATUM", "header_send_date")
        .withColumn(
            "header_send_date",
            expr(
                "case when length(header_send_date) < 8 THEN concat(substring(header_send_date,4,4),'-', substring(header_send_date,2,2),'-', '0' ,substring(header_send_date,1,1)) ELSE concat(substring(header_send_date,5,4),'-', substring(header_send_date,3,2),'-', '0' ,substring(header_send_date,1,2)) END"
            ).cast("date"),
        )
        .withColumnRenamed("HEADER__VERZENDTIJD", "header_send_time")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__AB_EV", "store_type")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__AG_ADRES", "delivery_address")
        .withColumnRenamed(
            "STORES_VESTIGING_ALGEMEEN__AG_POSTCODE", "delivery_postal_code"
        )
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__BLOCKFROM", "block_from")
        .withColumn(
            "block_from",
            expr(
                "case when length(block_from) == 0 THEN '' ELSE CASE WHEN length(block_from) < 8 THEN concat(substring(block_from,4,4),'-', substring(block_from,2,2),'-', '0' ,substring(block_from,1,1)) ELSE concat(substring(block_from,5,4),'-', substring(block_from,3,2),'-', '0' ,substring(block_from,1,2)) END END"
            ).cast("date"),
        )
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__BLOCKTO", "block_to")
        .withColumn(
            "block_to",
            expr(
                "case when length(block_to) == 0 THEN '' ELSE CASE WHEN length(block_to) < 8 THEN concat(substring(block_to,4,4),'-', substring(block_to,2,2),'-', '0' ,substring(block_to,1,1)) ELSE concat(substring(block_to,5,4),'-', substring(block_to,3,2),'-', '0' ,substring(block_to,1,2)) END END"
            ).cast("date"),
        )
        .withColumnRenamed(
            "STORES_VESTIGING_ALGEMEEN__DISTRIBUTIEKANAAL", "distribution_channel_id"
        )
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__EMAIL", "email")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__EMAIL_GEBAK", "email_pastry")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__LANDCODE", "country_id")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__LATITUDE", "latitude")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__LONGITUDE", "longitude")
        .withColumnRenamed(
            "STORES_VESTIGING_ALGEMEEN__NAAM_DISTRIBUTIEKANAAL",
            "distribution_channel_descr",
        )
        .withColumnRenamed(
            "STORES_VESTIGING_ALGEMEEN__NAAM_VERKOOPORGANISATIE",
            "sales_organisation_descr",
        )
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__OPENINGSDATUM", "opening_date")
        .withColumn(
            "opening_date",
            expr(
                "case when length(opening_date) == 0 THEN '' ELSE CASE WHEN length(opening_date) < 8 THEN concat(substring(opening_date,4,4),'-', substring(opening_date,2,2),'-', '0' ,substring(opening_date,1,1)) ELSE concat(substring(opening_date,5,4),'-', substring(opening_date,3,2),'-', '0' ,substring(opening_date,1,2)) END END"
            ).cast("date"),
        )
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__OPPERVLAKTE", "surface")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__PHONE", "phone")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__POSTCODE", "postal_code")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__REGIONUMMER", "region_id")
        .withColumnRenamed(
            "STORES_VESTIGING_ALGEMEEN__REGIO_LOCATIE", "region_location_id"
        )
        .withColumnRenamed(
            "STORES_VESTIGING_ALGEMEEN__REGIO_LOCATIE_NAAM", "region_location_descr"
        )
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__REMARKS", "remarks")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__SLUITINGSDATUM", "closting_date")
        .withColumn(
            "closting_date",
            expr(
                "case when length(closting_date) == 0 THEN '' ELSE CASE WHEN length(closting_date) < 8 THEN concat(substring(closting_date,4,4),'-', substring(closting_date,2,2),'-', '0' ,substring(closting_date,1,1)) ELSE concat(substring(closting_date,5,4),'-', substring(closting_date,3,2),'-', '0' ,substring(closting_date,1,2)) END END"
            ).cast("date"),
        )
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__STAD", "city")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__STATUS", "status")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__STRAATNAAM", "street")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__TAALCODE", "language_code")
        .withColumnRenamed(
            "STORES_VESTIGING_ALGEMEEN__VERKOOPORGANISATIE", "sales_organisation_id"
        )
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__VESTIGING", "store_id")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__VESTIGINGNAAM", "store_name")
        .withColumnRenamed("STORES_VESTIGING_ALGEMEEN__WINKELTYPE", "store_group")
        .withColumnRenamed(
            "STORES_VESTIGING_ALGEMEEN__WINKEL_KASSA_VALUTA", "store_currency"
        )
        .withColumnRenamed(
            "STORES_VESTIGING_ALGEMEEN__REGIONAAM", "general_region_descr"
        )
        .withColumn("load_time", current_timestamp())
        .withColumn("ingestion_date", current_date())
        .withColumn("ingestion_file", input_file_name())
        .withColumn("year", year("header_send_date"))
        .withColumn("month", month("header_send_date"))
        .withColumn("day", dayofmonth("header_send_date"))
        .drop("STORES__xmlns", "HEADER__VALUE", "STORES_VESTIGING_ALGEMEEN__VALUE")
        .dropDuplicates(["store_id"])
    )

    
    logger.info("End of TsapPrice def")
    
    return dfSapStore
