import os
import logging 
import sys
from pyspark.sql.functions import *
from utils.modules import logger
from functools import reduce
from pyspark.sql.session import SparkSession
from pyspark.context import SparkContext
from pyspark.sql.functions import input_file_name

logger = logger()

def THROrganizationStructure(**kwargs):

    logger.info('Invoked THROrganizationStructure def')

    dfOrgStruc = kwargs.get("df")

    columns = "cost_center;name_cost_center;country;unit;region_or_department;sub_department".split(";")
    oldColumns=dfOrgStruc.schema.names
    dfOrgStruc = reduce(lambda dfOrgStruc, idx: dfOrgStruc.withColumnRenamed(oldColumns[idx], columns[idx]), range(len(oldColumns)), dfOrgStruc)
    
    dfOrgStruc = dfOrgStruc.withColumn("filename_reverse", input_file_name())
    dfOrgStruc = dfOrgStruc.withColumn("filename_reverse", reverse(split(reverse(dfOrgStruc.filename_reverse), '/')[0]))
    
    dfOrgStruc = dfOrgStruc.withColumn("load_time",current_timestamp()) \
                           .withColumnRenamed("filename_reverse","ingestion_file") \
                           .withColumn("ingestion_date",current_date())
    dfOrgStruc = dfOrgStruc.select("cost_center","name_cost_center","country","unit","region_or_department","sub_department","load_time","ingestion_date","ingestion_file")
    logger.info('End of THROrganizationStructure def')

    return dfOrgStruc
